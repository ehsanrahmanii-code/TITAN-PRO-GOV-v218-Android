# Changelog

## v2.1.8-CALIBRATED — decisions measured against real outcomes

- **New `app/engine/calibrate.py`** (Governor 1.8.0): every resolved entry of the signal log (TP1 / SL / 4 h sign) now measures what each confidence band (<50, 50-65, 65+) and each side (LONG/SHORT) *really* delivered. Win rates are shrunk toward the global rate (Beta prior) and shown with an 80 % Wilson lower bound, so one lucky trade never reads as 100 %.
- **Expected R per signal** = p·R − (1−p) − round-trip cost, using the signal's own R:R. A signal is **blocked only when the measured expectancy is clearly negative** (point EV < −0.10R and lower-bound EV < −0.25R, ≥25 resolved outcomes overall and ≥12 in the matching band/side). Near break-even or thin evidence never blocks.
- **Honest confidence:** the published confidence is blended with the measured win rate (weight grows with sample size, max 50 %), and the reason line shows the measured rate and expected R.
- **Cold start is a no-op:** with fewer than 25 resolved outcomes nothing changes — the panel says how many are still needed.
- New `GET /api/calibration`, a calibration panel on the Signals page, `calibration` field on every matrix row / governor result.
- Fixed while writing it: an explicit-data call must never hit the cache; cache key now changes whenever an outcome resolves or flips.
- 5 new tests (inert without data, blocks only clear losers, shrinkage, governor respects block/blend, API). Suite: 81 tests, 0 failures; browser sweep desktop + phone: 0 errors, 0 overflow.

## v2.1.7-AUDIT-GZIP

Full audit: 76 offline tests, static check, `node --check` on all 7 JS files, sweep of 29 GET endpoints, fuzz of ~20 POST endpoints with invalid input, real headless Chromium on desktop (1366 px) and phone (390 px) viewports through all 8 pages and all 10 coin tabs: **0 JS errors, 0 failed requests, 0 horizontal overflow, 0 HTTP 500**.

- **Responses are now gzip-compressed** (stdlib, no new dependency): `/api/matrix` 190 KB → 56 KB, `/api/coin` 196 KB → 58 KB, `/api/deep` 192 KB → 48 KB, JS/CSS −70 %. Streamed static files, ETag and `Vary` handled; compression can never turn a response into an error.
- `/api/alerts` and `/api/auto/config` no longer return raw Python exception text on bad input (Persian message instead).
- `_pair_corr` no longer emits NaN/RuntimeWarning on flat series; `extras.stats` autocorrelation on a flat series no longer warns (both return 0).
- `tests/static_check.py` and `tools/sim_server.py` no longer write `__pycache__` next to the code (data-only-in-XXX rule).
- 3 new tests (gzip round-trip incl. static files, no exception leak, flat-series correlation).
- Known and left as is on purpose: the first `/api/report/<coin>` call runs a 33-step walk-forward backtest (≈2–4 s, then cached 10 min). Skipping the extras inside it would change the backtest's signals, so it was not touched.

## v2.1.6-COINS-IN-STUDIO-SAVE

- The registered-coins block (chips of all coins, remove ×, «ثبت ارز جدید» button, exchange suggestions) now appears at the top of the Studio tab **«ذخیره‌سازی تنظیمات و ارزها»** and also in Settings (one shared component). Verified in a real headless browser: add (24→26), remove (→25), both pages in sync.

## v2.1.5-SETTINGS-ADD

- Register-new-coin now lives ONLY in Settings (removed from the top bar and the market page). Same flow: several coins at once, checked on the exchanges, saved and scanned immediately.

## v2.1.4-ADD-COINS — register new coins from anywhere

- New **«ارز جدید»** button in the top bar (every page), **«ثبت ارز جدید»** in the market page, and the coin panel is now the first block of Settings. All use the same flow: type one or several coins (`ARB OP INJ APT`, spaces/commas), each is checked on the exchanges in parallel, valid ones are saved and scanned + analysed immediately (no cache); unknown ones are reported, not fatal. New endpoint `POST /api/watchlist/add`.
- Verified in a real headless browser (header dialog, settings box, market button; list grew 24 → 30).

## v2.1.3-LIVE-AUDIT — decision-logic audit

**Bias / logic bugs fixed**
- `pro_core` mapped positive and negative scores differently (a +40 score became *bearish*, −40 stayed −40) → systematic SHORT bias. Now symmetric; the PRO layer is blended before confidence is computed; price == VWAP no longer counts as "below".
- Governor: `data_trust` was a *signed* vote → every coin got a constant bullish edge (≈ +0.11). Trust now only shrinks the edge. `margin` was always |edge| (meaningless gate) → now real one-sidedness of the evidence.
- Governor structure evidence turned a LONG *minority* into bearish evidence; fixed (net direction). WAIT timeframes keep a weak lean instead of exactly 0.
- Forecast evidence never matched (`bullish/bearish` vs `UP/DOWN`); now uses `prob_up`.
- Derivatives and context evidence used wrong keys/units (funding never read, OI read without price direction, same numbers counted twice) → now built from the direction-aware context parts, each source once.
- Governor could publish the OPPOSITE side of the multi-timeframe consensus using that consensus' grade → now a veto.
- Matrix row and coin page used different contexts (BTC correlation/ATR filter only in the matrix) → one `_ctx_full` for every path; BTC direction from fresh 4h+1h.
- Levels: the structure-aware stop/targets were overwritten by a fixed multiple, so R:R was ≈2.2 for every signal. Now structural stop + regime targets with fees/slippage, real R:R and **room to the nearest opposing level** (R) with a warning when < 1R.
- "PULLBACK" action when price already ran away from the entry zone.

**Checks** — long/short mirror-symmetry test, fuzz of the engine on 11 edge-case datasets (flat, zero volume, 1e-9 and 1e5 prices, gaps, NaN, dojis, crash): no exceptions / NaN, level order always valid; sweep of all 29 GET endpoints on the simulator. 73 offline tests.

## v2.1.2-LIVE — live data only, saved looks, coin picker

**Old/fake data (root causes fixed)**
- Scan button now forces a *real* scan: candles and prices bypass every cache, no analysis is reused (`/api/scan?force=1`). A forced scan requested during a running scan is queued instead of being silently refused.
- Automatic scans may reuse an analysis only for ≤150 s and ≤0.10 ATR price drift (was 15 min / 0.15 ATR).
- Every result carries its age; results older than `max(4 min, 2×scan interval+90 s)`, stale-kline results and restored ones are **not fresh**: they never reach the central governor, signal log, alerts, auto-trader or the top lists. A coin with <2 fresh timeframes shows an honest WAIT "داده تازه کافی نیست". Cards/headers show "داده کهنه" + price/candle source.
- Disk snapshot is no longer restored at start (opt-in `TITAN_RESTORE_SNAPSHOT=1`, and even then flagged and never used for decisions).
- A failed scan no longer leaves old data looking current (`last_error`, ageing).
- Tickers: coins missing on OKX are now filled from MEXC/Bybit/Gate/Binance (before, they silently fell back to a stale candle close); each price has a timestamp and source.
- Detail view / plan lab use the live price (plan lab used the last closed close); stale timeframes are re-fetched on demand.
- Signal log: wick-aware SL/TP evaluation from real candle extremes, stops updating after 24 h (MFE/MAE used to drift forever).
- Context (derivatives/depth) refresh starts with the stalest coins (end of list was starved). Gemini model list is current + `TITAN_GEMINI_MODELS`.
- New `/api/data/health` (age/source per coin × timeframe).

**Storage only in XXX** — background image moved from browser localStorage to `XXX/ui/`; bytecode goes to `XXX/pycache`; unique temp names for atomic writes.

**Settings** — coin picker with exchange search + top-volume suggestions, validation before saving (unknown symbols rejected), max 60 coins, only the new coin is scanned immediately, removed coins are purged. "ذخیره‌ها و بارگذاری": named saved looks (theme, interface, layout, widgets, chart, tz/calendar, background; optionally watchlist + scan interval) in `XXX/ui_presets.json`.

Tests: 68 offline tests pass (new: forced fetch, ticker fallback, reuse window, stale exclusion, wick evaluation, coin validation, saved looks, XXX-only).

## v2.1.1-NEON-STUDIO
**رفع باگ‌های رابط، کلیدها و ذخیره‌سازی**
- پوشهٔ ذخیره‌سازی از `YYY` به **`XXX`** تغییر کرد (فایل‌های پوشهٔ قدیمی `YYY` خودکار و بدون بازنویسی به `XXX` منتقل می‌شوند). حافظهٔ بایت‌کد پایتون هم داخل `XXX/pycache` نوشته می‌شود؛ بیرون از `XXX` چیزی ذخیره نمی‌شود.
- هشدار لاگ `FutureWarning: Series.fillna with 'method'` (در `app/analysis/smc.py`) رفع شد؛ هشدار تقسیم در ماتریس همبستگی هم بی‌صدا شد.
- **ریشهٔ خراب‌بودن کلیدهای on/off**: شنونده‌های کلیک با هر بار رسم دوباره ثبت می‌شدند و هر کلیک چند بار اجرا می‌شد (دو بار = بدون تغییر). حالا هر شنونده فقط یک‌بار ثبت می‌شود (`T.on` جایگزین می‌کند، `T.offAll` هنگام تغییر صفحه). کلیدها `button` واقعی با `aria-checked` شدند.
- کلیدهای جدید و واقعی‌شده: ساعت و تاریخ نوار بالا، وضعیت اسکن، زیرعنوان، دکمهٔ اسکن، هدر چسبان ارز، نوار ابزار و راهنمای نمودار، زمان فعال‌شدن سیگنال، ارقام اعشار و قالب قیمت. «تراکم» (فشرده/باز) حالا واقعاً فاصله‌ها را عوض می‌کند.
- ستون‌های داشبورد: خودکار / ۱ تا ۶. تعداد ستون واقعی از عرض صفحه محاسبه می‌شود و هیچ ویجتی از کادر یا صفحه بیرون نمی‌زند (حلقه‌ها، عقربه، جدول‌ها، ماتریس، بهترین فرصت، سلامت، روند، حال‌وهوا).
- نوار بالا مرتب شد (عنوان، وضعیت اسکن، ساعت، دکمه) و روی موبایل دو ردیف تمیز دارد.
- استودیو: انتخاب بخش‌ها به‌صورت کاشی/فهرست مرتب با آیکن، عنوان و شمارنده؛ ردیف گزینه‌ها و فهرست ویجت‌ها روی موبایل مرتب شد.

## v2.1.0-NEON-STUDIO
**معامله خودکار + یادگیری از اشتباه**
- سیگنال‌های تاییدشدهٔ حاکم (که از گیت‌ها عبور کنند) به‌صورت خودکار در صرافی آزمایشی ثبت می‌شوند (پیش‌فرض روشن، حالت «متعادل»).
- هر پوزیشن «عکس‌فوری دلایل ورود» (خانواده‌های شواهد، رژیم، اجماع، فاصله از EMA، RSI، بافت، پیش‌بینی) را نگه می‌دارد.
- پس از بسته‌شدن، کالبدشکافی نوشته می‌شود (`app/engine/lessons.py` → `XXX/lessons.json`): علت باخت/برد، هشدارهای پیش از ورود و درس به فارسی.
- گیت ورود بعدی از تاریخچهٔ واقعی می‌خواند: اشتباه تکراری (≥۴ معامله با ≤۲۵٪ برد)، ارز با دو باخت پیاپی (۱۲ ساعت استراحت)، ستاپ با میانگین R منفی و ارز با ۶ معاملهٔ اخیر بد فقط برای درجه A. هر وتو دلیل و آمارش را می‌گوید؛ بدون داده چیزی ساخته نمی‌شود.
- نتیجه در داشبورد (ویجت)، صفحهٔ معاملات، و تب «درس‌ها و ثبت خودکار» هر ارز دیده می‌شود.

**روند هر ارز (`app/analysis/trend.py`, `/api/trend/<sym>`)**
- تب «روند ارز» (اولین تب): جهت و قدرت، فاز (حرکت/اصلاح/خستگی/رنج)، ساختار HH/HL، چینش EMA، سن روند، سطوح تایید و ابطال، انتظار آماری ۴۸ کندل، چک‌لیست شواهد و ریسک‌ها؛ هر جمله با عدد پشتوانه‌اش.

**نمودار کامل‌تر**
- روندخط‌های خودکار (از سوینگ‌ها، با تعداد لمس و امتداد)، فیبوناچی آخرین موج، نقاط لمس شماره‌دار و خط شکست الگوهای ساختاری، برچسب‌های حمایت/مقاومت با قیمت، بولینگر، VWAP، ۴ EMA با دورهٔ دلخواه، ۶ نوع نمودار (شمعی، توخالی، هایکن‌آشی، میله‌ای، خطی، ناحیه‌ای).

**سرعت**
- تحلیل ۴ تایم‌فریم تا وقتی کندل بستهٔ تازه نیامده و قیمت از ۰٫۱۵ ATR جابه‌جا نشده دوباره محاسبه نمی‌شود (اسکن دوم ≈ ۱۰ برابر سریع‌تر).
- «تحلیل عمیق» از نتایج اسکن استفاده می‌کند و کش دارد (۰٫۶۵ ثانیه ← فوری).
- آخرین اسکن در `XXX/snapshot.json.gz` ذخیره می‌شود و داشبورد در همان لحظهٔ شروع پر است.

**رابط و شخصی‌سازی (استودیو)**
- منوی گروه‌بندی‌شده (تحلیل / اجرا / سیستم)، تب‌های صفحهٔ ارز در ۵ گروه (تصمیم، آینده، ساختار، داده، هوش).
- **استودیو**: ۱۶۰+ گزینه در ۱۴ دسته، ۱۷ تم آماده (۳ روشن)، رنگ‌ها، شیشه، افکت‌ها، پس‌زمینه (شفق، شبکه، مش، تصویر شخصی…)، قلم، چیدمان (جای منو: راست/چپ/بالا/پایین/مخفی)، ویجت‌های داشبورد (ترتیب با کشیدن، اندازه ۱ تا ۶ ستون، روشن/خاموش)، تنظیمات نمودار و رنگ‌های آن، پشتیبان JSON.
- افکت‌های نئونی: رادار بازار، نوار قیمت متحرک، حاشیهٔ نئونی چرخان/ضربانی، ذرات (شبکه، ماتریکس، ستاره، برف، کرم شب‌تاب، حباب)، نور دنبال‌کنندهٔ ماوس، کج‌شدن سه‌بعدی کارت‌ها، موج کلیک، شمارش متحرک اعداد، خطوط CRT، دانهٔ فیلم، گوشه‌های HUD.

**اصلاح‌های دیگر**
- ادغام خروجی SMC با ساختار قبلی، پیش‌فرض‌های سیاست خودکار، مهاجرت قدیمی‌ها، تست‌های جدید (حافظهٔ اشتباهات، روند، خطوط، کش، snapshot، شخصی‌سازی).

## v2.0.0-GLASS-CORE
**رابط کاربری (بازنویسی کامل، یک قالب)**
- همهٔ قالب‌ها، تم‌ها، چیدمان‌ها و تصاویر نمونه حذف شد؛ فقط یک رابط شیشه‌ای گرافیکی (`titan.css` + ۶ فایل JS) باقی است.
- ۷ بخش روشن: داشبورد · بازار · تحلیل ارز · سیگنال‌ها · معاملات · هسته · تنظیمات. تحلیل هر ارز ۸ تب مرتب دارد.
- نمودار جدید (Canvas): **هر کندل گذشته/جاری/آینده تاریخ و ساعت دارد** (محور زمان دو‌خطی، کراس‌هیر، تولتیپ با بازهٔ باز→بسته‌شدن، شمسی+میلادی، منطقهٔ زمانی قابل‌انتخاب).
- پیکتوگرام برای همهٔ الگوهای کندلی و ساختاری، نردبان معامله، نوارها و حلقه‌های نورانی، خط زمان هر تایم‌فریم.

**پیش‌بینی و زمان**
- **۴۸ کندل آینده برای هر تایم‌فریم** (+ کندل جاری)، هر کدام با `t` و `t_close`، مخروط ۱۰/۵۰/۹۰٪ و احتمال هر گام.
- باگ: زمان کندل‌های پیش‌بینی یک کندل جلوتر بود (از کندل در حال تشکیل محاسبه می‌شد) → از آخرین کندل **بسته** محاسبه می‌شود.
- باگ: با افق ۴۸ کندل، بازگشت به میانگین هر روند را برعکس می‌کرد → رانش پایدار در روند قوی، کشش میانگین با افت نمایی.
- هر سیگنال بلوک `timing` دارد: مبنای تحلیل، اعتبار تا کی، زمان تقریبی رسیدن به TP1/2/3 و حدضرر.
- **الگوها**: شروع، پایان تشکیل، معتبر تا (کندلی: بر اساس نوع؛ مثلث/گوه: تا رأس)، سطح ابطال/تایید، وضعیت (فعال/تاییدشده/باطل/منقضی)، هدف و ETA.

**باگ‌های هسته**
- سیگنال منتشرشده با لاگ خودش وتو می‌شد (گیت همپوشانی) و در اسکن بعد به WAIT برمی‌گشت → ادامهٔ سیگنال زنده وتو نمی‌شود.
- `smc_mod` تعریف‌نشده بود و SMC عملاً هرگز اجرا نمی‌شد؛ خروجی OB/FVG با ساختار SMC ادغام می‌شود (نه جایگزین).
- مسیر `/api/signals/log` به تابع دیگری چسبیده بود و `api_siglog` بدون route بود.
- `closed_only` ۸٪ آخر کندل در حال تشکیل را بسته حساب می‌کرد.
- حالت WAIT اکنون سناریوی مشروط دوطرفه با شرط قیمتی و زمان بررسی دارد.

**هسته مرکزی (`app/core.py`)**
- ثبت نقش و وظایف ۱۶ بخش، اندازه‌گیری هر فراخوانی، `guard` برای اجرای ایمن، روشن/خاموش‌کردن بخش‌های اختیاری، خط لولهٔ جریان، رویدادها و سلامت کل (`/api/core`).

**ذخیره‌سازی**
- همهٔ داده، حافظه، لاگ، تنظیمات و کلیدها فقط در پوشهٔ **XXX**؛ پوشه‌های قدیمی (XXX/WWW/LLL/JJJ/TTT) یک‌بار به XXX منتقل می‌شوند.

**ابزار و تست**
- `tools/sim_server.py`: اجرای کامل داشبورد با دادهٔ مصنوعی بدون اینترنت. تست‌های قدیمی به‌روز و ۶ تست جدید اضافه شد.

## v1.7.2-UI-OVERLAP-SMC
- **ویجت یادگیری حاکم (UI)**: `W.learn` + داده `/api/learn` — نمایش reliability هر خانواده، نرخ برد، وضعیت کالیبراسیون
- **گیت همپوشانی/کول‌داون همان‌سمت**: `learn.same_side_overlap` از siglog (۴۵د، سقف ۴ سیگنال باز همان‌سمت)
- **SMC سبک از V84 technicals_core**:
  - `app/analysis/smc.py` — Order Block / Fair Value Gap روی dataframe محلی
  - همبستگی BTC (Pearson) + فیلتر soft برای آلت‌های high-beta در نوسان بالا
  - boost/هشدار در technicals و وتوی soft در Governor
- ویجت Governor: پشتیبانی، مخالف، تضاد، نزدیک‌ترین OB/FVG

## v1.7.1-LEARN-LITE
- حلقه یادگیری سبک فایل‌محور + گیت R:R + SCORE_ECHO_CAP + رفع alias verdict/cons

## v1.7.0-V84-HARDENED
- آستانه‌های نامتقارن SHORT، support/contradiction، وزن‌های V84

## v1.6.1-GOV-INTEGRATED
- یکپارچگی x10/x12 در Governor
