"""Multi-timeframe fusion: weighted consensus, higher-TF veto, coherent verdict + narrative."""
from __future__ import annotations
from typing import Any
import pandas as pd

from app.config import TF_WEIGHT, SIDE_THRESHOLD, FORECAST_CANDLES
from app.analysis.technicals import analyze
from app.analysis.forecast import build_forecast
from app.analysis.grade import fuse, grade_from
from app.engine.governor import govern

REGIME_FA = {"trend": "روندی", "range": "رنج", "neutral": "گذار", "unknown": "نامشخص"}
SIDE_SHORT = {"LONG": "خرید", "SHORT": "فروش", "WAIT": "انتظار"}
SIDE_FA = {"LONG": "خرید (LONG)", "SHORT": "فروش (SHORT)", "WAIT": "انتظار"}


class _Pre:
    """Adapter so a cached signal dict (from the scan) behaves like a freshly analysed Signal."""
    def __init__(self, d: dict):
        self._d = d
        for k, v in d.items():
            setattr(self, k, v)

    def to_dict(self) -> dict:
        return self._d


def deep_analyze(frames: dict[str, pd.DataFrame], symbol: str, primary_tf: str = "1h",
                 prices: dict[str, float] | None = None, ctx: dict | None = None,
                 pre_sigs: dict | None = None, pre_fcs: dict | None = None) -> dict[str, Any]:
    """`pre_sigs` / `pre_fcs` (tf -> dict from the scan cache) skip the expensive per-timeframe analysis and projection."""
    prices = prices or {}
    sigs, fcs = {}, {}
    for tf, df in frames.items():
        if df is None or len(df) < 60:
            continue
        if pre_sigs and tf in pre_sigs and pre_fcs and tf in pre_fcs:
            sigs[tf] = _Pre(pre_sigs[tf])
            fcs[tf] = pre_fcs[tf]
            continue
        s = analyze(df, symbol, tf, price=prices.get(tf))
        sigs[tf] = s
        lv = {"entry": s.entry, "stop": s.stop, "tp1": s.tp1, "tp2": s.tp2, "tp3": s.tp3} if s.side != "WAIT" else None
        fcs[tf] = build_forecast(df, s.side, tf, symbol, lv)
    if not sigs:
        return {"symbol": symbol, "primary_tf": primary_tf, "signal": None, "all_tf": {}, "verdict": "WAIT",
                "consensus_score": 0, "conviction": 0, "agreement": "mixed", "regime": "unknown", "narrative": "داده کافی نیست"}

    consensus, side, note = fuse({t: x.score for t, x in sigs.items()}, (ctx or {}).get("bias", 0.0))
    wsum = sum(TF_WEIGHT.get(t, .2) for t in sigs)
    sides = [s.side for s in sigs.values()]
    ln, sn = sides.count("LONG"), sides.count("SHORT")
    agreement = ("strong_long" if ln >= 3 else "strong_short" if sn >= 3 else
                 "lean_long" if ln > sn else "lean_short" if sn > ln else "mixed")
    aligned = sum(TF_WEIGHT.get(t, .2) for t, s in sigs.items() if (s.score > 10) == (consensus > 0) and abs(s.score) > 10) / wsum
    conviction = round(min(0.97, 0.55 * min(1, abs(consensus) / 70) + 0.45 * aligned), 3)

    ptf = primary_tf if primary_tf in sigs else next(iter(sigs))
    prim = sigs[ptf]
    plan = prim
    if side in ("LONG", "SHORT") and prim.side != side:
        plan = analyze(frames[ptf], symbol, ptf, price=prices.get(ptf), force_side=side)
    regime = prim.regime
    pf = fcs[ptf]
    if side in ("LONG", "SHORT"):                                   # re-run the path statistics for the plan actually proposed
        pf = build_forecast(frames[ptf], side, ptf, symbol,
                            {"entry": plan.entry, "stop": plan.stop, "tp1": plan.tp1, "tp2": plan.tp2, "tp3": plan.tp3})
        fcs[ptf] = pf
    sd = {t: x.to_dict() for t, x in sigs.items()}
    if side in ("LONG", "SHORT") and plan is not prim:
        sd[ptf] = plan.to_dict()
    gr = grade_from(sd, fcs, side, consensus, ptf, ctx)
    # Central Governor — sole publisher over fuse side
    gov = govern(sd, fcs, ctx, gr if isinstance(gr, dict) else {}, symbol=symbol)
    pub_side = gov.get("side") or "WAIT"
    if not gov.get("published"):
        pub_side = "WAIT"

    parts = [f"رژیم {REGIME_FA.get(regime, regime)} · اجماع وزنی {consensus:+.0f} → {SIDE_FA[side]}"]
    if note:
        parts.append(note)
    if gov.get("vetoes"):
        parts.append("وتوی حاکم: " + " · ".join(gov["vetoes"][:3]))
    if gov.get("reasons"):
        parts.append("حاکم: " + " · ".join(gov["reasons"][:3]))
    # V84-hardened diagnostics
    if gov.get("published") and gov.get("support") is not None:
        parts.append(f"پشتیبانی {gov.get('support')} · تضاد {gov.get('contradiction', 0):.0%}")
    parts.append("تایم‌فریم‌ها: " + " | ".join(f"{t}: {SIDE_SHORT[s.side]} {s.score:+.0f}" for t, s in sigs.items()))
    parts.append(f"احتمال صعود ({ptf}، {pf.get('n_future') or FORECAST_CANDLES} کندل) {pf['prob_up'] * 100:.0f}٪ · حرکت میانه {pf['expected_move_pct']:+.2f}٪")
    if pub_side != "WAIT":
        parts.append(f"ورود {plan.entry} · حدضرر {plan.stop} · اهداف {plan.tp1}/{plan.tp2}/{plan.tp3} · R:R {plan.risk_reward}")
    if ctx and ctx.get("parts"):
        parts.append(f"بافت بازار {ctx['bias']:+.2f}: " + " · ".join(p_["t"] for p_ in sorted(ctx["parts"], key=lambda x: -abs(x["v"] * x["w"]))[:2]))
    if prim.reasons:
        parts.append("دلایل: " + " · ".join(prim.reasons[:4]))

    # If governor publishes WAIT, keep plan levels but mark verdict WAIT for consistency
    out_signal = plan.to_dict()
    if pub_side == "WAIT" and out_signal.get("side") in ("LONG", "SHORT"):
        out_signal = dict(out_signal)
        out_signal["side"] = "WAIT"
        out_signal["warnings"] = list(out_signal.get("warnings") or []) + list(gov.get("vetoes") or [])

    # both-side plans + the price triggers that would turn a WAIT into a trade (so a WAIT is never an empty card)
    plans: dict = {}
    for sd_ in ("LONG", "SHORT"):
        try:
            pl = prim if prim.side == sd_ else (plan if plan.side == sd_ else analyze(frames[ptf], symbol, ptf, price=prices.get(ptf), force_side=sd_))
            plans[sd_] = {"entry": pl.entry, "stop": pl.stop, "tp1": pl.tp1, "tp2": pl.tp2, "tp3": pl.tp3, "rr": pl.risk_reward,
                          "entry_zone": (pl.levels or {}).get("entry_zone")}
        except Exception:                                                  # noqa: BLE001
            continue
    lv0, px0 = prim.levels or {}, float(prim.entry or 0)
    res_up = sorted(x for x in (lv0.get("resistance") or []) if px0 and x > px0 * 1.0005)
    sup_dn = sorted((x for x in (lv0.get("support") or []) if px0 and x < px0 * 0.9995), reverse=True)
    triggers = {"LONG": {"above": res_up[0] if res_up else (prim.indicators or {}).get("donch_hi")},
                "SHORT": {"below": sup_dn[0] if sup_dn else (prim.indicators or {}).get("donch_lo")}}
    return {"plans": plans, "triggers": triggers, "symbol": symbol, "primary_tf": ptf, "signal": out_signal, "primary": prim.to_dict(),
            "forecast": pf, "all_tf": {t: s.to_dict() for t, s in sigs.items()}, "all_forecasts": fcs, "grade": gr,
            "consensus_score": round(consensus, 1), "conviction": conviction, "verdict": pub_side, "veto": note,
            "agreement": agreement, "regime": regime, "narrative": " — ".join(parts),
            "governor": gov, "fuse_side": side,
            "ctx": ctx, "long_count": ln, "short_count": sn, "wait_count": sides.count("WAIT")}
