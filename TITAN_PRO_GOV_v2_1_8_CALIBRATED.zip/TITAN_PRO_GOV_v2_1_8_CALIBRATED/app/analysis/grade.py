"""Multi-timeframe fusion helpers + an explainable setup grade (A-D).
The grade is a checklist, not a probability: every point is shown to the user with its reason."""
from __future__ import annotations
from app.config import TF_WEIGHT, SIDE_THRESHOLD as TH


CTX_SHIFT = 10.0          # max consensus points the derivatives/book/sentiment context may add or remove


def fuse(scores: dict[str, float], ctx_bias: float = 0.0) -> tuple[float, str, str]:
    """Hierarchical multi-TF decision:
    1d = market direction, 4h = structure, 1h = setup, 15m = timing.
    Higher-TF opposition hard-vetoes trend entries; mean-reversion still possible
    only when HTF is flat (not strongly opposed)."""
    wsum = sum(TF_WEIGHT.get(t, .2) for t in scores)
    cons = sum(TF_WEIGHT.get(t, .2) * s for t, s in scores.items()) / wsum if wsum else 0.0
    cons += CTX_SHIFT * max(-1.0, min(1.0, ctx_bias))
    side = "LONG" if cons >= TH else "SHORT" if cons <= -TH else "WAIT"
    note = ""
    htf = {t: scores[t] for t in ("4h", "1d") if t in scores}
    if side != "WAIT" and htf:
        opp_hard = [t for t, b in htf.items() if (b <= -TH and side == "LONG") or (b >= TH and side == "SHORT")]
        if len(opp_hard) == len(htf):
            note, side = "تایم‌فریم‌های بزرگ‌تر خلاف جهت‌اند → وتو", "WAIT"
        elif opp_hard and abs(cons) < TH + 12:
            # Soft conflict with only moderate consensus → wait
            note, side = f"تعارض با {','.join(opp_hard)} و اجماع ضعیف → انتظار", "WAIT"
        elif "1d" in htf:
            d1 = htf["1d"]
            if (side == "LONG" and d1 < -TH * 0.7) or (side == "SHORT" and d1 > TH * 0.7):
                note, side = "جهت روزانه مخالف است → وتو", "WAIT"
    # 15m alone must not drive a trade against 1h
    if side != "WAIT" and "1h" in scores and "15m" in scores:
        if abs(scores.get("15m", 0)) > abs(scores.get("1h", 0)) + 15:
            if (scores["1h"] > 8 and side == "SHORT") or (scores["1h"] < -8 and side == "LONG"):
                note, side = "۱۵م برخلاف ساختار ۱ساعته است → انتظار", "WAIT"
    # strongly opposed positioning/book/sentiment with only a moderate consensus: do not fight the crowd's squeeze risk
    if side != "WAIT" and abs(cons) < TH + 15 and ((side == "LONG" and ctx_bias <= -0.45) or (side == "SHORT" and ctx_bias >= 0.45)):
        note, side = "بافت بازار (فاندینگ/OI/دفتر سفارش/احساسات) به‌شدت مخالف است → انتظار", "WAIT"
    return cons, side, note


def grade_from(sigs: dict[str, dict], fcs: dict[str, dict], side: str, cons: float, ptf: str = "1h", ctx: dict | None = None) -> dict:
    """sigs/fcs are the dict forms (Signal.to_dict(), forecast_summary())."""
    if side == "WAIT" or ptf not in sigs:
        return {"grade": "—", "points": 0, "why": [], "aligned": 0, "side": side}
    pts, why = 0, []

    def add(n, text):
        nonlocal pts
        pts += n
        why.append({"p": n, "t": text})

    a = abs(cons)
    if a >= 55: add(2, f"اجماع قوی ({cons:+.0f})")
    elif a >= 42: add(1, f"اجماع متوسط ({cons:+.0f})")
    else: add(0, f"اجماع ضعیف ({cons:+.0f})")
    same = [t for t, s in sigs.items() if s["side"] == side]
    opp = [t for t, s in sigs.items() if s["side"] not in (side, "WAIT")]
    big_opp = [t for t in opp if t in ("4h", "1d")]
    if len(same) >= 3: add(2, f"{len(same)} تایم‌فریم هم‌جهت")
    elif len(same) == 2: add(1, "۲ تایم‌فریم هم‌جهت")
    else: add(0, "فقط یک تایم‌فریم هم‌جهت")
    if big_opp: add(-2, "تایم‌فریم بزرگ مخالف: " + "،".join(big_opp))
    p = sigs[ptf]
    if p.get("regime") == "trend" and p["side"] == side: add(1, "رژیم روندی و هم‌جهت")
    if p.get("agree", 0) >= 0.75: add(1, f"هم‌سویی مولفه‌ها {p['agree'] * 100:.0f}٪")
    f = fcs.get(ptf) or {}
    if f.get("alignment") == "aligned": add(1, f"پیش‌بینی {int(f.get('n_future') or f.get('n') or 48)} کندل هم‌جهت")
    elif f.get("alignment") == "divergent": add(-1, f"پیش‌بینی {int(f.get('n_future') or f.get('n') or 48)} کندل مخالف")
    e = f.get("edge") if p["side"] == side else None
    if e:
        if e["p_tp1"] >= 0.5: add(1, f"احتمال رسیدن به TP1 {e['p_tp1'] * 100:.0f}٪")
        if e["ev_r"] < -0.15: add(-1, f"امید ریاضی شبیه‌سازی منفی ({e['ev_r']:+.2f}R)")
    ps = ((p.get("extras") or {}).get("pat") or {})
    if ps.get("items") and abs(ps.get("score", 0)) >= 35:
        aligned = (ps["score"] > 0) == (side == "LONG")
        add(1 if aligned else -1, ("الگوی تاییدکننده: " if aligned else "الگوی مخالف: ") + "، ".join(ps["items"][:2]))
    rr = p.get("risk_reward", 0)
    if rr >= 2: add(1, f"R:R خوب ({rr:.1f})")
    elif rr < 1.2: add(-1, f"R:R ضعیف ({rr:.1f})")
    if len(p.get("warnings", [])) >= 3: add(-1, "هشدارهای متعدد")
    # complementary layers (x10 quality / x12 alignment) — PRO-clean strength
    x10 = (p.get("extras") or {}).get("x10") or {}
    x12 = (p.get("extras") or {}).get("x12") or {}
    q = x10.get("quality")
    try:
        q = float(q) if q is not None else None
    except (TypeError, ValueError):
        q = None
    if q is not None:
        if q >= 65: add(1, f"کیفیت بازار خوب (x10={q:.0f})")
        elif q < 30: add(-1, f"کیفیت بازار ضعیف (x10={q:.0f})")
    try:
        timing = float(x10.get("timing") or 0.0)
        if side == "LONG" and timing >= 30: add(1, f"زمان‌بندی ورود مناسب ({timing:.0f})")
        elif side == "SHORT" and timing <= -30: add(1, f"زمان‌بندی ورود مناسب ({timing:.0f})")
        elif side == "LONG" and timing <= -40: add(-1, f"زمان‌بندی مخالف ({timing:.0f})")
        elif side == "SHORT" and timing >= 40: add(-1, f"زمان‌بندی مخالف ({timing:.0f})")
    except (TypeError, ValueError):
        pass
    try:
        sc12 = float(x12.get("score") or 0.0)
        aligned12 = (sc12 > 0 and side == "LONG") or (sc12 < 0 and side == "SHORT")
        if abs(sc12) >= 25:
            add(1 if aligned12 else -1, ("لایه x12 هم‌جهت: " if aligned12 else "لایه x12 مخالف: ") + f"{sc12:+.0f}")
    except (TypeError, ValueError):
        pass
    if ctx:
        bias = ctx.get("bias", 0.0) * (1 if side == "LONG" else -1)
        top = max(ctx.get("parts") or [{}], key=lambda x: abs(x.get("v", 0) * x.get("w", 0)), default={}).get("t", "")
        if bias >= 0.2: add(1, "بافت بازار هم‌جهت: " + top)
        elif bias <= -0.2: add(-1, "بافت بازار مخالف: " + top)
        if ctx.get("liq_ok") is False: add(-1, "نقدینگی/اسپرد نامناسب")
    g = "A" if pts >= 7 else "B" if pts >= 4 else "C" if pts >= 2 else "D"
    return {"grade": g, "points": pts, "why": why, "aligned": len(same), "side": side}
