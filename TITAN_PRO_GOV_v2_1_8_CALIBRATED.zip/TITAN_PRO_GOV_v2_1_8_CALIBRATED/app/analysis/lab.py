"""TITAN Coin Lab — one deep, coherent report per coin.

Takes everything the engine knows (per-timeframe signals + forecasts, the multi-timeframe fusion, order-book / derivatives,
walk-forward evidence, the x10 layer) and turns it into:
  * a SECTION × TIMEFRAME matrix (trend, momentum, volume/flow, structure, levels, volatility, patterns, oscillators,
    quality, forecast) where every cell has a score, a side and a Persian opinion,
  * one unified opinion per timeframe (scalp / setup / structure / macro),
  * one final verdict with an explicit confidence breakdown, action, entry/exit plan, risks and invalidation rules.
Pure functions: no network, no randomness. Every part is defensive so a missing input only removes that part.
"""
from __future__ import annotations
from typing import Any

from app.config import TF_WEIGHT, SIDE_THRESHOLD

TF_ROLE = {"15m": "تایمینگ / اسکالپ", "1h": "ستاپ معامله", "4h": "ساختار روند", "1d": "جهت کلان"}
SIDE_FA = {"LONG": "خرید", "SHORT": "فروش", "WAIT": "صبر"}
SECTIONS = [  # id, name, directional?, weight
    ("trend", "روند", True, 1.30), ("momentum", "مومنتوم", True, 1.05), ("volume", "حجم و جریان پول", True, 0.95),
    ("structure", "ساختار و SMC", True, 1.15), ("levels", "سطوح و فضای حرکت", True, 0.90), ("pattern", "الگوها", True, 0.55),
    ("osc", "اسیلاتورها و میانگین‌ها", True, 0.75), ("forecast", "پیش‌بینی آماری", True, 0.95),
    ("volat", "نوسان و فشردگی", False, 0.0), ("quality", "کیفیت بازار (x10)", False, 0.0),
]
SEC_NAME = {k: n for k, n, _, _ in SECTIONS}


def _clip(x: float, a: float = -100.0, b: float = 100.0) -> float:
    return float(max(a, min(b, x)))


def _side(score: float, th: float = 14.0) -> str:
    return "LONG" if score >= th else "SHORT" if score <= -th else "WAIT"


def _ltr(v: Any) -> str:
    """Isolate a number run so it keeps its order inside right-to-left Persian text."""
    return "\u2066" + str(v) + "\u2069"


def _fmt(v: Any, nd: int = 2) -> str:
    try:
        return f"{float(v):.{nd}f}"
    except (TypeError, ValueError):
        return "—"


def _grp(sig: dict, group: str, skip_x: bool = False) -> tuple[float, list[dict]]:
    cs = [c for c in sig.get("components", []) if c.get("g") == group and not (skip_x and str(c.get("k", "")).startswith("x_"))]
    tw = sum(c["w"] for c in cs) or 1e-9
    return _clip(sum(c["w"] * c["s"] for c in cs) / tw * 100), cs


def _top(cs: list[dict], n: int = 3) -> list[str]:
    return [c["t"] for c in sorted(cs, key=lambda c: -abs(c["s"] * c["w"])) if abs(c["s"]) >= 0.25][:n]


def _verdict_word(score: float) -> str:
    a = abs(score)
    mag = "قوی" if a >= 55 else "متوسط" if a >= 30 else "ضعیف"
    return ("صعودی " if score > 0 else "نزولی ") + mag if a >= 14 else "خنثی"


# ───────────────────────────── per-section opinions ─────────────────────────────
def sections_for(sig: dict, fc: dict | None, px: float | None = None) -> dict[str, dict]:
    """Return {section_id: {score, side, text, facts, kind}} for one timeframe."""
    fc = fc or {}
    ind, ex, lv = sig.get("indicators") or {}, sig.get("extras") or {}, sig.get("levels") or {}
    px = px or sig.get("entry") or 0.0
    atr = ind.get("atr") or (px * 0.01 if px else 1.0)
    out: dict[str, dict] = {}

    # trend
    sc, cs = _grp(sig, "trend")
    facts = _top(cs, 3)
    adx = ind.get("adx", 0)
    txt = f"روند {_verdict_word(sc)}"
    txt += " و قدرت روند بالاست (ADX %.0f)" % adx if adx >= 25 else " ولی قدرت روند کم است (ADX %.0f)" % adx if adx < 18 else " (ADX %.0f)" % adx
    out["trend"] = {"score": sc, "text": txt, "facts": facts, "kind": "dir"}

    # momentum
    sc, cs = _grp(sig, "momentum")
    facts = _top(cs, 3)
    rsi = ind.get("rsi", 50)
    txt = f"مومنتوم {_verdict_word(sc)}"
    if rsi >= 70: txt += "؛ RSI اشباع خرید (%.0f) و احتمال خستگی حرکت" % rsi
    elif rsi <= 30: txt += "؛ RSI اشباع فروش (%.0f) و احتمال بازگشت" % rsi
    else: txt += " (RSI %.0f)" % rsi
    out["momentum"] = {"score": sc, "text": txt, "facts": facts, "kind": "dir"}

    # volume / flow
    sc, cs = _grp(sig, "volume")
    fl = ex.get("flow") or {}
    facts = _top(cs, 2)
    if fl:
        bs = fl.get("buy_share")
        if bs is not None:
            sc = _clip(sc * 0.7 + (bs - 0.5) * 200 * 0.3)
            facts.append(f"سهم خرید ۲۰ کندل اخیر {bs * 100:.0f}٪")
        if fl.get("div") == "bull": facts.append("واگرایی صعودی CVD"); sc = _clip(sc + 10)
        if fl.get("div") == "bear": facts.append("واگرایی نزولی CVD"); sc = _clip(sc - 10)
    txt = f"جریان پول و حجم {_verdict_word(sc)}"
    if fl.get("rel_vol") is not None:
        txt += f" · حجم نسبی {_fmt(fl.get('rel_vol'), 1)}×"
    out["volume"] = {"score": sc, "text": txt, "facts": facts[:4], "kind": "dir"}

    # structure / SMC
    sc, cs = _grp(sig, "structure")
    sm = ex.get("smc") or {}
    facts = _top(cs, 2)
    if sm.get("structure"): facts.append(sm["structure"].get("label", ""))
    if sm.get("range"): facts.append("قیمت در ناحیهٔ " + {"premium": "گران (Premium)", "discount": "ارزان (Discount)"}.get(sm["range"].get("zone"), "تعادل"))
    if sm.get("sweep"): facts.append(sm["sweep"].get("note", "جمع‌آوری نقدینگی"))
    z = (sm.get("range") or {}).get("zone")
    if z == "discount": sc = _clip(sc + 6)
    elif z == "premium": sc = _clip(sc - 6)
    out["structure"] = {"score": sc, "text": f"ساختار بازار {_verdict_word(sc)}" + (f" · آخرین رویداد {sm['event']['kind']} {'صعودی' if sm['event']['dir'] == 'up' else 'نزولی'}" if sm.get("event") else ""),
                        "facts": [f for f in facts if f][:4], "kind": "dir"}

    # levels / room to move
    zones = lv.get("zones") or []
    res = sorted([z for z in zones if z.get("kind") == "R"], key=lambda z: z["p"])
    sup = sorted([z for z in zones if z.get("kind") == "S"], key=lambda z: -z["p"])
    up_room = (res[0]["p"] - px) / atr if res and atr else 6.0
    dn_room = (px - sup[0]["p"]) / atr if sup and atr else 6.0
    sc = _clip((min(up_room, 8) - min(dn_room, 8)) / 8 * 100)
    facts = []
    if res: facts.append(f"نزدیک‌ترین مقاومت {res[0]['p']:.6g} ({up_room:.1f} ATR بالاتر)")
    if sup: facts.append(f"نزدیک‌ترین حمایت {sup[0]['p']:.6g} ({dn_room:.1f} ATR پایین‌تر)")
    vp = ex.get("vp") or {}
    if vp.get("poc"):
        pos = "بالای" if px > vp["poc"] else "زیر"
        facts.append(f"قیمت {pos} POC ({vp['poc']:.6g})")
        sc = _clip(sc + (8 if px > vp["poc"] else -8))
    fib = ex.get("fib") or {}
    if fib.get("near"): facts.append(f"نزدیک فیبو {fib['near']['r']}")
    txt = "فضای حرکت به سمت بالا بیشتر است" if sc >= 14 else "فضای حرکت به سمت پایین بیشتر است" if sc <= -14 else "فضای حرکت دو سمت متعادل است"
    out["levels"] = {"score": sc, "text": txt, "facts": facts[:4], "kind": "dir"}

    # patterns
    sc, cs = _grp(sig, "pattern")
    pt = ex.get("pat") or {}
    items = pt.get("items") or []
    sc = _clip(sc * 0.5 + (pt.get("score") or 0) * 0.5)
    out["pattern"] = {"score": sc, "text": ("الگوی غالب: " + "، ".join(items[:2])) if items else "الگوی معناداری فعال نیست", "facts": (items[:3] or _top(cs, 2)), "kind": "dir"}

    # oscillators
    o = ex.get("osc") or {}
    sc = _clip((o.get("all_score") or 0) * 1.4) if o else 0.0
    out["osc"] = {"score": sc, "text": (f"رای‌گیری: {o.get('all_label', '—')}" if o else "داده‌ای نیست"),
                  "facts": [f"اسیلاتورها {o.get('osc_buy', 0)} خرید / {o.get('osc_sell', 0)} فروش", f"میانگین‌ها {o.get('ma_buy', 0)} خرید / {o.get('ma_sell', 0)} فروش"] if o else [], "kind": "dir"}

    # forecast
    if fc and fc.get("prob_up") is not None:
        pu = fc["prob_up"]
        sc = _clip((pu - 0.5) * 200 * 1.4)
        facts = [f"احتمال صعود {pu * 100:.0f}٪", f"حرکت میانهٔ مورد انتظار {fc.get('expected_move_pct', 0):+.2f}٪", f"σ ≈ {fc.get('sigma_pct', 0):.2f}٪"]
        e = fc.get("edge") or {}
        if e: facts.append(f"EV معامله {e.get('ev_r', 0):+.2f}R · P(TP1) {e.get('p_tp1', 0) * 100:.0f}٪")
        txt = f"شبیه‌سازی آماری {_verdict_word(sc)}" + (" و هم‌جهت با سیگنال" if fc.get("alignment") == "aligned" else " و مخالف سیگنال" if fc.get("alignment") == "divergent" else "")
        out["forecast"] = {"score": sc, "text": txt, "facts": facts, "kind": "dir"}
    else:
        out["forecast"] = {"score": 0.0, "text": "پیش‌بینی در دسترس نیست", "facts": [], "kind": "dir"}

    # volatility (state)
    x10 = ex.get("x10") or {}
    it = x10.get("items") or {}
    facts = []
    sq = ind.get("squeeze")
    if sq: facts.append("فشردگی بولینگر فعال")
    if it.get("vol_exp"): facts.append(it["vol_exp"]["t"])
    if it.get("sqz"): facts.append(it["sqz"]["t"])
    atrp = ind.get("atr_pct", 0)
    state = "بسیار پرنوسان" if atrp > 5 else "پرنوسان" if atrp > 2.5 else "عادی" if atrp > 0.6 else "کم‌نوسان"
    out["volat"] = {"score": 0.0, "text": f"نوسان {state} (ATR {atrp:.2f}٪)" + (" · آمادهٔ حرکت انفجاری" if sq else ""), "facts": facts[:4], "kind": "state"}

    # quality (state) — hurst / chop / linreg
    if x10:
        q = x10.get("quality", 50)
        fq = [it[k]["t"] for k in ("hurst", "chop", "linreg") if it.get(k)]
        out["quality"] = {"score": 0.0, "q": q, "text": f"{x10.get('quality_label', '')} ({q:.0f}/100) · {x10.get('timing_label', '')}", "facts": fq[:3], "kind": "state"}
    else:
        out["quality"] = {"score": 0.0, "q": 50, "text": "داده‌ای نیست", "facts": [], "kind": "state"}

    for k, v in out.items():
        v["score"] = round(v["score"], 1)
        v["side"] = _side(v["score"]) if v["kind"] == "dir" else "STATE"
    return out


# ───────────────────────────── micro-structure ─────────────────────────────
def micro_opinion(micro: dict | None) -> dict:
    micro = micro or {}
    dp, dv = micro.get("depth") or {}, micro.get("derivs") or {}
    score, facts = 0.0, []
    if dp.get("ok"):
        imb = dp.get("imb_1pct", 0)
        score += _clip(imb * 120, -60, 60)
        facts.append(f"عدم‌توازن دفتر سفارش ±۱٪: {imb * 100:+.0f}٪ ({'خریدار' if imb > 0 else 'فروشنده'} غالب)")
        if dp.get("spread_pct") is not None and dp["spread_pct"] > 0.08: facts.append(f"اسپرد بالا ({dp['spread_pct']:.3f}٪)؛ نقدشوندگی ضعیف")
    if dv.get("ok"):
        fnd = dv.get("funding_pct") or 0
        if fnd > 0.05: score -= 18; facts.append(f"فاندینگ بالا ({fnd:.3f}٪)؛ لانگ‌ها شلوغ‌اند (ریسک لیکویید لانگ)")
        elif fnd < -0.03: score += 18; facts.append(f"فاندینگ منفی ({fnd:.3f}٪)؛ شورت‌ها شلوغ‌اند (ریسک شورت‌اسکوییز)")
        else: facts.append(f"فاندینگ عادی ({fnd:.3f}٪)")
        lsb = dv.get("ls_buy")
        if lsb is not None:
            pct = lsb * 100 if lsb <= 1 else lsb
            if pct > 62: score -= 8; facts.append(f"نسبت لانگ به شورت بالا ({pct:.0f}٪ لانگ)؛ نشانهٔ ازدحام")
            elif pct < 40: score += 8; facts.append(f"نسبت لانگ پایین ({pct:.0f}٪)؛ ازدحام شورت")
        if dv.get("oi_usd"): facts.append(f"OI ≈ ${dv['oi_usd'] / 1e6:.0f}M")
    ok = bool(dp.get("ok") or dv.get("ok"))
    score = _clip(score)
    return {"ok": ok, "score": round(score, 1), "side": _side(score, 12) if ok else "WAIT", "facts": facts,
            "text": ("ریزساختار بازار " + _verdict_word(score)) if ok else "دفتر سفارش و مشتقات در دسترس نیست (فقط تحلیل کندلی)"}


# ───────────────────────────── per-timeframe unified opinion ─────────────────────────────
def tf_opinion(tf: str, sig: dict, fc: dict | None, px: float | None = None) -> dict:
    secs = sections_for(sig, fc, px)
    tw = sum(w for k, n, d, w in SECTIONS if d)
    score = sum(secs[k]["score"] * w for k, n, d, w in SECTIONS if d) / tw
    side = _side(score, 18)
    dir_secs = [(k, secs[k]) for k, n, d, w in SECTIONS if d]
    same = [k for k, s in dir_secs if s["side"] == side] if side != "WAIT" else []
    opp = [k for k, s in dir_secs if s["side"] not in (side, "WAIT")] if side != "WAIT" else []
    agree = len(same) / len(dir_secs)
    q = secs["quality"].get("q", 50)
    conf = max(0.05, min(0.95, 0.15 + 0.45 * min(1, abs(score) / 60) + 0.25 * agree + 0.15 * (q / 100)))
    if side == "WAIT":
        conf *= 0.6
    best = sorted(dir_secs, key=lambda kv: -abs(kv[1]["score"]) * (1 if (kv[1]["score"] > 0) == (score > 0) else 0.0))[:2]
    sup_txt = "، ".join(SEC_NAME[k] for k, _ in best if abs(_["score"]) >= 20) or "—"
    parts = [f"{tf} ({TF_ROLE.get(tf, '')}): {SIDE_FA[side]} با امتیاز ترکیبی {score:+.0f}"]
    if same: parts.append(f"{len(same)} از {len(dir_secs)} بخش هم‌جهت‌اند (قوی‌ترین: {sup_txt})")
    if opp: parts.append("مخالف: " + "، ".join(SEC_NAME[k] for k in opp[:3]))
    if sig.get("regime"): parts.append("رژیم " + {"trend": "روندی", "range": "رنج", "neutral": "گذار"}.get(sig["regime"], sig["regime"]))
    return {"tf": tf, "role": TF_ROLE.get(tf, ""), "score": round(score, 1), "side": side, "confidence": round(conf, 3), "agree": round(agree, 2),
            "same": same, "opp": opp, "quality": q, "sections": secs, "text": " · ".join(parts),
            "core_side": sig.get("side"), "core_score": sig.get("score"), "core_conf": sig.get("confidence")}


# ───────────────────────────── the full report ─────────────────────────────
def build(symbol: str, sigs: dict[str, dict], fcs: dict[str, dict], deep: dict, micro: dict | None = None,
          evidence: dict | None = None, plan_lab: dict | None = None, price: float | None = None, bt: dict | None = None) -> dict:
    tfs = [t for t in ("15m", "1h", "4h", "1d") if t in sigs]
    if not tfs:
        return {"symbol": symbol, "ok": False, "error": "داده کافی برای تحلیل عمیق نیست"}
    per = {t: tf_opinion(t, sigs[t], fcs.get(t), price) for t in tfs}
    mic = micro_opinion(micro)

    # matrix: section × timeframe
    matrix = [{"id": k, "name": n, "kind": "dir" if d else "state",
               "cells": {t: {"score": per[t]["sections"][k]["score"], "side": per[t]["sections"][k]["side"], "text": per[t]["sections"][k]["text"],
                             "facts": per[t]["sections"][k]["facts"], "q": per[t]["sections"][k].get("q")} for t in tfs}} for k, n, d, w in SECTIONS]
    # section-level consensus across timeframes (TF-weighted)
    wsum = sum(TF_WEIGHT.get(t, .2) for t in tfs)
    for row in matrix:
        if row["kind"] == "dir":
            sc = sum(TF_WEIGHT.get(t, .2) * row["cells"][t]["score"] for t in tfs) / wsum
            row["score"], row["side"] = round(sc, 1), _side(sc)
            row["text"] = f"{row['name']} در مجموع تایم‌فریم‌ها {_verdict_word(sc)}"
            sides = {row["cells"][t]["side"] for t in tfs} - {"WAIT"}
            row["conflict"] = len(sides) > 1
        else:
            row["score"], row["side"], row["conflict"] = 0.0, "STATE", False
            row["text"] = row["cells"][tfs[0] if "1h" not in tfs else "1h"]["text"]

    verdict, cons = deep.get("verdict", "WAIT"), float(deep.get("consensus_score") or 0)
    ptf = deep.get("primary_tf") if deep.get("primary_tf") in tfs else ("1h" if "1h" in tfs else tfs[0])
    sig = deep.get("signal") or sigs[ptf]
    lvl = sig.get("levels") or {}
    x10 = (sig.get("extras") or {}).get("x10") or {}
    quality, timing = float(x10.get("quality", 50)), float(x10.get("timing", 0))
    d = 1 if verdict == "LONG" else -1 if verdict == "SHORT" else 0
    timing_fit = timing * d

    # unified score: core consensus (60%) + section matrix (30%) + microstructure (10%)
    dir_rows = [r for r in matrix if r["kind"] == "dir"]
    mscore = sum(r["score"] * w for r, (k, n, dd, w) in zip(matrix, SECTIONS) if dd) / (sum(w for k, n, dd, w in SECTIONS if dd) or 1)
    unified = 0.60 * cons + 0.30 * mscore + (0.10 * mic["score"] if mic["ok"] else 0.10 * mscore)
    u_side = "LONG" if unified >= SIDE_THRESHOLD * 0.85 else "SHORT" if unified <= -SIDE_THRESHOLD * 0.85 else "WAIT"
    same_sign = (unified > 0) == (verdict == "LONG")
    if verdict == "WAIT":
        final = "WAIT"                                        # the core engine's vetoes are never overridden by the lab
    elif u_side == verdict or (u_side == "WAIT" and abs(unified) >= 15 and same_sign):
        final = verdict
    else:
        final = "WAIT"                                        # sections / microstructure contradict the core verdict

    n_same = sum(1 for r in dir_rows if r["side"] == final) if final != "WAIT" else 0
    sec_agree = n_same / len(dir_rows) if dir_rows else 0.0
    ev = evidence or {}
    ev_ok = ev.get("n", 0) >= 12 and ev.get("avg_r", 0) > 0.05
    parts_conf = [
        {"k": "اجماع چندتایم‌فریم", "v": round(min(1, abs(cons) / 70) * 100), "w": 0.28, "note": f"اجماع وزنی {cons:+.0f}"},
        {"k": "هم‌سویی بخش‌ها", "v": round(sec_agree * 100), "w": 0.22, "note": f"{n_same} از {len(dir_rows)} بخش هم‌جهت"},
        {"k": "هم‌راستایی تایم‌فریم‌ها", "v": round(float(deep.get("conviction") or 0) * 100), "w": 0.18, "note": "وزن تایم‌فریم‌های هم‌جهت"},
        {"k": "کیفیت بازار", "v": round(quality), "w": 0.12, "note": x10.get("quality_label", "—")},
        {"k": "زمان‌بندی ورود", "v": round(max(0, min(100, 50 + timing_fit / 2))), "w": 0.10, "note": x10.get("timing_label", "—")},
        {"k": "شواهد بک‌تست", "v": 70 if ev_ok else 45 if ev.get("n") else 40, "w": 0.10, "note": (f"{ev.get('n', 0)} معامله · میانگین {ev.get('avg_r', 0):+.2f}R" if ev.get("n") else "نمونهٔ کافی نیست")},
    ]
    conf = sum(p["v"] * p["w"] for p in parts_conf) / 100
    if final == "WAIT":
        conf *= 0.55
    for veto in (deep.get("veto"),):
        if veto and final != "WAIT":
            conf *= 0.8
    conf = round(max(0.03, min(0.95, conf)), 3)

    # action
    ez = lvl.get("entry_zone") or {}
    if final == "WAIT":
        action, action_why = "صبر", (deep.get("veto") or "اجماع و هم‌سویی برای ورود کافی نیست")
    elif quality < 30:
        action, action_why = "ورود با حجم کم", "کیفیت بازار پایین است؛ فقط با ریسک کاهش‌یافته"
    elif ez and not ez.get("now_ok") or timing_fit <= -35:
        action, action_why = "ورود در پولبک", ez.get("note") or "زمان‌بندی ورود مناسب نیست؛ منتظر بازگشت به ناحیهٔ ورود بمانید"
    else:
        action, action_why = "ورود اکنون", "جهت، کیفیت و زمان‌بندی هم‌راستا هستند"

    # risks / invalidation
    risks = list(sig.get("warnings") or [])
    if mic["ok"] and mic["facts"]:
        risks += [f for f in mic["facts"] if "ریسک" in f or "ازدحام" in f or "اسپرد" in f]
    if deep.get("veto"): risks.append(deep["veto"])
    conflicts = [f"{r['name']}: تایم‌فریم‌ها هم‌نظر نیستند" for r in dir_rows if r.get("conflict")]
    inval = []
    if final in ("LONG", "SHORT"):
        inval.append(f"{'کلوز زیر' if final == 'LONG' else 'کلوز بالای'} {sig.get('stop')} ایدهٔ معامله را باطل می‌کند")
        if lvl.get("trail"): inval.append(f"حد ضرر متحرک (Chandelier): {lvl['trail']}")
        opp_tf = [t for t in ("4h", "1d") if t in per and per[t]["side"] not in (final, "WAIT")]
        if opp_tf: inval.append("تایم‌فریم بزرگ مخالف است: " + "، ".join(opp_tf))
        else: inval.append("تغییر جهت امتیاز ۴ساعته/روزانه به خلاف سیگنال، دلیل خروج زودهنگام است")

    # coherent narrative
    top = sorted(dir_rows, key=lambda r: -abs(r["score"]) * (1 if (r["score"] > 0) == (unified > 0) else 0.2))[:3]
    nar = [f"نتیجهٔ نهایی {symbol.replace('USDT', '')}: {SIDE_FA[final]} با اطمینان {conf * 100:.0f}٪ (امتیاز یکپارچه {unified:+.0f})."]
    if final != "WAIT":
        nar.append("مهم‌ترین دلایل: " + "، ".join(f"{r['name']} ({r['score']:+.0f})" for r in top if abs(r["score"]) >= 15) + ".")
    nar.append(f"اقدام پیشنهادی: {action} — {action_why}.")
    if final != "WAIT":
        tps = " / ".join(str(sig.get(k)) for k in ("tp1", "tp2", "tp3"))
        nar.append(f"ورود {_ltr(sig.get('entry'))} · حد ضرر {_ltr(sig.get('stop'))} · اهداف {_ltr(tps)} · R:R {_ltr(sig.get('risk_reward'))}.")
    if conflicts: nar.append("تعارض‌ها: " + "؛ ".join(conflicts[:3]) + ".")
    if risks: nar.append("ریسک‌ها: " + "؛ ".join(dict.fromkeys(risks))[:300] + ".")

    horizons = [{"tf": t, "role": per[t]["role"], "side": per[t]["side"], "score": per[t]["score"], "confidence": per[t]["confidence"], "text": per[t]["text"]} for t in tfs]
    best_plans = {}
    for sd in ("long", "short"):
        rows = ((plan_lab or {}).get(sd) or {}).get("rows") or []
        best_plans[sd] = {"best": (plan_lab or {}).get(sd, {}).get("best"), "rows": rows[:5]} if rows else None

    return {"ok": True, "symbol": symbol, "price": price, "primary_tf": ptf, "final": final, "core_verdict": verdict, "unified_score": round(unified, 1),
            "core_score": round(cons, 1), "matrix_score": round(mscore, 1), "micro": mic, "confidence": conf, "confidence_parts": parts_conf,
            "action": action, "action_why": action_why, "grade": (deep.get("grade") or {}).get("grade", "—"), "grade_why": (deep.get("grade") or {}).get("why", []),
            "tfs": tfs, "per_tf": per, "matrix": matrix, "horizons": horizons, "plan": {k: sig.get(k) for k in ("side", "entry", "stop", "tp1", "tp2", "tp3", "risk_reward")} if final != "WAIT" else None,
            "entry_zone": ez, "tp_notes": lvl.get("tp_notes") or [], "trail": lvl.get("trail"), "refs": lvl.get("refs") or {},
            "x10": x10, "risks": list(dict.fromkeys(risks)), "conflicts": conflicts, "invalidation": inval, "narrative": nar, "evidence": ev or None,
            "plans": best_plans, "backtest": ({k: bt.get(k) for k in ("n", "win_rate", "avg_r", "pf", "max_dd_r", "t_stat", "significant")} if bt and not bt.get("error") else None),
            "agreement": deep.get("agreement"), "conviction": deep.get("conviction"), "regime": deep.get("regime")}
