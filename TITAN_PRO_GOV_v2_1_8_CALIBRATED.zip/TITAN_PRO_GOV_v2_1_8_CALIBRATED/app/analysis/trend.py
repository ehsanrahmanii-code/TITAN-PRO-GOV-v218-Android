"""Clear, numeric trend of one coin: per timeframe (direction, strength, phase, age, structure) and overall, with the
levels that confirm / invalidate it and the statistical expectation. Everything is computed from closed candles and the
cached analysis — no opinion is invented: each line of the statement quotes the number it rests on."""
from __future__ import annotations
import numpy as np
import pandas as pd

from app.config import TF_MS, TF_WEIGHT

DIR_FA = {"up": "صعودی", "down": "نزولی", "range": "خنثی / رنج"}
PHASE_FA = {"impulse": "حرکت قدرتمند در جهت روند", "pullback": "اصلاح داخل روند", "range": "فشردگی / بی‌جهت", "exhaustion": "خستگی روند (احتمال اصلاح)",
            "reversal": "نشانهٔ تغییر روند"}


def _swings(h: np.ndarray, l: np.ndarray, k: int = 3) -> tuple[list[int], list[int]]:
    hi, lo = [], []
    for i in range(k, len(h) - k):
        if h[i] == h[i - k:i + k + 1].max() and h[i] > h[i - 1]:
            hi.append(i)
        if l[i] == l[i - k:i + k + 1].min() and l[i] < l[i - 1]:
            lo.append(i)
    return hi, lo


def _strength_word(v: float) -> str:
    return "قوی" if v >= 66 else "متوسط" if v >= 40 else "ضعیف"


def analyze_tf(df: pd.DataFrame, sig: dict, tf: str) -> dict:
    c = df["close"].values.astype(float)
    h = df["high"].values.astype(float)
    l = df["low"].values.astype(float)
    ind = sig.get("indicators") or {}
    n = len(c)
    px = float((sig.get("entry")) or c[-1])
    atr = float(ind.get("atr") or np.mean(h[-14:] - l[-14:]) or px * 0.01)
    e9, e21, e50, e200 = (float(ind.get(k) or c[-1]) for k in ("ema9", "ema21", "ema50", "ema200"))
    stack = 1 if e9 > e21 > e50 else -1 if e9 < e21 < e50 else 0
    if stack and e50 and e200:
        stack = stack * (1.0 if (e50 > e200) == (stack > 0) else 0.6)
    st = 1 if (ind.get("supertrend") or 0) > 0 else -1
    # structure from swing points
    hi, lo = _swings(h, l)
    struct, sw_txt = 0, "نامشخص"
    if len(hi) >= 2 and len(lo) >= 2:
        hh, hl = h[hi[-1]] > h[hi[-2]], l[lo[-1]] > l[lo[-2]]
        lh, ll = h[hi[-1]] < h[hi[-2]], l[lo[-1]] < l[lo[-2]]
        struct = 1 if hh and hl else -1 if lh and ll else 0
        sw_txt = "سقف و کف بالاتر (HH/HL)" if struct > 0 else "سقف و کف پایین‌تر (LH/LL)" if struct < 0 else "ساختار مختلط"
    # regression slope over the last 40 bars
    m = min(40, n)
    y = np.log(np.clip(c[-m:], 1e-12, None)); x = np.arange(m, dtype=float)
    sl, ic = np.polyfit(x, y, 1)
    ss_res = float(np.sum((y - (sl * x + ic)) ** 2)); ss_tot = float(np.sum((y - y.mean()) ** 2)) or 1e-12
    r2 = max(0.0, 1 - ss_res / ss_tot)
    slope_pct = float(sl * 100)
    adx = float(ind.get("adx") or 0)
    sc = 2.0 * stack + 1.0 * st + 2.0 * struct + 1.5 * np.sign(sl) * r2 + (1.0 if px > e200 else -1.0)
    score = float(np.clip(sc / 7.5, -1, 1))
    d = "up" if score > 0.33 else "down" if score < -0.33 else "range"
    strength = float(np.clip(abs(score) * 62 + min(adx, 50) * 0.5, 0, 97))
    if d == "range":
        strength = float(np.clip(35 - adx * 0.5, 5, 40))
    # age: consecutive bars on the same side of EMA50
    ema50 = pd.Series(c).ewm(span=50, adjust=False).mean().values
    age = 0
    for i in range(n - 1, -1, -1):
        if (c[i] > ema50[i]) == (c[-1] > ema50[-1]):
            age += 1
        else:
            break
    # phase
    rsi = float(ind.get("rsi") or 50)
    ext = (px - e21) / atr * (1 if d != "down" else -1)
    if d == "range" or adx < 16:
        phase = "range"
    elif (d == "up" and (rsi > 72 or ext > 2.4)) or (d == "down" and (rsi < 28 or ext > 2.4)):
        phase = "exhaustion"
    elif (d == "up" and px < e21) or (d == "down" and px > e21):
        phase = "pullback" if ((d == "up" and px > e50) or (d == "down" and px < e50)) else "reversal"
    else:
        phase = "impulse"
    # last swing, pullback depth
    sw_hi = float(h[hi[-1]]) if hi else float(h[-20:].max())
    sw_lo = float(l[lo[-1]]) if lo else float(l[-20:].min())
    leg = (sw_hi - sw_lo) or atr
    depth = ((sw_hi - px) / leg if d == "up" else (px - sw_lo) / leg if d == "down" else None)
    if depth is not None and not (0.0 <= depth <= 1.5):
        depth = None                                            # price already beyond the last swing → "depth of pullback" has no meaning
    return {"tf": tf, "dir": d, "dir_fa": DIR_FA[d], "score": round(score * 100), "strength": round(strength), "strength_fa": _strength_word(strength),
            "adx": round(adx, 1), "rsi": round(rsi, 1), "ema_stack": "bull" if stack > 0 else "bear" if stack < 0 else "mixed", "supertrend": st,
            "structure": sw_txt, "slope_pct_bar": round(slope_pct, 3), "r2": round(r2, 2), "age_bars": age, "age_ms": age * TF_MS.get(tf, 3_600_000),
            "phase": phase, "phase_fa": PHASE_FA[phase], "ext_atr": round(ext, 2), "pullback_depth": round(depth, 2) if depth is not None else None,
            "swing_hi": sw_hi, "swing_lo": sw_lo, "ema": {"e9": e9, "e21": e21, "e50": e50, "e200": e200}, "atr": atr, "price": px}


def build(sym: str, frames: dict, sigs: dict, fcs: dict, deep: dict | None = None) -> dict:
    tfs = {}
    for tf in ("15m", "1h", "4h", "1d"):
        if tf in frames and tf in sigs and frames[tf] is not None and len(frames[tf]) >= 60:
            try:
                tfs[tf] = analyze_tf(frames[tf], sigs[tf], tf)
            except Exception:                                    # noqa: BLE001
                continue
    if not tfs:
        return {"symbol": sym, "ok": False, "error": "داده کافی برای تحلیل روند نیست"}
    wsum = sum(TF_WEIGHT.get(t, .2) for t in tfs)
    score = sum(TF_WEIGHT.get(t, .2) * v["score"] for t, v in tfs.items()) / wsum
    agree = sum(TF_WEIGHT.get(t, .2) for t, v in tfs.items() if (v["dir"] == "up") == (score > 0) and v["dir"] != "range") / wsum
    d = "up" if score > 22 else "down" if score < -22 else "range"
    adx_w = sum(TF_WEIGHT.get(t, .2) * v["adx"] for t, v in tfs.items()) / wsum
    strength = min(97, abs(score) * 0.8 + adx_w * 0.35) if d != "range" else max(5, 30 - adx_w * 0.4)
    trust = ((deep or {}).get("governor") or {}).get("trust")
    if trust is not None:
        trust = float(trust) / 100.0 if float(trust) > 1.5 else float(trust)
    conf = min(95.0, 100 * (0.45 * agree + 0.35 * min(1, abs(score) / 60) + 0.20 * (trust if trust is not None else 0.7))) if d != "range" else min(80.0, 100 * (0.5 * (1 - agree) + 0.3))
    ptf = "4h" if "4h" in tfs else next(iter(tfs))
    p = tfs[ptf]
    # levels
    sg = (sigs.get("1h") or sigs.get(ptf) or {})
    zones = ((sg.get("levels") or {}).get("zones")) or []
    px = float(sg.get("entry") or p["price"])
    res = sorted([z["p"] for z in zones if z["p"] > px * 1.0005])[:3]
    sup = sorted([z["p"] for z in zones if z["p"] < px * 0.9995], reverse=True)[:3]
    inval = tfs.get("1h", p)["swing_lo"] if d == "up" else tfs.get("1h", p)["swing_hi"] if d == "down" else None
    inval_4h = p["swing_lo"] if d == "up" else p["swing_hi"] if d == "down" else None
    # expectation from the statistical projection
    exp = {}
    for tf in ("1h", "4h"):
        f = fcs.get(tf) or {}
        if f.get("candles"):
            cs = [c for c in f["candles"] if not c.get("current")]
            bd = f.get("bands") or {}
            k = min(len(cs), 24) - 1
            exp[tf] = {"prob_up": f.get("prob_up"), "move_pct": f.get("expected_move_pct"), "direction": f.get("direction"), "bars": len(cs),
                       "t_end": cs[-1]["t_close"] if cs else None,
                       "lo": (bd.get("p10") or [None])[-1], "mid": (bd.get("p50") or [None])[-1], "hi": (bd.get("p90") or [None])[-1]}
    # checklist
    chk = []
    for tf, v in tfs.items():
        chk.append({"t": f"{tf}: {v['dir_fa']} {v['strength_fa']} (ADX {v['adx']}، {v['structure']})", "ok": (v["dir"] == d) if d != "range" else (v["dir"] == "range")})
    chk.append({"t": "چینش EMA هم‌جهت در تایم‌فریم اصلی (۹/۲۱/۵۰)", "ok": (p["ema_stack"] == "bull") == (d == "up") and p["ema_stack"] != "mixed"})
    if exp.get("1h"):
        pu = exp["1h"]["prob_up"] or 0.5
        chk.append({"t": f"پیش‌بینی آماری ۴۸ کندل ۱س: احتمال بالاتر {round(pu * 100)}٪", "ok": (pu >= 0.5) == (d == "up")})
    # risks
    risks = []
    if p["phase"] == "exhaustion":
        risks.append(f"روند در {ptf} خسته به نظر می‌رسد (RSI {p['rsi']}، فاصله از EMA۲۱ {p['ext_atr']} ATR) — احتمال اصلاح")
    if agree < 0.6 and d != "range":
        risks.append("تایم‌فریم‌ها کاملاً هم‌جهت نیستند؛ اطمینان کمتر")
    for tf in ("1d", "4h"):
        v = tfs.get(tf)
        if v and d != "range" and v["dir"] not in (d, "range"):
            risks.append(f"روند {tf} مخالف است ({v['dir_fa']}) — ریسک برگشت")
    if adx_w < 18 and d != "range":
        risks.append("قدرت روند (ADX) پایین است؛ شکست‌های کاذب محتمل‌ترند")
    base = sym.replace("USDT", "")
    lines = []
    if d == "range":
        lines.append(f"{base} روند مشخصی ندارد و بین حمایت و مقاومت نوسان می‌کند (امتیاز {score:+.0f}، ADX میانگین {adx_w:.0f}).")
    else:
        lines.append(f"روند غالب {base} {DIR_FA[d]} و {_strength_word(strength)} است (امتیاز {score:+.0f}، قدرت {strength:.0f}٪، اطمینان {conf:.0f}٪).")
        ok_n = sum(1 for v in tfs.values() if v["dir"] == d)
        lines.append(f"{ok_n} از {len(tfs)} تایم‌فریم هم‌جهت‌اند؛ تایم‌فریم اصلی ({ptf}): {p['structure']}، ADX {p['adx']}، " + ("چینش EMA " + ("صعودی" if p["ema_stack"] == "bull" else "نزولی" if p["ema_stack"] == "bear" else "مختلط")) + ".")
        lines.append(f"فاز فعلی: {p['phase_fa']}" + (f"؛ عمق اصلاح {p['pullback_depth'] * 100:.0f}٪ از آخرین موج" if p.get("pullback_depth") is not None and p["phase"] == "pullback" else "") + f"؛ قیمت {p['age_bars']} کندل {ptf} است که روی همین سمت EMA۵۰ مانده.")
        if inval:
            lines.append(f"روند با بسته‌شدن {'زیر' if d == 'up' else 'بالای'} {inval:.6g} (آخرین {'کف' if d == 'up' else 'سقف'} {'۱س' if '1h' in tfs else ptf}) باطل می‌شود" + (f"؛ ابطال قوی‌تر زیر/بالای {inval_4h:.6g} در {ptf}." if inval_4h else "."))
    if exp.get("1h"):
        e = exp["1h"]
        lines.append(f"انتظار آماری ({e['bars']} کندل ۱س): احتمال بالاتر بودن {round((e['prob_up'] or .5) * 100)}٪، حرکت میانه {e['move_pct']:+.2f}٪.")
    return {"symbol": sym, "ok": True, "overall": {"dir": d, "dir_fa": DIR_FA[d], "score": round(score), "strength": round(strength), "strength_fa": _strength_word(strength),
                                                     "confidence": round(conf), "agree": round(agree * 100), "primary_tf": ptf, "phase": p["phase"], "phase_fa": p["phase_fa"],
                                                     "headline": lines[0], "statement": lines},
            "tfs": tfs, "levels": {"resistance": res, "support": sup, "invalidation": inval, "invalidation_htf": inval_4h, "price": px},
            "expect": exp, "checklist": chk, "risks": risks}
