"""TITAN x12 — ten complementary indicators (regime / pressure / path / energy).

Designed to NOT duplicate x10 (quality/timing/flow) or x11 (structure/participation).
Each item: {v, s (-1..+1), t (Persian), role}. compute() never raises.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

KEYS = [
    "eff_ratio", "ulcer", "mass", "tsi", "coppock",
    "force", "nvi_pvi", "pivot_bias", "range_pos", "gap_pressure",
]
NAMES = {
    "eff_ratio": "نسبت کارایی کافمن (ER)",
    "ulcer": "شاخص اولسر (درد افت)",
    "mass": "شاخص جرم (Mass Index)",
    "tsi": "True Strength Index",
    "coppock": "کاپاک منحنی",
    "force": "شاخص نیروی الدر",
    "nvi_pvi": "NVI / PVI",
    "pivot_bias": "باIASس پیوت کلاسیک",
    "range_pos": "موقعیت در رنج ۲۰",
    "gap_pressure": "فشار گپ و پیوستگی",
}
ROLES = {
    "eff_ratio": "regime", "ulcer": "risk", "mass": "regime", "tsi": "momentum",
    "coppock": "momentum", "force": "volume", "nvi_pvi": "volume",
    "pivot_bias": "structure", "range_pos": "timing", "gap_pressure": "pressure",
}
ROLE_FA = {
    "regime": "رژیم بازار", "risk": "ریسک افت", "momentum": "مومنتوم",
    "volume": "حجم و مشارکت", "structure": "ساختار", "timing": "زمان‌بندی", "pressure": "فشار قیمت",
}


def _c(x, a=-1.0, b=1.0) -> float:
    return float(max(a, min(b, x)))


def _f(x, nd=4):
    try:
        x = float(x)
        return round(x, nd) if np.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def efficiency_ratio(close: np.ndarray, n: int = 20) -> dict:
    if len(close) < n + 2:
        return {}
    c = close.astype(float)
    net = abs(c[-1] - c[-n - 1])
    path = float(np.abs(np.diff(c[-n - 1:])).sum()) or 1e-12
    er = net / path
    mom = float(np.sign(c[-1] - c[-n - 1]))
    if er >= 0.55:
        s, t = mom * _c((er - 0.4) * 2), f"ER={er:.2f} · مسیر کارآمد و روندی"
    elif er <= 0.25:
        s, t = 0.0, f"ER={er:.2f} · نویز زیاد؛ لبه روند ضعیف"
    else:
        s, t = mom * 0.25, f"ER={er:.2f} · کارایی متوسط"
    return {"v": _f(er, 3), "s": round(s, 3), "t": t}


def ulcer_index(close: np.ndarray, n: int = 14) -> dict:
    if len(close) < n + 5:
        return {}
    c = pd.Series(close.astype(float))
    peak = c.cummax()
    dd = 100 * (c - peak) / peak.replace(0, np.nan)
    ui = float(np.sqrt((dd.tail(n) ** 2).mean()))
    if not np.isfinite(ui):
        return {}
    # high ulcer = pain → caution for longs, mild short bias in up-drawdowns
    s = _c(-ui / 8.0) * 0.7
    t = f"UI={ui:.1f} · {'درد افت بالا؛ احتیاط خرید' if ui >= 5 else 'افت کنترل‌شده' if ui >= 2 else 'آرامش نسبی'}"
    return {"v": _f(ui, 2), "s": round(s, 3), "t": t}


def mass_index(df: pd.DataFrame, n: int = 25) -> dict:
    if len(df) < n + 20:
        return {}
    rng = (df["high"] - df["low"]).astype(float)
    ema1 = rng.ewm(span=9, adjust=False).mean()
    ema2 = ema1.ewm(span=9, adjust=False).mean()
    ratio = ema1 / ema2.replace(0, np.nan)
    mi = float(ratio.tail(n).sum())
    if not np.isfinite(mi):
        return {}
    # classic: bulge above ~27 then drop signals reversal setup
    if mi >= 27:
        s, t = 0.0, f"MI={mi:.1f} · برآمدگی دامنه؛ آمادهٔ برگشت احتمالی"
    elif mi <= 22:
        s, t = 0.15 * float(np.sign(df["close"].iloc[-1] - df["close"].iloc[-n])), f"MI={mi:.1f} · دامنه فشرده"
    else:
        s, t = 0.0, f"MI={mi:.1f} · دامنه عادی"
    return {"v": _f(mi, 1), "s": round(s, 3), "t": t}


def tsi(df: pd.DataFrame, r: int = 25, s: int = 13) -> dict:
    c = df["close"].astype(float)
    if len(c) < r + s + 5:
        return {}
    m = c.diff()
    num = m.ewm(span=r, adjust=False).mean().ewm(span=s, adjust=False).mean()
    den = m.abs().ewm(span=r, adjust=False).mean().ewm(span=s, adjust=False).mean()
    v = float(100 * num.iloc[-1] / (den.iloc[-1] or 1e-12))
    if not np.isfinite(v):
        return {}
    sc = _c(v / 40.0)
    t = f"TSI={v:.1f} · {'مومنتوم صعودی' if v > 10 else 'مومنتوم نزولی' if v < -10 else 'خنثی'}"
    return {"v": _f(v, 1), "s": round(sc, 3), "t": t}


def coppock(close: np.ndarray) -> dict:
    if len(close) < 50:
        return {}
    c = pd.Series(close.astype(float))
    roc11 = c.pct_change(11)
    roc14 = c.pct_change(14)
    cop = (roc11 + roc14).ewm(span=10, adjust=False).mean()
    v = float(cop.iloc[-1] * 100)
    prev = float(cop.iloc[-2] * 100)
    if not np.isfinite(v):
        return {}
    s = _c(v / 5.0) * 0.7
    if v > 0 and prev <= 0:
        s, t = 0.8, f"Coppock={v:.2f} · عبور به مثبت (سیگنال خرید تاریخی)"
    elif v < 0 and prev >= 0:
        s, t = -0.8, f"Coppock={v:.2f} · عبور به منفی"
    else:
        t = f"Coppock={v:.2f}"
    return {"v": _f(v, 2), "s": round(s, 3), "t": t}


def force_index(df: pd.DataFrame, n: int = 13) -> dict:
    if len(df) < n + 5:
        return {}
    c, v = df["close"].astype(float), df["volume"].astype(float)
    fi = (c.diff() * v).ewm(span=n, adjust=False).mean()
    val = float(fi.iloc[-1])
    scale = float(fi.tail(100).abs().median()) or 1e-12
    z = val / scale
    s = _c(z / 3.0)
    t = f"Force={_f(z, 2)} · {'فشار خرید حجمی' if z > 1 else 'فشار فروش حجمی' if z < -1 else 'نیروی متعادل'}"
    return {"v": _f(z, 2), "s": round(s, 3), "t": t}


def nvi_pvi(df: pd.DataFrame) -> dict:
    if len(df) < 40:
        return {}
    c, v = df["close"].astype(float).values, df["volume"].astype(float).values
    nvi = pvi = 1000.0
    for i in range(1, len(c)):
        chg = (c[i] - c[i - 1]) / (c[i - 1] or 1e-12)
        if v[i] < v[i - 1]:
            nvi *= 1 + chg
        else:
            pvi *= 1 + chg
    # compare to their EMAs as trend of smart/dumb money proxies
    # approximate with last value vs simple mean of reconstructed path is hard; use recent force of each
    # Instead: last 20 bars contribution
    nvi_s = pvi_s = 0.0
    nvi = pvi = 1000.0
    hist_n, hist_p = [], []
    for i in range(1, len(c)):
        chg = (c[i] - c[i - 1]) / (c[i - 1] or 1e-12)
        if v[i] < v[i - 1]:
            nvi *= 1 + chg
        else:
            pvi *= 1 + chg
        hist_n.append(nvi)
        hist_p.append(pvi)
    hn, hp = np.array(hist_n[-30:]), np.array(hist_p[-30:])
    if len(hn) < 10:
        return {}
    n_slope = (hn[-1] - hn[0]) / (hn[0] or 1)
    p_slope = (hp[-1] - hp[0]) / (hp[0] or 1)
    # NVI (smart money on down-volume days) preferred
    s = _c(n_slope * 8) * 0.55 + _c(p_slope * 5) * 0.25
    t = f"NVIΔ={n_slope * 100:.1f}% · PVIΔ={p_slope * 100:.1f}%"
    return {"v": _f(n_slope * 100, 2), "s": round(float(s), 3), "t": t, "pvi_d": _f(p_slope * 100, 2)}


def pivot_bias(df: pd.DataFrame) -> dict:
    if len(df) < 5:
        return {}
    h, l, c = float(df["high"].iloc[-2]), float(df["low"].iloc[-2]), float(df["close"].iloc[-2])
    p = (h + l + c) / 3
    r1, s1 = 2 * p - l, 2 * p - h
    last = float(df["close"].iloc[-1])
    if last >= r1:
        s, t = 0.7, "بالای R1 پیوت کلاسیک"
    elif last <= s1:
        s, t = -0.7, "زیر S1 پیوت کلاسیک"
    elif last >= p:
        s, t = 0.3, "بالای پیوت مرکزی"
    else:
        s, t = -0.3, "زیر پیوت مرکزی"
    return {"v": _f((last - p) / (p or 1) * 100, 2), "s": s, "t": t, "pivot": _f(p, 8), "r1": _f(r1, 8), "s1": _f(s1, 8)}


def range_position(df: pd.DataFrame, n: int = 20) -> dict:
    if len(df) < n + 2:
        return {}
    h = float(df["high"].tail(n).max())
    l = float(df["low"].tail(n).min())
    last = float(df["close"].iloc[-1])
    if h <= l:
        return {}
    pos = (last - l) / (h - l)
    # mean-reversion lean near edges, mild trend lean mid-break
    if pos >= 0.85:
        s, t = -0.45, f"نزدیک سقف رنج {n} · احتمال اشباع خرید"
    elif pos <= 0.15:
        s, t = 0.45, f"نزدیک کف رنج {n} · احتمال اشباع فروش"
    else:
        s, t = _c((pos - 0.5) * 0.6), f"موقعیت رنج: {pos * 100:.0f}٪"
    return {"v": _f(pos, 3), "s": round(s, 3), "t": t, "hi": _f(h, 8), "lo": _f(l, 8)}


def gap_pressure(df: pd.DataFrame) -> dict:
    if len(df) < 30:
        return {}
    o, c = df["open"].astype(float).values, df["close"].astype(float).values
    gaps = o[1:] - c[:-1]
    atr = float(pd.concat([
        df["high"] - df["low"],
        (df["high"] - df["close"].shift()).abs(),
        (df["low"] - df["close"].shift()).abs(),
    ], axis=1).max(axis=1).tail(20).mean()) or 1e-12
    recent = gaps[-10:]
    filled = 0
    for i in range(len(gaps) - 10, len(gaps)):
        if i < 0:
            continue
        g = gaps[i]
        if abs(g) < atr * 0.15:
            filled += 1
            continue
        # gap up filled if later low reaches prior close
        if g > 0 and df["low"].iloc[i + 1:].min() <= c[i]:
            filled += 1
        elif g < 0 and df["high"].iloc[i + 1:].max() >= c[i]:
            filled += 1
    last_gap = float(gaps[-1]) / atr
    s = _c(last_gap * 0.5)
    t = f"گپ اخیر={last_gap:.2f}ATR · پرشدگی ۱۰تای آخر≈{filled}/10"
    return {"v": _f(last_gap, 2), "s": round(s, 3), "t": t, "fill_rate": filled / 10}


def compute(df: pd.DataFrame, tf: str = "1h") -> dict:
    close = df["close"].astype(float).values
    fns = {
        "eff_ratio": lambda: efficiency_ratio(close),
        "ulcer": lambda: ulcer_index(close),
        "mass": lambda: mass_index(df),
        "tsi": lambda: tsi(df),
        "coppock": lambda: coppock(close),
        "force": lambda: force_index(df),
        "nvi_pvi": lambda: nvi_pvi(df),
        "pivot_bias": lambda: pivot_bias(df),
        "range_pos": lambda: range_position(df),
        "gap_pressure": lambda: gap_pressure(df),
    }
    items: dict[str, dict] = {}
    for k, fn in fns.items():
        try:
            r = fn()
        except Exception:  # noqa: BLE001
            r = {}
        if r:
            r.update(n=NAMES[k], role=ROLES[k], role_fa=ROLE_FA.get(ROLES[k], ""))
            items[k] = r
    if not items:
        return {}
    votes = [it["s"] for it in items.values() if abs(it.get("s") or 0) >= 0.15]
    score = round(float(np.mean(votes)) * 100, 1) if votes else 0.0
    bull = sum(1 for it in items.values() if (it.get("s") or 0) > 0.2)
    bear = sum(1 for it in items.values() if (it.get("s") or 0) < -0.2)
    by_role: dict[str, list] = {}
    for it in items.values():
        by_role.setdefault(it.get("role") or "other", []).append(it["s"])
    role_scores = {k: round(float(np.mean(v)) * 100, 1) for k, v in by_role.items()}
    return {
        "items": items, "n": len(items), "score": score, "bull": bull, "bear": bear,
        "roles": role_scores, "keys": list(items.keys()),
        "label": "هم‌سویی صعودی x12" if score >= 25 else "هم‌سویی نزولی x12" if score <= -25 else "x12 خنثی",
    }
