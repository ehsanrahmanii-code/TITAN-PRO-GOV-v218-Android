"""Outcome calibration: turns the Governor's raw «confidence» into a probability measured on YOUR resolved signals.

Why: confidence is a hand-built score; nothing guarantees that «70» wins 70 % of the time. Every resolved entry of the signal log
(hit TP1 / hit SL / 4 h sign) is a real outcome, so we can measure what each confidence band, side and grade really delivered
and refuse signals whose measured expectancy is negative.

Statistics are deliberately conservative (small samples are the normal case here):
  - win rate is shrunk toward the global rate (Beta prior), the global rate toward 0.5;
  - a Wilson lower bound (80 %) is reported next to it;
  - a signal is blocked only when BOTH the point estimate and the lower bound say the expected R is clearly negative,
    and only with enough samples (point EV < -0.10R and lower-bound EV < -0.25R). With too little data nothing changes (state = "insufficient").
"""
from __future__ import annotations
import math
import threading
import time
from typing import Any

from app.config import FEE_TAKER, SLIPPAGE

_LOCK = threading.Lock()
_CACHE: dict[str, Any] = {"key": None, "ts": 0.0, "val": None}

MIN_TOTAL = 25            # resolved outcomes before calibration is used at all
MIN_BUCKET = 12           # outcomes inside the matching band/side before it is trusted
PRIOR_GLOBAL = 10.0       # pseudo-samples pulling the global win rate toward 0.5
PRIOR_BUCKET = 8.0        # pseudo-samples pulling a band toward the global rate
Z80 = 1.2816              # one-sided 90 % / two-sided 80 %
BLOCK_EV_LOW = -0.25      # expected R (lower bound) below this AND point EV below BLOCK_EV_POINT → block
BLOCK_EV_POINT = -0.10    # near break-even is not «clearly negative»: thin evidence never blocks it
BANDS = ((0.0, 50.0, "<50"), (50.0, 65.0, "50-65"), (65.0, 101.0, "65+"))


def _win(e: dict) -> float | None:
    hit = e.get("hit")
    if hit == "TP1":
        return 1.0
    if hit == "SL":
        return 0.0
    r4 = (e.get("res") or {}).get("4h")
    if r4 is None:
        return None
    try:
        return 1.0 if float(r4) > 0 else 0.0
    except (TypeError, ValueError):
        return None


def _planned_r(e: dict) -> float | None:
    """Reward/risk of the logged plan (|tp1-entry| / |entry-stop|), capped; None when the plan was not stored."""
    try:
        p, s, t = float(e["price"]), float(e["stop"]), float(e["tp1"])
        risk = abs(p - s)
        return min(4.0, abs(t - p) / risk) if risk > 0 else None
    except (KeyError, TypeError, ValueError):
        return None


def wilson_low(wins: float, n: float, z: float = Z80) -> float:
    if n <= 0:
        return 0.0
    p = wins / n
    d = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return max(0.0, (centre - margin) / d)


def _band(conf: float) -> str:
    for lo, hi, name in BANDS:
        if lo <= conf < hi:
            return name
    return BANDS[-1][2]


def _table(entries: list[dict]) -> dict[str, Any]:
    rows = []
    for e in entries:
        w = _win(e)
        if w is None or e.get("verdict") not in ("LONG", "SHORT"):
            continue
        try:
            conf = float(e.get("confidence"))
        except (TypeError, ValueError):
            continue
        rows.append({"w": w, "side": e["verdict"], "band": _band(conf), "grade": str(e.get("grade") or "—"), "r": _planned_r(e)})
    n = len(rows)
    wins = sum(r["w"] for r in rows)
    g = (wins + PRIOR_GLOBAL * 0.5) / (n + PRIOR_GLOBAL) if n else 0.5
    rwin = [r["r"] for r in rows if r["w"] == 1.0 and r["r"]]
    avg_rw = sum(rwin) / len(rwin) if rwin else 1.5

    def agg(sel: list[dict]) -> dict[str, Any]:
        k = len(sel)
        w = sum(x["w"] for x in sel)
        p = (w + PRIOR_BUCKET * g) / (k + PRIOR_BUCKET)
        return {"n": k, "wins": int(w), "raw": round(w / k, 3) if k else None, "p": round(p, 3), "p_low": round(wilson_low(w, k), 3)}

    return {
        "n": n, "global": round(g, 3), "avg_win_r": round(avg_rw, 2),
        "band": {name: agg([r for r in rows if r["band"] == name]) for _, _, name in BANDS},
        "side": {s: agg([r for r in rows if r["side"] == s]) for s in ("LONG", "SHORT")},
        "grade": {gr: agg([r for r in rows if r["grade"] == gr]) for gr in sorted({r["grade"] for r in rows})},
        "ready": n >= MIN_TOTAL,
    }


def table(entries: list[dict] | None = None) -> dict[str, Any]:
    """Calibration table from the signal log (cached ~45 s; the log only grows slowly)."""
    if entries is not None:                                       # explicit data (tests, what-if): never cached
        return _table(entries)
    from app.engine import siglog
    entries = siglog.entries_copy()
    wins = [_win(e) for e in entries]                              # key changes whenever an outcome resolves or flips
    key = (len(entries), entries[-1].get("id") if entries else None, sum(w is not None for w in wins), sum(w or 0.0 for w in wins))
    now = time.time()
    with _LOCK:
        if _CACHE["key"] == key and now - _CACHE["ts"] < 45 and _CACHE["val"] is not None:
            return _CACHE["val"]
    val = _table(entries)
    with _LOCK:
        _CACHE.update(key=key, ts=now, val=val)
    return val


def assess(side: str, confidence: float, rr: float | None = None, entries: list[dict] | None = None) -> dict[str, Any]:
    """Calibrated win probability and expected R for a candidate signal.

    state: "insufficient" (not enough own outcomes — nothing is changed) | "calibrated".
    block: True only when the measured expectancy is clearly negative (see module doc)."""
    t = table(entries)
    out: dict[str, Any] = {"state": "insufficient", "n": t["n"], "p_win": None, "p_low": None, "ev_r": None, "ev_low": None, "block": False,
                           "band": _band(float(confidence or 0.0)), "need": MIN_TOTAL}
    if side not in ("LONG", "SHORT") or not t["ready"]:
        return out
    b, s = t["band"][out["band"]], t["side"][side]
    ref = b if b["n"] >= MIN_BUCKET else s if s["n"] >= MIN_BUCKET else None
    if ref is None:
        out["state"] = "insufficient_band"
        return out
    # the side's own record tilts the band estimate (shorts and longs do not behave the same on every market)
    p, p_low = ref["p"], ref["p_low"]
    if ref is b and s["n"] >= MIN_BUCKET:
        p = 0.6 * b["p"] + 0.4 * s["p"]
        p_low = min(b["p_low"], s["p_low"]) if s["p_low"] > 0 else b["p_low"]
    r_win = max(1.0, min(4.0, float(rr))) if rr and rr > 0 else t["avg_win_r"]
    cost = min(0.30, max(0.05, 2 * (FEE_TAKER + SLIPPAGE) / 0.010))   # round-trip fee+slippage in R for a typical 1 % stop (≈ 0.22 R)
    ev = p * r_win - (1 - p) - cost
    ev_low = p_low * r_win - (1 - p_low) - cost
    out.update(state="calibrated", p_win=round(p, 3), p_low=round(p_low, 3), ev_r=round(ev, 2), ev_low=round(ev_low, 2),
               r_win=round(r_win, 2), n_ref=ref["n"], block=bool(ev < BLOCK_EV_POINT and ev_low < BLOCK_EV_LOW))
    return out
