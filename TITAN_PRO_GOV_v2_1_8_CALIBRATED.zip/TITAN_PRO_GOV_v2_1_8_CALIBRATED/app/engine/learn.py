"""Lightweight adaptive learning for Central Governor (no heavy DB).

Stores soft reliability multipliers per evidence family in XXX/governor_learn.json.
Updated from siglog outcomes (hit SL/TP1 or 4h return). Tilts WEIGHTS within
safe bounds so the clean architecture stays fast and file-based.

Inspired by V84 edge_lab component attribution + validated_decisions soft weights,
but deliberately simple: no champion/challenger, no SQLite, no Monte-Carlo.
"""
from __future__ import annotations
import json
import os
import threading
import time
from pathlib import Path
from typing import Any

from app.config import DATA_DIR

_FILE = DATA_DIR / "governor_learn.json"
_LOCK = threading.RLock()
_STATE: dict[str, Any] | None = None

# Families that participate in adaptive tilt (must match governor WEIGHTS keys)
FAMILIES = (
    "htf_trend", "mtf_setup", "ltf_trigger", "momentum", "structure",
    "volume_flow", "derivatives", "pattern", "forecast", "context", "x_layer",
)

# Soft bounds: never destroy a component, never let one dominate
TILT_MIN = 0.72
TILT_MAX = 1.38
MIN_SAMPLES = 8          # need this many resolved outcomes before tilting
PRIOR_STRENGTH = 6.0     # Bayesian-ish prior toward 0.5 win rate
LEARN_RATE = 0.18        # how fast reliability moves toward observed
MAX_ENTRIES_USED = 220


def _defaults() -> dict:
    return {
        "ts": 0.0,
        "n_resolved": 0,
        "reliability": {k: 1.0 for k in FAMILIES},
        "stats": {k: {"n": 0, "wins": 0.0} for k in FAMILIES},
        "global": {"n": 0, "wins": 0.0, "avg_r": 0.0},
    }


def _load() -> dict:
    global _STATE
    if _STATE is not None:
        return _STATE
    st = _defaults()
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            st["ts"] = float(raw.get("ts") or 0)
            st["n_resolved"] = int(raw.get("n_resolved") or 0)
            rel = raw.get("reliability") or {}
            for k in FAMILIES:
                if k in rel:
                    st["reliability"][k] = max(TILT_MIN, min(TILT_MAX, float(rel[k])))
            stats = raw.get("stats") or {}
            for k in FAMILIES:
                if k in stats and isinstance(stats[k], dict):
                    st["stats"][k]["n"] = int(stats[k].get("n") or 0)
                    st["stats"][k]["wins"] = float(stats[k].get("wins") or 0)
            g = raw.get("global") or {}
            st["global"]["n"] = int(g.get("n") or 0)
            st["global"]["wins"] = float(g.get("wins") or 0)
            st["global"]["avg_r"] = float(g.get("avg_r") or 0)
    except Exception:  # noqa: BLE001
        pass
    _STATE = st
    return _STATE


def _save(st: dict) -> None:
    tmp = _FILE.with_name(_FILE.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, _FILE)


def get_reliability() -> dict[str, float]:
    """Copy of current per-family reliability multipliers (1.0 = neutral)."""
    with _LOCK:
        st = _load()
        return {k: float(st["reliability"].get(k, 1.0)) for k in FAMILIES}


def get_status() -> dict[str, Any]:
    with _LOCK:
        st = _load()
        return {
            "n_resolved": st["n_resolved"],
            "reliability": dict(st["reliability"]),
            "global": dict(st["global"]),
            "ready": st["n_resolved"] >= MIN_SAMPLES,
            "ts": st["ts"],
        }


def _outcome_win(entry: dict) -> float | None:
    """Return 1.0 (win), 0.0 (loss), or None if not yet resolvable.

    Prefer path hit (TP1/SL); else use 4h horizon sign.
    """
    hit = entry.get("hit")
    if hit == "TP1":
        return 1.0
    if hit == "SL":
        return 0.0
    r4 = (entry.get("res") or {}).get("4h")
    if r4 is None:
        return None
    try:
        return 1.0 if float(r4) > 0 else 0.0
    except (TypeError, ValueError):
        return None


def _signed_components(entry: dict) -> dict[str, float]:
    """Components stored at log time; values in [-1,1] roughly."""
    comp = entry.get("components") or {}
    out = {}
    for k in FAMILIES:
        try:
            out[k] = float(comp.get(k, 0.0) or 0.0)
        except (TypeError, ValueError):
            out[k] = 0.0
    return out


def refresh_from_siglog(entries: list[dict] | None = None) -> dict[str, Any]:
    """Recompute reliability from resolved siglog entries.

    Safe to call periodically (e.g. after each scan). Idempotent.
    """
    if entries is None:
        try:
            from app.engine import siglog
            entries = siglog.entries_copy()
        except Exception:  # noqa: BLE001
            entries = []

    # Only use entries that have components snapshot + resolvable outcome
    usable = []
    for e in entries[-MAX_ENTRIES_USED:]:
        if not e.get("components"):
            continue
        w = _outcome_win(e)
        if w is None:
            continue
        usable.append((e, w))

    with _LOCK:
        st = _load()
        # reset stats then rebuild
        stats = {k: {"n": 0, "wins": 0.0} for k in FAMILIES}
        g_n = g_wins = 0.0
        for e, win in usable:
            side = str(e.get("verdict") or "")
            comps = _signed_components(e)
            g_n += 1
            g_wins += win
            for k, v in comps.items():
                # Only credit/blame families that actually leaned with the published side
                if abs(v) < 0.12:
                    continue
                agrees = (v > 0 and side == "LONG") or (v < 0 and side == "SHORT")
                if not agrees:
                    # opposing evidence that was overruled → mild reverse credit if trade lost
                    if win < 0.5:
                        stats[k]["n"] += 0.35
                        stats[k]["wins"] += 0.35  # opposing was "right"
                    continue
                stats[k]["n"] += 1.0
                stats[k]["wins"] += win

        reliability = {}
        for k in FAMILIES:
            n = stats[k]["n"]
            wins = stats[k]["wins"]
            if n < MIN_SAMPLES * 0.5:
                reliability[k] = 1.0
                continue
            # posterior mean with prior
            p = (wins + PRIOR_STRENGTH * 0.5) / (n + PRIOR_STRENGTH)
            # map win-rate around 0.5 → multiplier around 1.0
            # p=0.40 → ~0.82, p=0.50 → 1.0, p=0.60 → ~1.18
            raw = 1.0 + (p - 0.5) * 2.2
            # smooth toward previous
            prev = float(st["reliability"].get(k, 1.0))
            tilted = prev * (1.0 - LEARN_RATE) + raw * LEARN_RATE
            reliability[k] = max(TILT_MIN, min(TILT_MAX, tilted))

        st["reliability"] = reliability
        st["stats"] = stats
        st["n_resolved"] = int(g_n)
        st["global"] = {
            "n": int(g_n),
            "wins": float(g_wins),
            "avg_r": round(g_wins / g_n, 4) if g_n else 0.0,
        }
        st["ts"] = time.time()
        _STATE = st
        _save(st)
        return get_status()


def apply_tilts(base_weights: dict[str, float]) -> dict[str, float]:
    """Return a copy of base_weights multiplied by learned reliability."""
    rel = get_reliability()
    out = {}
    for k, w in base_weights.items():
        out[k] = float(w) * float(rel.get(k, 1.0))
    return out


# ── soft same-side overlap / cooldown (siglog-based, V84 edge_lab spirit) ──
OVERLAP_COOLDOWN_SEC = 2700      # 45 min default between same-side publishes
OVERLAP_MAX_OPEN_SIDE = 4        # soft cap of concurrent same-side tracked signals


def same_side_overlap(symbol: str, side: str, now: float | None = None) -> dict:
    """Return {ok, reason} — soft gate against rapid re-publish of same side.

    Uses siglog last verdict + recent unresolved entries. No DB.
    """
    if side not in ("LONG", "SHORT"):
        return {"ok": True, "reason": ""}
    now = now or time.time()
    try:
        from app.engine import siglog
        entries = siglog.entries_copy()
    except Exception:  # noqa: BLE001
        return {"ok": True, "reason": ""}

    sym = str(symbol or "").upper().replace("/", "").replace("-", "")
    # A signal that is ALREADY live for this coin is a continuation, not a re-publish: the gate must never veto a signal
    # because of its own log entry (that made every published signal flip to WAIT on the next evaluation).
    try:
        if siglog.current(sym) == side:
            return {"ok": True, "reason": "continuation"}
    except Exception:  # noqa: BLE001
        pass
    # recent same symbol + same side still open (no hit yet) within cooldown
    for e in reversed(entries[-80:]):
        es = str(e.get("symbol") or "").upper().replace("/", "").replace("-", "")
        if es != sym:
            continue
        if str(e.get("verdict") or "") != side:
            # opposite side published more recently → allow flip
            if float(e.get("t") or 0) > now - OVERLAP_COOLDOWN_SEC:
                return {"ok": True, "reason": "flip"}
            break
        age = now - float(e.get("t") or 0)
        if age < OVERLAP_COOLDOWN_SEC and e.get("hit") is None:
            return {
                "ok": False,
                "reason": f"همپوشانی همان‌سمت ({side}) تا {int((OVERLAP_COOLDOWN_SEC - age) / 60)}د دیگر",
            }
        break

    # global soft cap on unresolved same-side across symbols
    open_same = 0
    for e in entries[-120:]:
        if str(e.get("verdict") or "") == side and e.get("hit") is None:
            age = now - float(e.get("t") or 0)
            if age < OVERLAP_COOLDOWN_SEC * 2:
                open_same += 1
    if open_same >= OVERLAP_MAX_OPEN_SIDE:
        return {
            "ok": False,
            "reason": f"سقف سیگنال‌های باز {side} ({open_same}/{OVERLAP_MAX_OPEN_SIDE})",
        }
    return {"ok": True, "reason": ""}
