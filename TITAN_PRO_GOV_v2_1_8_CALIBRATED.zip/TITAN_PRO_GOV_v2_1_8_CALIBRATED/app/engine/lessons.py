"""Mistake memory (حافظهٔ اشتباهات).

Every position opened by the system carries a *snapshot of the reasons* it was opened (families of evidence, regime,
consensus, extension, RSI, market context, forecast ...). When the position closes, a post-mortem is written:

* which pre-entry warning conditions were present (tags_in) and what went wrong after entry (tags_out),
* a plain-language lesson.

Before the next automatic entry the gate looks at the REAL history: a warning condition (or a setup bucket, or a coin) that
has repeatedly lost is blocked — so the same mistake is not repeated. Nothing here invents statistics: a rule needs enough
closed trades to fire, and every veto names the evidence behind it. All data lives in XXX/lessons.json.
"""
from __future__ import annotations
import json
import os
import threading
import time

from app.config import DATA_DIR

_FILE = DATA_DIR / "lessons.json"
_LOCK = threading.RLock()
_ST: dict | None = None
MAX_CASES = 400

TAG_FA = {
    "chased": "ورود دیرهنگام (قیمت از EMA۲۱ دور بود)",
    "exhaustion": "ورود در اشباع RSI",
    "ctx_opposed": "بافت بازار مخالف بود",
    "range_regime": "بازار رنج بود",
    "weak_consensus": "اجماع تایم‌فریم‌ها ضعیف بود",
    "htf_conflict": "روند تایم‌فریم بالا هم‌جهت نبود",
    "fc_against": "پیش‌بینی آماری مخالف بود",
    "low_quality": "کیفیت بازار/سطوح پایین بود",
}
OUT_FA = {
    "early_fail": "تقریباً بلافاصله خلاف جهت رفت (ورود بدون تایید)",
    "gave_back": "سود خوبی داشت ولی برگشت و حدضرر خورد (سود محافظت نشد)",
    "time_exit": "در مهلت زمانی حرکت نکرد (ستاپ کهنه/رنج)",
    "flip_exit": "تحلیل برعکس شد و پوزیشن بسته شد",
    "clean_win": "اجرای تمیز: ورود درست و رسیدن به هدف",
}


def _load() -> dict:
    global _ST
    if _ST is None:
        try:
            raw = json.loads(_FILE.read_text(encoding="utf-8"))
            _ST = raw if isinstance(raw, dict) else {}
        except Exception:                                        # noqa: BLE001
            _ST = {}
        _ST.setdefault("cases", [])
    return _ST


def _save() -> None:
    try:
        tmp = _FILE.with_name(_FILE.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
        tmp.write_text(json.dumps(_load(), ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _FILE)
    except OSError:
        pass


def tags_for(snap: dict, side: str) -> list[str]:
    """Pre-entry warning conditions present in a snapshot (the same function is used for past trades and for a new candidate)."""
    if not snap:
        return []
    d = 1 if side == "LONG" else -1
    f = snap.get("fams") or {}
    out = []
    if (snap.get("ext_atr") or 0) > 1.6:
        out.append("chased")
    rsi = snap.get("rsi")
    if rsi is not None and ((side == "LONG" and rsi > 72) or (side == "SHORT" and rsi < 28)):
        out.append("exhaustion")
    if (snap.get("ctx_bias") or 0) * d < -0.25:
        out.append("ctx_opposed")
    if snap.get("regime") == "range":
        out.append("range_regime")
    if abs(snap.get("cons") or 0) < 40:
        out.append("weak_consensus")
    if (f.get("htf_trend") or 0) * d < -0.15:
        out.append("htf_conflict")
    pu = snap.get("fc_prob_up")
    if pu is not None and ((side == "LONG" and pu < 0.45) or (side == "SHORT" and pu > 0.55)):
        out.append("fc_against")
    if snap.get("quality") is not None and snap["quality"] < 40:
        out.append("low_quality")
    return out


def _out_tags(rec: dict) -> list[str]:
    r, mfe, why = float(rec.get("r") or 0), float(rec.get("mfe") or 0), str(rec.get("reason") or "")
    out = []
    if r <= 0 and why in ("stop", "sl") and mfe < 0.3:
        out.append("early_fail")
    if r <= 0.1 and mfe >= 1.0:
        out.append("gave_back")
    if why == "time":
        out.append("time_exit")
    if why == "signal_flip":
        out.append("flip_exit")
    if r > 0.5 and not out:
        out.append("clean_win")
    return out


def _lesson_text(rec: dict, tin: list[str], tout: list[str]) -> str:
    sym, side, r = str(rec.get("symbol", "")).replace("USDT", ""), rec.get("side"), float(rec.get("r") or 0)
    if r > 0.3:
        base = f"{sym} {('خرید' if side == 'LONG' else 'فروش')}: برد {r:+.2f}R"
        if tin:
            base += " — با وجود هشدار: " + "، ".join(TAG_FA[t] for t in tin[:2])
        return base
    parts = []
    if tout:
        parts.append(" · ".join(OUT_FA[t] for t in tout[:2]))
    if tin:
        parts.append("هشدارهای قبل از ورود: " + "، ".join(TAG_FA[t] for t in tin[:3]))
    if not parts:
        parts.append("ضرر عادی در چارچوب ریسک؛ نشانهٔ خطای مشخصی در ورود دیده نشد")
    return f"{sym} {('خرید' if side == 'LONG' else 'فروش')} ({r:+.2f}R): " + " | ".join(parts)


def on_close(rec: dict) -> None:
    """Post-mortem of one closed trade (called by the paper exchange)."""
    try:
        snap = rec.get("snap") or {}
        side = rec.get("side")
        tin, tout = tags_for(snap, side), _out_tags(rec)
        case = {"id": rec.get("id"), "symbol": rec.get("symbol"), "side": side, "t_open": rec.get("opened_at"), "t_close": rec.get("closed_at"),
                "r": float(rec.get("r") or 0), "pnl": float(rec.get("pnl") or 0), "win": float(rec.get("pnl") or 0) > 0, "reason": rec.get("reason"),
                "mfe": rec.get("mfe"), "mae": rec.get("mae"), "grade": rec.get("grade"), "regime": rec.get("regime") or snap.get("regime"),
                "plan": rec.get("plan"), "source": rec.get("source"), "tags_in": tin, "tags_out": tout, "fams": snap.get("fams") or {},
                "lesson": _lesson_text(rec, tin, tout)}
        with _LOCK:
            st = _load()
            st["cases"].append(case)
            del st["cases"][:-MAX_CASES]
            _save()
    except Exception:                                            # noqa: BLE001 — learning must never break trading
        pass


def _stat(cs: list[dict]) -> dict:
    n = len(cs)
    w = sum(1 for c in cs if c["win"])
    sr = sum(c["r"] for c in cs)
    return {"n": n, "wins": w, "win": round(w / n * 100) if n else None, "sum_r": round(sr, 2), "avg_r": round(sr / n, 2) if n else None}


def tag_stats() -> dict:
    with _LOCK:
        cs = list(_load()["cases"])
    return {t: _stat([c for c in cs if t in c["tags_in"]]) for t in TAG_FA}


def check(symbol: str, side: str, snap: dict, grade: str = "") -> dict:
    """Gate for a new automatic entry. `ok` False only when REAL past trades of the same kind keep losing."""
    with _LOCK:
        cs = list(_load()["cases"])
    fails, warns, notes = [], [], []
    now = time.time()
    # 1) the same coin + side lost twice in a row recently → rest it
    mine = [c for c in cs if c["symbol"] == symbol and c["side"] == side][-2:]
    if len(mine) == 2 and all(not c["win"] for c in mine) and now - (mine[-1]["t_close"] or 0) < 12 * 3600:
        fails.append(f"{symbol.replace('USDT', '')} {('خرید' if side == 'LONG' else 'فروش')} دو بار پیاپی باخته؛ ۱۲ ساعت استراحت")
    # 2) the last 6 trades of this coin are clearly negative → only grade A may re-enter
    last6 = [c for c in cs if c["symbol"] == symbol][-6:]
    if len(last6) >= 4 and sum(c["r"] for c in last6) <= -3.0 and grade != "A":
        fails.append(f"مجموع {len(last6)} معاملهٔ اخیر این ارز {sum(c['r'] for c in last6):+.1f}R است؛ فقط درجه A مجاز")
    # 3) warning conditions that have repeatedly lost
    for t in tags_for(snap, side):
        s = _stat([c for c in cs if t in c["tags_in"]])
        if s["n"] >= 4 and s["win"] <= 25 and s["sum_r"] < 0:
            fails.append(f"اشتباه تکراری «{TAG_FA[t]}»: {s['n']} بار، {s['n'] - s['wins']} باخت ({s['sum_r']:+.1f}R)")
        elif s["n"] >= 3 and s["win"] <= 34 and s["sum_r"] < 0:
            warns.append(f"«{TAG_FA[t]}» قبلاً {s['n']} بار با {s['win']}٪ برد همراه بوده")
    # 4) the whole setup bucket (side, regime, grade)
    b = [c for c in cs if c["side"] == side and c.get("regime") == snap.get("regime") and c.get("grade") == grade]
    sb = _stat(b)
    if sb["n"] >= 6 and sb["avg_r"] is not None and sb["avg_r"] <= -0.4:
        fails.append(f"این نوع ستاپ ({side}/{snap.get('regime')}/{grade}) در {sb['n']} معامله میانگین {sb['avg_r']:+.2f}R داشته")
    if not cs:
        notes.append("هنوز معاملهٔ بسته‌شده‌ای برای یادگیری نیست")
    return {"ok": not fails, "fails": fails, "warns": warns, "notes": notes, "n_cases": len(cs)}


def advice(symbol: str, side: str, snap: dict, grade: str = "") -> dict:
    """Same evidence as `check`, for display next to a signal (never blocks anything by itself)."""
    r = check(symbol, side, snap, grade)
    r["tags"] = [{"k": t, "fa": TAG_FA[t]} for t in tags_for(snap, side)]
    return r


def summary() -> dict:
    with _LOCK:
        cs = list(_load()["cases"])
    fam: dict = {}
    for c in cs:
        d = 1 if c["side"] == "LONG" else -1
        for k, v in (c.get("fams") or {}).items():
            if k == "data_trust" or v is None:
                continue
            side_ = "aligned" if v * d > 0.15 else "opposed" if v * d < -0.15 else None
            if side_:
                fam.setdefault(k, {"aligned": [], "opposed": []})[side_].append(c)
    fam_out = {k: {"aligned": _stat(v["aligned"]), "opposed": _stat(v["opposed"])} for k, v in fam.items()}
    out_stats = {}
    for t in OUT_FA:
        sub = [c for c in cs if t in c["tags_out"]]
        if sub:
            out_stats[t] = {"fa": OUT_FA[t], **_stat(sub)}
    by_sym = {}
    for c in cs:
        by_sym.setdefault(c["symbol"], []).append(c)
    return {"total": _stat(cs), "cases": cs[-40:][::-1], "tags": {t: {"fa": TAG_FA[t], **s} for t, s in tag_stats().items()},
            "outcomes": out_stats, "families": fam_out, "symbols": {k: _stat(v) for k, v in by_sym.items()},
            "rules": _active_rules(cs)}


def _active_rules(cs: list[dict]) -> list[dict]:
    rules = []
    for t in TAG_FA:
        s = _stat([c for c in cs if t in c["tags_in"]])
        if s["n"] >= 3 and s["win"] is not None and s["win"] <= 34 and s["sum_r"] < 0:
            rules.append({"kind": "tag", "text": f"«{TAG_FA[t]}» → {'ممنوع' if s['n'] >= 4 and s['win'] <= 25 else 'هشدار'}", **s})
    return rules


def reset() -> None:
    global _ST
    with _LOCK:
        _ST = {"cases": []}
        _save()
