"""Saved looks (named presets of theme + interface + layout [+ watchlist + scan interval]) and the custom background image.
Everything lives ONLY in XXX/ (presets: XXX/ui_presets.json, images: XXX/ui/)."""
from __future__ import annotations
import base64
import json
import os
import re
import shutil
import threading
import time

from app.config import DATA_DIR

_DIR = DATA_DIR / "ui"
_FILE = DATA_DIR / "ui_presets.json"
_LOCK = threading.RLock()
_MAX_PRESETS = 40
_MAX_UI_BYTES = 200_000
_MAX_IMG_BYTES = 3_500_000
_DIR.mkdir(parents=True, exist_ok=True)


def _atomic(path, data: bytes) -> None:
    tmp = path.with_name(path.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def _load() -> dict:
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        if isinstance(raw, dict) and isinstance(raw.get("presets"), dict):
            return raw
    except Exception:                                            # noqa: BLE001
        pass
    return {"presets": {}, "active": None}


def _save(st: dict) -> None:
    _atomic(_FILE, json.dumps(st, ensure_ascii=False, indent=1).encode("utf-8"))


def _slug(name: str) -> str:
    return re.sub(r"[^0-9A-Za-z\u0600-\u06FF_-]+", "_", name.strip())[:40].strip("_") or "preset"


def clean_name(name: str) -> str:
    n = re.sub(r"\s+", " ", str(name or "")).strip()[:40]
    if not n:
        raise ValueError("نام ذخیره خالی است")
    return n


# ── background image ───────────────────────────────────────────────────────
def bg_path():
    return _DIR / "bg.jpg"


def set_bg(data_url: str) -> dict:
    m = re.match(r"^data:image/(jpeg|jpg|png|webp);base64,(.+)$", str(data_url or ""), re.S)
    if not m:
        raise ValueError("تصویر نامعتبر")
    raw = base64.b64decode(m.group(2), validate=False)
    if not raw or len(raw) > _MAX_IMG_BYTES:
        raise ValueError("حجم تصویر زیاد است (حداکثر ۳٫۵ مگابایت)")
    with _LOCK:
        _atomic(bg_path(), raw)
    return {"ok": True, "v": int(time.time()), "bytes": len(raw)}


def clear_bg() -> dict:
    with _LOCK:
        try:
            bg_path().unlink()
        except FileNotFoundError:
            pass
    return {"ok": True}


def has_bg() -> bool:
    return bg_path().is_file()


# ── presets ────────────────────────────────────────────────────────────────
def list_presets() -> dict:
    with _LOCK:
        st = _load()
    rows = [{"name": n, "saved": p.get("saved"), "has_watchlist": bool(p.get("watchlist")), "n_coins": len(p.get("watchlist") or []),
             "has_scan": p.get("scan_sec") is not None, "has_bg": bool(p.get("bg")), "theme": (p.get("ui") or {}).get("p", {}).get("preset")}
            for n, p in st["presets"].items()]
    rows.sort(key=lambda r: -(r["saved"] or 0))
    return {"presets": rows, "active": st.get("active"), "max": _MAX_PRESETS}


def save_preset(name: str, ui: dict, watchlist: list | None = None, scan_sec: int | None = None) -> dict:
    name = clean_name(name)
    if not isinstance(ui, dict) or len(json.dumps(ui)) > _MAX_UI_BYTES:
        raise ValueError("تنظیمات رابط نامعتبر یا بزرگ است")
    with _LOCK:
        st = _load()
        if name not in st["presets"] and len(st["presets"]) >= _MAX_PRESETS:
            raise ValueError(f"حداکثر {_MAX_PRESETS} ذخیره مجاز است")
        p = {"name": name, "saved": time.time(), "ui": ui}
        if watchlist:
            p["watchlist"] = [str(x) for x in watchlist][:80]
        if scan_sec is not None:
            p["scan_sec"] = int(scan_sec)
        if has_bg() and (ui.get("p") or {}).get("bgmode") == "image":
            f = _DIR / f"bg_{_slug(name)}.jpg"
            shutil.copyfile(bg_path(), f)
            p["bg"] = f.name
        else:
            old = (st["presets"].get(name) or {}).get("bg")
            if old:
                try:
                    (_DIR / old).unlink()
                except OSError:
                    pass
        st["presets"][name] = p
        st["active"] = name
        _save(st)
    return {"ok": True, **list_presets()}


def get_preset(name: str) -> dict | None:
    with _LOCK:
        p = _load()["presets"].get(name)
        return json.loads(json.dumps(p)) if p else None


def apply_bg_of(p: dict) -> bool:
    """Put the preset's saved background back as the active one (or clear it when the preset has none)."""
    f = p.get("bg")
    with _LOCK:
        if f and (_DIR / f).is_file():
            shutil.copyfile(_DIR / f, bg_path())
            return True
    return False


def set_active(name: str | None) -> None:
    with _LOCK:
        st = _load()
        st["active"] = name
        _save(st)


def delete_preset(name: str) -> dict:
    with _LOCK:
        st = _load()
        p = st["presets"].pop(name, None)
        if p and p.get("bg"):
            try:
                (_DIR / p["bg"]).unlink()
            except OSError:
                pass
        if st.get("active") == name:
            st["active"] = None
        _save(st)
    return {"ok": bool(p), **list_presets()}
