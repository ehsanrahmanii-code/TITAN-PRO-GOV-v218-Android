"""TITAN PRO Clean — Flask API + dashboard."""
from __future__ import annotations
import math
from urllib.parse import urlparse

from flask import Flask, jsonify, request, render_template, send_file, abort
from flask.json.provider import DefaultJSONProvider

from app import settings
from app.config import (HOST, PORT, VERSION, TIMEFRAMES, DATA_DIR, to_symbol, valid_symbol, to_base, KLINE_LIMIT, MAX_LEVERAGE,
                        FORECAST_CANDLES, SIDE_THRESHOLD, CHART_KLINES, STARTING_CAPITAL, RISK_PER_TRADE_PCT, FEE_TAKER, SLIPPAGE, TF_MS, TF_FA)
from app.engine import scanner
from app.data.market import fetch_klines, fetch_prices, fetch_ticker, closed_only, fetch_depth, fetch_derivs, search_pairs
from app.analysis import backtest as bt
from app.analysis import patterns as pat
from app.engine import alerts as alerts_mod, evidence, siglog, context, readiness
from app.engine import learn as learn_mod
from app.exchange import policy
from app.analysis import planner
from app.analysis.technicals import analyze
from app.ai.gemini import ai_opinion
from app import core, ui_store
from app.engine import lessons
from app.exchange import paper as exchange

def _clean(o):
    """Recursively replace NaN / ±Infinity (invalid JSON) by null and numpy scalars by Python scalars."""
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if hasattr(o, "item") and callable(o.item) and type(o).__module__ == "numpy":
        return _clean(o.item())
    return o


class _SafeJSON(DefaultJSONProvider):
    def dumps(self, obj, **kw):
        return super().dumps(_clean(obj), **kw)


app = Flask(__name__, template_folder="templates", static_folder="static")
app.json_provider_class = _SafeJSON
app.json = _SafeJSON(app)
app.json.ensure_ascii = False
_LOCAL_HOSTS = {"127.0.0.1", "localhost", "[::1]", "::1"}


@app.before_request
def _same_origin_guard():
    """Block cross-site POSTs (a random web page must not be able to trade your paper account) and DNS-rebinding."""
    if HOST in ("127.0.0.1", "localhost", "::1") and request.host.rsplit(":", 1)[0].strip("[]") not in {h.strip("[]") for h in _LOCAL_HOSTS}:
        return jsonify({"ok": False, "error": "host not allowed"}), 403
    if request.method in ("POST", "DELETE", "PUT"):
        o = request.headers.get("Origin")
        if o and urlparse(o).netloc != request.host:
            return jsonify({"ok": False, "error": "cross-origin blocked"}), 403


_GZ_TYPES = ("application/json", "application/javascript", "text/javascript", "text/css", "text/html", "image/svg+xml")


def _gzip(resp):
    """Compress big text responses (API JSON is 100-200 KB per call) when the client accepts gzip. Stdlib only."""
    try:
        if (resp.status_code != 200 or resp.headers.get("Content-Encoding") or "gzip" not in request.headers.get("Accept-Encoding", "")
                or not (resp.mimetype or "").startswith(_GZ_TYPES) or request.method == "HEAD"):
            return resp
        resp.direct_passthrough = False                       # static files are streamed; we need the bytes
        data = resp.get_data()
        if len(data) < 1024:
            return resp
        import gzip as _g
        resp.set_data(_g.compress(data, compresslevel=5))
        resp.headers["Content-Encoding"] = "gzip"
        resp.headers["Content-Length"] = str(len(resp.get_data()))
        resp.headers.add("Vary", "Accept-Encoding")
        et = resp.headers.get("ETag")
        if et and not et.startswith("W/"):
            resp.headers["ETag"] = "W/" + et                  # the body bytes changed, so the tag can only be weak
    except Exception:                                         # noqa: BLE001 - compression is an optimisation, never an error
        pass
    return resp


@app.after_request
def _headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return _gzip(resp)


@app.errorhandler(Exception)
def _err(e):
    code = getattr(e, "code", 500)
    return jsonify({"ok": False, "error": str(e)[:200]}), code if isinstance(code, int) else 500


def _sym_or_400(s: str):
    s = to_symbol(s)
    return s if valid_symbol(s) else None


def _tf(default="1h") -> str:
    t = request.args.get("tf", default)
    return t if t in TIMEFRAMES else default


CHART_TFS = ["1m", "5m"] + list(TIMEFRAMES)        # chart-only extras (signals still use TIMEFRAMES)


@app.route("/")
def index():
    return render_template("index.html", version=VERSION)


@app.route("/api/status")
def api_status():
    return jsonify({"version": VERSION, "timeframes": TIMEFRAMES, "symbols": settings.get_watchlist(),
                    "data_dir": str(DATA_DIR), "max_leverage": MAX_LEVERAGE, "scan_sec": settings.get_scan_sec(),
                    "threshold": SIDE_THRESHOLD, "forecast_n": FORECAST_CANDLES, "start_capital": STARTING_CAPITAL,
                    "risk_pct": RISK_PER_TRADE_PCT, "fee": FEE_TAKER, "slip": SLIPPAGE, "now": int(__import__("time").time() * 1000),
                    "tf_ms": {t: TF_MS[t] for t in TIMEFRAMES}, "tf_fa": {t: TF_FA[t] for t in TIMEFRAMES}, "data_name": DATA_DIR.name,
                    "core_health": core.snapshot()["health"], "fresh_limit": scanner.fresh_limit(), **scanner.get_status()})


@app.route("/api/scan", methods=["POST"])
def api_scan():
    """force=1 → bypass every cache (candles and prices straight from the exchanges, no analysis reuse). The UI's scan button always sends it."""
    syms = [to_symbol(s) for s in request.args.getlist("symbol") if valid_symbol(s)] or None
    tfs = [t for t in request.args.getlist("tf") if t in TIMEFRAMES] or (None if request.args.get("full") == "1" else ["1h"])
    return jsonify(scanner.start_scan(syms, tfs, force=request.args.get("force") == "1"))


@app.route("/api/data/health")
def api_data_health():
    """How old is every number on screen? Per coin × timeframe: age, source, freshness, last error."""
    import time as _t
    now = _t.time()
    rows = {}
    for sym in settings.get_watchlist():
        rows[sym] = {}
        for tf in TIMEFRAMES:
            it = scanner.get_cache_item(sym, tf)
            rows[sym][tf] = None if not it or "signal" not in it else {
                "age": int(now - it.get("updated", now)), "fresh": scanner.is_fresh(it), "stale": bool(it.get("stale")), "restored": bool(it.get("restored")),
                "reused": bool(it.get("reused")), "kl_source": it.get("kl_source"), "price_src": it.get("price_src"),
                "price_age": int(now - float(it.get("price_ts") or it.get("updated", now))), "error": it.get("last_error")}
    return jsonify({"limit_s": scanner.fresh_limit(), "now": int(now * 1000), "rows": rows, **{k: v for k, v in scanner.get_status().items() if k in ("last_scan", "scanning", "sources")}})


@app.route("/api/symbols/search")
def api_symbols_search():
    """USDT pairs from the exchanges for the 'add coin' picker (best volume first)."""
    try:
        return jsonify({"ok": True, "rows": search_pairs(request.args.get("q", ""), 40)})
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"ok": False, "rows": [], "error": str(e)[:120]})


def _symbol_exists(sym: str) -> bool:
    try:
        df = fetch_klines(sym, "1h", 60, force=True)
        return df is not None and len(df) >= 30
    except Exception:                                            # noqa: BLE001
        return False


@app.route("/api/matrix")
def api_matrix():
    return jsonify(scanner.get_matrix())


def _on_demand(symbol: str, tf: str, force: bool = False) -> dict:
    try:
        tk = fetch_ticker(symbol)
        tk = tk if tk and tk.get("price") else None
    except Exception:                                            # noqa: BLE001
        tk = None
    return scanner.scan_one(symbol, tf, tk, force=force)


@app.route("/api/coin/<symbol>")
def api_coin(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    tf = _tf()
    item = scanner.get_cache_item(sym, tf)
    if not item or not scanner.is_fresh(item):                   # missing OR old/restored/stale → analyse again from live data
        try:
            fresh_item = _on_demand(sym, tf, force=True)
            scanner.put_cache_item(sym, tf, fresh_item)
            item = fresh_item
        except Exception as e:                                   # noqa: BLE001
            if not item:
                return jsonify({"error": str(e)[:160]})
            item = dict(item); item["last_error"] = str(e)[:160]
    out = dict(item)
    out["fresh"] = scanner.is_fresh(item)
    out["all_tf"] = {t: c["signal"] for t in TIMEFRAMES if (c := scanner.get_cache_item(sym, t)) and "signal" in c}
    out["all_forecasts"] = {t: c.get("forecast") for t in TIMEFRAMES if (c := scanner.get_cache_item(sym, t)) and "signal" in c}
    out["all_fresh"] = {t: scanner.is_fresh(scanner.get_cache_item(sym, t)) for t in TIMEFRAMES}
    out["base"] = to_base(sym)
    out["now"] = int(__import__("time").time() * 1000)
    out["bar_ms"] = TF_MS.get(tf)
    return jsonify(out)


@app.route("/api/deep/<symbol>")
def api_deep(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        d = dict(scanner.build_deep(sym, _tf()))
        side = d.get("verdict") if d.get("verdict") in ("LONG", "SHORT") else None
        if side:
            d["lessons"] = lessons.advice(sym, side, scanner.make_snap(d), (d.get("grade") or {}).get("grade", ""))
        d["auto_ledger"] = [x for x in exchange.get_account({}).get("auto_log", []) if x.get("symbol") == sym][-5:]
        return jsonify(d)
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/ai/<symbol>")
def api_ai(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"ok": False, "error": "نماد نامعتبر"}), 400
    try:
        deep = scanner.build_deep(sym, _tf())
        item = scanner.get_cache_item(sym, _tf())
        return jsonify(ai_opinion(sym, deep, (item or {}).get("ticker")))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"ok": False, "error": str(e)[:160]})


_BT_CACHE: dict = {}


@app.route("/api/market")
def api_market():
    return jsonify(scanner.market_overview())


@app.route("/api/readiness")
def api_readiness():
    return jsonify(readiness.assess())


@app.route("/api/context")
def api_context():
    return jsonify(context.overview())


@app.route("/api/context/<symbol>")
def api_context_symbol(symbol):
    sym = to_symbol(symbol)
    if not valid_symbol(sym):
        return jsonify({"error": "نماد نامعتبر"}), 400
    return jsonify(context.get(sym) or {"error": "هنوز دادهٔ بافت بازار برای این ارز آماده نیست"})


@app.route("/api/micro/<symbol>")
def api_micro(symbol):
    """Order-book depth + perpetual derivatives (funding, OI, long/short). Each part fails independently."""
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    out = {"symbol": sym}
    for k, fn in (("depth", fetch_depth), ("derivs", fetch_derivs)):
        try:
            out[k] = fn(sym)
        except Exception as e:                                   # noqa: BLE001
            out[k] = {"ok": False, "reason": str(e)[:80]}
    return jsonify(out)


def _backtest(sym: str, tf: str) -> dict:
    full = fetch_klines(sym, tf, 500)
    df = closed_only(full, tf)
    key = (sym, tf, str(df["open_time"].iloc[-1]))
    hit = _BT_CACHE.get(key)
    if hit and __import__("time").time() - hit[0] < 600:
        return hit[1]
    res = bt.run(df, sym, tf)
    res.update(symbol=sym, tf=tf, candles=len(df))
    _BT_CACHE.clear() if len(_BT_CACHE) > 40 else None
    _BT_CACHE[key] = (__import__("time").time(), res)
    return res


@app.route("/api/report/<symbol>")
def api_report(symbol):
    """Coin Lab: unified deep analysis of one coin (every section x every timeframe + final verdict)."""
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"ok": False, "error": "نماد نامعتبر"}), 400
    tf = _tf()
    micro = {}
    for k, fn in (("depth", fetch_depth), ("derivs", fetch_derivs)):
        try:
            micro[k] = fn(sym)
        except Exception as e:                                   # noqa: BLE001
            micro[k] = {"ok": False, "reason": str(e)[:80]}
    try:
        btr = _backtest(sym, tf)
    except Exception:                                            # noqa: BLE001
        btr = None
    try:
        return jsonify(scanner.build_report(sym, tf, micro, btr))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"ok": False, "error": str(e)[:160]})


@app.route("/api/exchange/performance")
def api_perf():
    return jsonify(exchange.performance())


@app.route("/api/backtest/<symbol>")
def api_backtest(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        return jsonify(_backtest(sym, _tf()))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/patterns/<symbol>")
def api_patterns(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        return jsonify(scanner.pattern_view(sym, _tf()))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/timeline/<symbol>")
def api_timeline(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        return jsonify(scanner.build_timeline(sym))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/trend/<symbol>")
def api_trend(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        return jsonify(scanner.trend_view(sym))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"ok": False, "error": str(e)[:160]})


@app.route("/api/lessons")
def api_lessons():
    return jsonify(lessons.summary())


@app.route("/api/lessons/reset", methods=["POST"])
def api_lessons_reset():
    lessons.reset()
    return jsonify({"ok": True})


@app.route("/api/core")
def api_core():
    st = scanner.get_status()
    return jsonify(core.snapshot({"scan": {"scanning": st["scanning"], "last_scan": st["last_scan"], "duration": st["duration"], "progress": st["progress"],
                                           "errors": st["errors"]}, "sources": st["sources"], "version": VERSION,
                                  "auto": exchange.pause_state() if hasattr(exchange, "pause_state") else None}))


@app.route("/api/core/toggle", methods=["POST"])
def api_core_toggle():
    b = request.get_json(force=True, silent=True) or {}
    return jsonify(core.set_enabled(str(b.get("mod", "")), bool(b.get("enabled", True))))


@app.route("/api/alerts", methods=["GET", "POST"])
def api_alerts():
    if request.method == "POST":
        try:
            return jsonify(alerts_mod.add(request.get_json(force=True, silent=True) or {}))
        except (ValueError, TypeError):
            return jsonify({"ok": False, "error": "ورودی هشدار نامعتبر است (نماد و قیمت عددی لازم است)"}), 400
    scanner.alerts_tick()
    return jsonify({"alerts": alerts_mod.list_all()})


@app.route("/api/alerts/<aid>", methods=["DELETE"])
def api_alert_del(aid):
    return jsonify({"ok": alerts_mod.remove(aid)})


_PLAN_CACHE: dict = {}


@app.route("/api/plan/<symbol>")
def api_plan(symbol):
    """Entry / stop / target laboratory (both sides) for the current candle."""
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    tf = _tf()
    try:
        full = fetch_klines(sym, tf, KLINE_LIMIT)
        df = closed_only(full, tf)
        key = (sym, tf, str(df["open_time"].iloc[-1]), round(float(df["close"].iloc[-1]), 8))
        hit = _PLAN_CACHE.get(key)
        if hit and __import__("time").time() - hit[0] < 20:
            return jsonify(hit[1])
        px = scanner.live_price(sym) or float((fetch_ticker(sym) or {}).get("price") or 0) or float(df["close"].iloc[-1])
        sig = analyze(df, sym, tf, price=px).to_dict()
        lab = scanner.plan_lab(sym, tf, df, sig, px)
        lab.update(symbol=sym, tf=tf, verdict_side=sig["side"], zones=(sig.get("levels") or {}).get("zones", []))
        _PLAN_CACHE.clear() if len(_PLAN_CACHE) > 40 else None
        _PLAN_CACHE[key] = (__import__("time").time(), lab)
        return jsonify(lab)
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/order", methods=["POST"])
def api_order():
    b = request.get_json(force=True, silent=True) or {}
    sym = _sym_or_400(str(b.get("symbol", "")))
    if not sym:
        return jsonify({"ok": False, "error": "نماد نامعتبر"})
    b["symbol"], b["source"] = sym, "manual"
    if b.get("mode") == "market":
        prices = _live_prices(); px = prices.get(sym)
        if not px:
            return jsonify({"ok": False, "error": "قیمت زنده در دسترس نیست"})
        try:
            return jsonify(exchange.open_position(sym, b.get("side", ""), px, float(b["stop"]), float(b["tp1"]), float(b["tp2"]), float(b.get("tp3") or 0), leverage=int(b.get("leverage") or 10),
                                                  risk_pct=float(b.get("risk_pct") or 0) or None, prices=prices, plan=str(b.get("plan", ""))[:40], deadline_sec=float(b.get("deadline_h") or 0) * 3600))
        except (KeyError, TypeError, ValueError):
            return jsonify({"ok": False, "error": "ورودی نامعتبر"})
    return jsonify(exchange.place_order(b))


@app.route("/api/order/cancel", methods=["POST"])
def api_order_cancel():
    return jsonify(exchange.cancel_order(str((request.get_json(force=True, silent=True) or {}).get("id", ""))))


@app.route("/api/auto/config", methods=["GET", "POST"])
def api_auto_cfg():
    if request.method == "POST":
        try:
            policy.save_cfg(request.get_json(force=True, silent=True) or {})
        except (ValueError, TypeError):
            return jsonify({"ok": False, "error": "تنظیمات خودکار نامعتبر است"}), 400
    return jsonify({"cfg": policy.effective(), "modes": {k: v for k, v in policy.MODES.items()}, "pause": exchange.pause_state()})


@app.route("/api/auto/resume", methods=["POST"])
def api_auto_resume():
    return jsonify(exchange.clear_pause())


@app.route("/api/evidence")
def api_evidence():
    return jsonify({"rows": evidence.all_rows(), "agg": evidence.aggregate()})


@app.route("/api/calibration")
def api_calibration():
    """Measured win rate per confidence band / side / grade from the resolved signal log (what «70 %» really means here)."""
    from app.engine import calibrate
    return jsonify(calibrate.table())


@app.route("/api/learn")
def api_learn():
    """Lightweight governor learning status (reliability tilts)."""
    try:
        return jsonify(learn_mod.get_status())
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": str(e)[:160]}), 500


@app.route("/api/signals/log")
def api_siglog():
    return jsonify(siglog.view())


@app.route("/api/klines/<symbol>")
def api_klines(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        limit = max(30, min(int(request.args.get("limit", 200)), 300))
    except ValueError:
        limit = 200
    try:
        tf = request.args.get("tf", "1h")
        tf = tf if tf in CHART_TFS else "1h"
        df = fetch_klines(sym, tf, limit).tail(limit)
        return jsonify({"symbol": sym, "tf": tf, "bar_ms": TF_MS.get(tf), "stale": bool(df.attrs.get("stale")), "fetched_at": df.attrs.get("fetched_at"),
                        "source": df.attrs.get("source"), "klines": [
            {"t": int(r.open_time.timestamp() * 1000), "o": float(r.open), "h": float(r.high), "l": float(r.low),
             "c": float(r.close), "v": float(r.volume)} for r in df.itertuples()]})
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]}), 502


def _live_prices() -> dict:
    try:
        return fetch_prices(settings.get_watchlist() + [p["symbol"] for p in exchange.get_account()["open_positions"]])
    except Exception:                                            # noqa: BLE001
        return {}


@app.route("/api/exchange")
def api_exchange():
    return jsonify(exchange.get_account(_live_prices()))


@app.route("/api/exchange/open", methods=["POST"])
def api_open():
    b = request.get_json(force=True, silent=True) or {}
    sym = _sym_or_400(str(b.get("symbol", "")))
    if not sym:
        return jsonify({"ok": False, "error": "نماد نامعتبر"})
    try:
        prices = _live_prices()
        entry = prices.get(sym)
        if not entry:
            return jsonify({"ok": False, "error": "قیمت زنده در دسترس نیست"})
        return jsonify(exchange.open_position(
            sym, b.get("side", ""), entry, float(b.get("stop", 0)), float(b.get("tp1", 0)), float(b.get("tp2", 0)),
            float(b.get("tp3", 0) or 0), leverage=int(b.get("leverage", 10)), prices=prices,
            score=float(b.get("score", 0) or 0), regime=str(b.get("regime", ""))[:12]))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "ورودی نامعتبر"})


@app.route("/api/exchange/close", methods=["POST"])
def api_close():
    b = request.get_json(force=True, silent=True) or {}
    pid = str(b.get("id", ""))
    pos = next((p for p in exchange.get_account()["open_positions"] if p["id"] == pid), None)
    if not pos:
        return jsonify({"ok": False, "error": "یافت نشد"})
    try:
        price = fetch_ticker(pos["symbol"])["price"]               # always the LIVE price (v1 closed at entry!)
    except Exception:                                            # noqa: BLE001
        return jsonify({"ok": False, "error": "قیمت زنده در دسترس نیست"})
    return jsonify(exchange.close_position(pid, price))


@app.route("/api/exchange/auto", methods=["POST"])
def api_auto():
    b = request.get_json(force=True, silent=True) or {}
    return jsonify(exchange.set_auto_trade(bool(b.get("enabled", False))))


@app.route("/api/exchange/reset", methods=["POST"])
def api_reset():
    return jsonify(exchange.reset_account())


@app.route("/api/settings", methods=["GET", "POST"])
def api_settings():
    if request.method == "GET":
        return jsonify(settings.get())
    patch = request.get_json(force=True, silent=True) or {}
    added: list[str] = []
    try:
        if "watchlist" in patch:
            wanted = settings.normalize_symbols(patch["watchlist"])
            current = set(settings.get_watchlist())
            added = [x for x in wanted if x not in current]
            bad = [x for x in added if not _symbol_exists(x)]
            if bad:                                                # never save a coin no exchange knows: it would scan as an error forever
                return jsonify({"ok": False, "error": "این نماد در هیچ صرافی پیدا نشد: " + "، ".join(b[:-4] for b in bad)}), 400
        out = settings.update(patch)
    except (ValueError, TypeError) as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    if "watchlist" in patch:
        out = dict(out)
        out["scan"] = scanner.start_scan(added or None, None, force=True) if added else scanner.start_scan(None, ["1h"], force=True) if patch.get("rescan") else None
        out["added"] = added
    return jsonify(out)


@app.route("/api/watchlist/add", methods=["POST"])
def api_watchlist_add():
    """Register one or several new coins ("ARB OP INJ APT" / list). Each is checked on the exchanges in parallel; valid ones are saved
    and scanned immediately (no cache); unknown ones are reported back instead of failing the whole request."""
    import re as _re
    from concurrent.futures import ThreadPoolExecutor
    from app.config import MAX_WATCHLIST
    b = request.get_json(force=True, silent=True) or {}
    raw = b.get("symbols") or []
    toks = [t for t in (_re.split(r"[\s,،;؛]+", raw) if isinstance(raw, str) else [str(x) for x in raw]) if t.strip()][:20]
    current = settings.get_watchlist()
    new, already, rejected = [], [], []
    for t in toks:
        n = settings.normalize_symbols([t])
        if not n:
            rejected.append(t.upper()[:14]); continue
        sym = n[0]
        (already if sym in current else new if sym not in new else already).append(sym)
    room = max(0, MAX_WATCHLIST - len(current))
    skipped, new = new[room:], new[:room]
    ok: list[str] = []
    if new:
        with ThreadPoolExecutor(max_workers=min(6, len(new))) as ex:
            for sym, good in zip(new, ex.map(_symbol_exists, new)):
                (ok if good else rejected).append(sym)
    scan = None
    if ok:
        try:
            settings.update({"watchlist": current + ok})
        except (ValueError, TypeError) as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        scan = scanner.start_scan(ok, None, force=True)
    return jsonify({"ok": bool(ok), "added": ok, "already": already, "rejected": [r[:-4] if r.endswith("USDT") else r for r in rejected],
                    "skipped": skipped, "watchlist": settings.get_watchlist(), "scan": scan})


# ── saved looks (themes / interface / layout) + background image — all inside XXX/ ──
@app.route("/api/presets", methods=["GET", "POST"])
def api_presets():
    if request.method == "GET":
        return jsonify(ui_store.list_presets())
    b = request.get_json(force=True, silent=True) or {}
    try:
        wl = settings.get_watchlist() if b.get("include_watchlist") else None
        scan = settings.get_scan_sec() if b.get("include_scan") else None
        return jsonify(ui_store.save_preset(b.get("name", ""), b.get("ui") or settings.get().get("ui") or {}, wl, scan))
    except ValueError as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/presets/load", methods=["POST"])
def api_presets_load():
    b = request.get_json(force=True, silent=True) or {}
    p = ui_store.get_preset(str(b.get("name", "")))
    if not p:
        return jsonify({"ok": False, "error": "ذخیره پیدا نشد"}), 404
    patch: dict = {"ui": p.get("ui") or {}}
    if b.get("apply_scan", True) and p.get("scan_sec") is not None:
        patch["scan_sec"] = p["scan_sec"]
    added: list[str] = []
    if b.get("apply_watchlist", True) and p.get("watchlist"):
        patch["watchlist"] = p["watchlist"]
        added = [x for x in settings.normalize_symbols(p["watchlist"]) if x not in set(settings.get_watchlist())]
    try:
        st = settings.update(patch)
    except (ValueError, TypeError) as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    bg = ui_store.apply_bg_of(p)
    ui_store.set_active(p["name"])
    scan = scanner.start_scan(added, None, force=True) if added else None
    return jsonify({"ok": True, "settings": st, "bg": bg, "scan": scan, "name": p["name"]})


@app.route("/api/presets/<path:name>", methods=["DELETE"])
def api_presets_del(name):
    return jsonify(ui_store.delete_preset(name))


@app.route("/api/ui/bg", methods=["POST", "DELETE"])
def api_ui_bg():
    if request.method == "DELETE":
        return jsonify(ui_store.clear_bg())
    try:
        return jsonify(ui_store.set_bg((request.get_json(force=True, silent=True) or {}).get("data", "")))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"ok": False, "error": str(e)[:120]}), 400


@app.route("/ui/bg.jpg")
def ui_bg():
    p = ui_store.bg_path()
    if not p.is_file():
        abort(404)
    r = send_file(p, mimetype="image/jpeg", max_age=0)
    r.headers["Cache-Control"] = "no-cache"
    return r


def main():
    from waitress import serve
    scanner.start_background()
    print(f"TITAN PRO GOV {VERSION} → http://{HOST}:{PORT}   data: {DATA_DIR}")
    serve(app, host=HOST, port=PORT, threads=12)


if __name__ == "__main__":
    main()
