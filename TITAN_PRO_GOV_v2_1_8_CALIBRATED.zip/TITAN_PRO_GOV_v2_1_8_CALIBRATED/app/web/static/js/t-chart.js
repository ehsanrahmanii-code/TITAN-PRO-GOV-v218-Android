/* TITAN · chart. Every candle — past, forming and future — carries its own date/time (axis, crosshair, tooltip).
   Layers: candles, EMA, volume, 48-candle projection + probability cone, trade levels, S/R zones, patterns with validity windows. */
(function (W) {
  'use strict';
  const T = W.TT, K = T.col;

  const FA = /[\u0600-\u06FF]/;
  function put(c, str, x, y, align) { c.direction = FA.test(str) ? 'rtl' : 'ltr'; c.textAlign = align || 'left'; c.fillText(str, x, y); c.direction = 'ltr'; }
  const o = id => T.p(id);
  const upC = () => o('c_up') || K.bull, dnC = () => o('c_down') || K.bear;
  function sma(arr, n) { const out = []; let sum = 0; for (let i = 0; i < arr.length; i++) { sum += arr[i]; if (i >= n) sum -= arr[i - n]; out.push(i >= n - 1 ? sum / n : null); } return out; }
  function ema(arr, n) { const k = 2 / (n + 1); let e = arr[0]; return arr.map((v, i) => (e = i ? v * k + e * (1 - k) : v)); }
  function nice(x) { const e = Math.pow(10, Math.floor(Math.log10(x))), f = x / e; return (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * e; }
  function rgba(hex, a) { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }

  class Chart {
    constructor(host) {
      this.host = host; this.cv = document.createElement('canvas'); this.ctx = this.cv.getContext('2d');
      this.tipEl = document.createElement('div'); this.tipEl.className = 'ctip'; this.tipEl.hidden = true;
      host.appendChild(this.cv); host.appendChild(this.tipEl);
      this.d = null; this.layers = Object.assign({}, T.S.cfg.layers); this.vs = 0; this.bw = 8; this.mouse = null; this.drag = null; this.ptrs = new Map(); this.h = 460;
      this.pad = { l: 8, r: 74, t: 26, b: 42 };
      this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(host);
      const c = this.cv;
      c.addEventListener('pointerdown', e => this.down(e)); c.addEventListener('pointermove', e => this.move(e));
      c.addEventListener('pointerup', e => this.up(e)); c.addEventListener('pointercancel', e => this.up(e));
      c.addEventListener('pointerleave', () => { if (!this.drag) { this.mouse = null; this.tipEl.hidden = true; this.draw(); } });
      c.addEventListener('wheel', e => { e.preventDefault(); this.zoomAt(e.deltaY < 0 ? 1.12 : 1 / 1.12, this.localX(e)); }, { passive: false });
      c.addEventListener('dblclick', () => this.fit());
      this.resize();
    }
    applyOpts() { this.layers = Object.assign({}, T.S.cfg.layers, { ema: !!(o('ema1') || o('ema2') || o('ema3') || o('ema4')) && T.S.cfg.layers.ema }); this.pad.r = o('chside') === 'left' ? 8 : 74; this.pad.l = o('chside') === 'left' ? 74 : 8; if (this.d) this.prep(); }
    destroy() { this.ro.disconnect(); this.host.innerHTML = ''; }
    localX(e) { return e.clientX - this.cv.getBoundingClientRect().left; }
    resize() {
      const w = this.host.clientWidth || 600, h = this.h, dpr = Math.min(2, devicePixelRatio || 1);
      this.W = w; this.cv.width = Math.round(w * dpr); this.cv.height = Math.round(h * dpr); this.cv.style.height = h + 'px';
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0); this.pw = w - this.pad.l - this.pad.r;
      if (this.d && !this._fitted) this.fit(); else this.draw();
    }
    /** data: {klines, fc, tf, bar_ms, plan, zones, pats, structs, now} */
    set(d) {
      const first = !this.d || this.d.sym !== d.sym || this.d.tf !== d.tf;
      this.d = d; this.prep();
      if (first) { this._fitted = false; this.fit(); } else this.draw();
    }
    prep() {
      const d = this.d, ks = d.klines || [], ms = d.bar_ms || T.tfMs(d.tf);
      this.ms = ms; this.n = ks.length; this.T0 = ks.length ? ks[0].t : 0;
      this.idx = t => (t - this.T0) / ms; this.tAt = i => this.T0 + i * ms;
      const cl = ks.map(k => k.c); this.emas = [1, 2, 3, 4].map(i => o('ema' + i) ? { arr: ema(cl, +o('ema' + i + 'p')), col: o('c_ema' + i), p: +o('ema' + i + 'p') } : null);
      if (o('bb')) { const n = +o('bbp'), m = sma(cl, n); this.bb = m.map((mu, i) => { if (mu == null) return null; let v = 0; for (let j = i - n + 1; j <= i; j++) v += (cl[j] - mu) ** 2; const sd = Math.sqrt(v / n); return [mu - 2 * sd, mu, mu + 2 * sd]; }); } else this.bb = null;
      if (o('vwap')) { let pv = 0, vv = 0, day = null; this.vw = ks.map(k => { const d = new Date(k.t).getUTCDate(); if (d !== day) { pv = vv = 0; day = d; } const tp = (k.h + k.l + k.c) / 3; pv += tp * k.v; vv += k.v; return vv ? pv / vv : tp; }); } else this.vw = null;
      if (o('chs') === 'heikin') { let po = ks[0].o, pc = ks[0].c; this.ha = ks.map((k, i) => { const c = (k.o + k.h + k.l + k.c) / 4, op = i ? (po + pc) / 2 : (k.o + k.c) / 2; po = op; pc = c; return { o: op, c, h: Math.max(k.h, op, c), l: Math.min(k.l, op, c) }; }); } else this.ha = null;
      const fc = (d.fc && d.fc.candles) || [], lastT = ks.length ? ks[ks.length - 1].t : 0;
      this.fut = fc.filter(c => c.t > lastT);                      // true future candles (the forming one is the real last candle)
      this.fcAll = fc; this.total = this.n + this.fut.length;
    }
    fit() {
      if (!this.d) return; this._fitted = true;
      const nf = this.fut.length, show = Math.min(this.n, this.W < 640 ? 46 : +o('chbars')), tot = show + nf + 3;
      this.bw = T.clamp(this.pw / tot, 2.2, 22); this.vs = Math.max(-2, this.n - show); this.draw();
    }
    goNow() { this.vs = this.n - Math.floor(this.pw / this.bw * 0.55); this.draw(); }
    zoom(f) { this.zoomAt(f, this.pad.l + this.pw / 2); }
    zoomAt(f, x) { const a = this.vs + (x - this.pad.l) / this.bw; this.bw = T.clamp(this.bw * f, 2, 40); this.vs = a - (x - this.pad.l) / this.bw; this.clampVs(); this.draw(); }
    clampVs() { const vis = this.pw / this.bw; this.vs = T.clamp(this.vs, -vis * 0.5, this.total - vis * 0.45); }
    down(e) {
      this.cv.setPointerCapture(e.pointerId); this.ptrs.set(e.pointerId, e.clientX);
      this.drag = { x: e.clientX, vs: this.vs, moved: false, pinch: null };
      if (this.ptrs.size === 2) { const v = [...this.ptrs.values()]; this.drag.pinch = { d: Math.abs(v[0] - v[1]), bw: this.bw }; }
    }
    move(e) {
      const x = this.localX(e), y = e.clientY - this.cv.getBoundingClientRect().top;
      if (this.ptrs.has(e.pointerId)) this.ptrs.set(e.pointerId, e.clientX);
      if (this.drag && this.ptrs.size === 2 && this.drag.pinch) {
        const v = [...this.ptrs.values()], dd = Math.abs(v[0] - v[1]) || 1; this.bw = T.clamp(this.drag.pinch.bw * dd / this.drag.pinch.d, 2, 40); this.clampVs(); this.draw(); return;
      }
      if (this.drag && this.ptrs.size === 1 && (e.pointerType !== 'mouse' || e.buttons)) {
        const dx = e.clientX - this.drag.x; if (Math.abs(dx) > 3) this.drag.moved = true;
        if (this.drag.moved) { this.vs = this.drag.vs - dx / this.bw; this.clampVs(); this.tipEl.hidden = true; this.draw(); return; }
      }
      this.mouse = { x, y }; this.draw(); this.showTip();
    }
    up(e) { this.ptrs.delete(e.pointerId); if (!this.ptrs.size) this.drag = null; }

    /* ── geometry ── */
    X(i) { return this.pad.l + (i - this.vs + 0.5) * this.bw; }
    Y(p) { return this.pt + (this.hi - p) / (this.hi - this.lo) * this.ph; }
    range() {
      const d = this.d, a = Math.max(0, Math.floor(this.vs)), b = Math.min(this.n - 1, Math.ceil(this.vs + this.pw / this.bw));
      let lo = Infinity, hi = -Infinity;
      for (let i = a; i <= b; i++) { const k = d.klines[i]; if (k) { lo = Math.min(lo, k.l); hi = Math.max(hi, k.h); } }
      if (!isFinite(lo)) { const k = d.klines[this.n - 1]; lo = k.l; hi = k.h; }
      const L = this.layers;
      if (L.fc && this.fut.length) {
        const b2 = (d.fc && d.fc.bands) || {};
        if (L.cone && b2.p10) { lo = Math.min(lo, ...b2.p10.slice(0, 60)); hi = Math.max(hi, ...b2.p90.slice(0, 60)); }
        else this.fut.forEach(c => { lo = Math.min(lo, c.low); hi = Math.max(hi, c.high); });
      }
      const span = (hi - lo) || hi * 0.01;
      if (L.lv && d.plan && d.plan.side && d.plan.side !== 'WAIT') [d.plan.stop, d.plan.tp1, d.plan.tp2, d.plan.entry].forEach(v => { if (v && v > lo - span * 0.5 && v < hi + span * 0.5) { lo = Math.min(lo, v); hi = Math.max(hi, v); } });
      const pad = (hi - lo) * 0.07; this.lo = lo - pad; this.hi = hi + pad;
    }
    draw() {
      if (!this.d || !this.n) return;
      const c = this.ctx, W_ = this.W, H = this.h, p = this.pad, L = this.layers, d = this.d;
      c.clearRect(0, 0, W_, H);
      const volH = L.vol && +o('chvol') > 0 ? Math.round((H - p.t - p.b) * +o('chvol') / 100) : 0;
      this.pt = p.t; this.ph = H - p.t - p.b - volH - (volH ? 8 : 0); this.vy0 = this.pt + this.ph + 8; this.vh = volH;
      this.range();
      const a = Math.floor(this.vs) - 1, b = Math.ceil(this.vs + this.pw / this.bw) + 1;
      c.save(); c.beginPath(); c.rect(p.l, 0, this.pw, H); c.clip();
      this.drawGrid(a, b); this.drawWatermark(); this.drawZones(); this.drawFib(); this.drawFutureBg(); this.drawPatternBoxes(); this.drawCone(); this.drawAuto();
      if (L.lv) this.drawPosition(); this.drawEma(a, b); this.drawCandles(a, b); this.drawFutureCandles(); this.drawMarkers(); this.drawStructs();
      if (L.vol && this.vh) this.drawVolume(a, b);
      this.drawNow(); c.restore();
      this.drawAxes(a, b); this.drawLevelTags(); this.drawHeader(); this.drawCross();
    }
    drawGrid(a, b) {
      const c = this.ctx, p = this.pad, step = nice((this.hi - this.lo) / 6);
      const gt = o('chgrid'); if (gt === 'none') return; c.lineWidth = 1; c.strokeStyle = rgba(o('c_grid'), +o('chgridop')); c.setLineDash(gt === 'dots' ? [1, 4] : []); c.beginPath();
      for (let v = Math.ceil(this.lo / step) * step; v < this.hi; v += step) { const y = Math.round(this.Y(v)) + .5; c.moveTo(p.l, y); c.lineTo(p.l + this.pw, y); }
      c.stroke(); c.setLineDash([]);
      // day boundaries
      c.strokeStyle = 'rgba(255,255,255,.07)'; c.setLineDash([2, 4]); c.beginPath();
      let prev = null;
      for (let i = a; i <= b; i++) {
        const t = this.tAt(i), day = T.jnum(t);
        if (prev && day !== prev && this.ms < 864e5) { const x = Math.round(this.X(i) - this.bw / 2) + .5; c.moveTo(x, this.pt); c.lineTo(x, this.pt + this.ph); }
        prev = day;
      }
      c.stroke(); c.setLineDash([]);
    }
    drawZones() {
      const z = this.d.zones || [], c = this.ctx, p = this.pad;
      if (!this.layers.zones) return;
      const lastC = this.d.klines[this.n - 1].c, near = new Set(z.slice().sort((a, b) => Math.abs(a.p - lastC) - Math.abs(b.p - lastC)).slice(0, 6));
      let lastLy = -99;
      z.slice().sort((a, b) => b.p - a.p).forEach(zz => {
        if (zz.p < this.lo || zz.p > this.hi) return; const y = this.Y(zz.p), col = zz.kind === 'R' ? K.bear : K.bull, h = Math.max(3, zz.n * 1.6);
        c.fillStyle = rgba(col, .07); c.fillRect(p.l, y - h, this.pw, h * 2); c.strokeStyle = rgba(col, .35); c.setLineDash([1, 5]); c.beginPath(); c.moveTo(p.l, y); c.lineTo(p.l + this.pw, y); c.stroke(); c.setLineDash([]);
        if (o('zlabels') && near.has(zz) && Math.abs(y - lastLy) > 13) { lastLy = y; c.fillStyle = rgba(col, .85); c.font = '600 10px system-ui'; put(c, (zz.kind === 'R' ? 'مقاومت' : 'حمایت') + ' ×' + T.fa(zz.n) + ' · ' + T.price(zz.p), p.l + 6, y - h - 2, 'left'); }
      });
    }
    drawWatermark() {
      if (!o('wm') || !this.d.sym) return; const c = this.ctx; c.save(); c.font = '800 ' + Math.min(120, this.pw / 5) + 'px system-ui,sans-serif'; c.textAlign = 'center'; c.fillStyle = rgba(K.ink, .035);
      c.fillText(String(this.d.sym).replace('USDT', ''), this.pad.l + this.pw / 2, this.pt + this.ph / 2 + 30); c.font = '700 14px system-ui'; c.fillText(this.d.tf, this.pad.l + this.pw / 2, this.pt + this.ph / 2 + 56); c.restore();
    }
    drawFib() {
      const f = this.d.auto && this.d.auto.fib; if (!o('fib') || !f) return; const c = this.ctx, x0 = this.X(this.idx(f.t0)), x1 = this.pad.l + this.pw, col = o('c_fib');
      const lv = Object.fromEntries(f.levels.map(l => [l.r, l.p])); const yA = this.Y(lv[0.382]), yB = this.Y(lv[0.618]);
      c.fillStyle = rgba(col, .06); c.fillRect(x0, Math.min(yA, yB), x1 - x0, Math.abs(yB - yA));
      f.levels.forEach(l => { if (l.p < this.lo || l.p > this.hi) return; const y = Math.round(this.Y(l.p)) + .5; c.strokeStyle = rgba(col, l.r === 0.618 || l.r === 0.5 ? .6 : .32); c.lineWidth = 1; c.setLineDash([6, 4]); c.beginPath(); c.moveTo(x0, y); c.lineTo(x1, y); c.stroke(); c.setLineDash([]); c.fillStyle = rgba(col, .85); c.font = '600 10px ui-monospace,monospace'; c.textAlign = 'left'; c.textAlign = 'right'; c.fillText('Fib ' + l.r + ' · ' + T.price(l.p), x1 - 4, y - 3); });
    }
    drawAuto() {
      const a = this.d.auto; if (!o('autol') || !a || !a.lines) return; const c = this.ctx, endX = this.X(this.n - 1 + (this.fut.length ? Math.min(this.fut.length, 24) : 6));
      a.lines.forEach(l => {
        const col = l.kind === 'sup' ? K.bull : K.bear, x0 = this.X(this.idx(l.t0)), x1 = this.X(this.idx(l.t1)), y0 = this.Y(l.p0), y1 = this.Y(l.p1), sl = (y1 - y0) / ((x1 - x0) || 1);
        c.lineWidth = 1.8; c.strokeStyle = rgba(col, .9); c.shadowColor = col; c.shadowBlur = 8 * T.S.fx.gk; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke();
        c.setLineDash([6, 5]); c.lineWidth = 1.3; c.beginPath(); c.moveTo(x1, y1); c.lineTo(endX, y1 + sl * (endX - x1)); c.stroke(); c.setLineDash([]); c.shadowBlur = 0;
        [[x0, y0], [x1, y1]].forEach(q => { c.fillStyle = col; c.beginPath(); c.arc(q[0], q[1], 3.4, 0, 7); c.fill(); c.strokeStyle = K.bg; c.lineWidth = 1; c.stroke(); });
        c.fillStyle = rgba(col, .95); c.font = '600 10px system-ui'; put(c, (l.kind === 'sup' ? 'روندخط حمایت' : 'روندخط مقاومت') + ' · ' + T.fa(l.touches) + ' لمس', endX - 4, y1 + sl * (endX - x1) + (l.kind === 'sup' ? 14 : -6), 'right');
      });
    }
    drawFutureBg() {
      if (!this.layers.fc || !this.fut.length) return;
      const c = this.ctx, x0 = this.X(this.idx(this.fut[0].t)) - this.bw / 2, x1 = this.X(this.idx(this.fut[this.fut.length - 1].t)) + this.bw / 2;
      const g = c.createLinearGradient(x0, 0, x1, 0); g.addColorStop(0, 'rgba(98,176,255,.09)'); g.addColorStop(1, 'rgba(168,139,255,.03)');
      c.fillStyle = g; c.fillRect(x0, this.pt, x1 - x0, this.ph);
      c.strokeStyle = 'rgba(98,176,255,.35)'; c.setLineDash([6, 5]); c.beginPath(); c.moveTo(x0, this.pt); c.lineTo(x0, this.pt + this.ph); c.stroke(); c.setLineDash([]);
      c.fillStyle = 'rgba(160,200,255,.8)'; c.font = '600 11px system-ui,sans-serif'; c.textAlign = 'left';
      const te = this.fut[this.fut.length - 1].t_close || this.fut[this.fut.length - 1].t;
      put(c, `${T.fa(this.fut.length)} کندل آینده · تا ${T.date(te)} ${T.time(te)}`, Math.max(x0 + 8, this.pad.l + 8), this.pt + this.ph - 8, 'left');
    }
    drawCone() {
      const L = this.layers, f = this.d.fc; if (!L.fc || !L.cone || !f || !f.bands || !f.bands.p10) return;
      const c = this.ctx, cs = this.fcAll, up = [], dn = [], mid = [];
      cs.forEach((k, j) => { const x = this.X(this.idx(k.t)); up.push([x, this.Y(f.bands.p90[j])]); dn.push([x, this.Y(f.bands.p10[j])]); mid.push([x, this.Y(f.bands.p50[j])]); });
      if (up.length < 2) return;
      const g = c.createLinearGradient(up[0][0], 0, up[up.length - 1][0], 0); g.addColorStop(0, rgba(o('c_cone'), +o('conop'))); g.addColorStop(1, rgba(o('c_cone'), +o('conop') * .35));
      c.beginPath(); up.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); dn.slice().reverse().forEach(q => c.lineTo(q[0], q[1])); c.closePath(); c.fillStyle = g; c.fill();
      c.lineWidth = 1; c.strokeStyle = rgba(o('c_cone'), .55); [up, dn].forEach(arr => { c.beginPath(); arr.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); });
      c.lineWidth = 1.8; c.strokeStyle = rgba(K.ink, .8); c.setLineDash([5, 4]); c.shadowColor = K.info; c.shadowBlur = 8 * T.S.fx.gk; c.beginPath(); mid.forEach((q, i) => i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])); c.stroke(); c.setLineDash([]); c.shadowBlur = 0;
    }
    drawPosition() {
      const pl = this.d.plan; if (!pl || !pl.side || pl.side === 'WAIT' || !pl.entry) return;
      const c = this.ctx, x0 = this.X(this.n - 1), x1 = this.pad.l + this.pw, ye = this.Y(pl.entry);
      const ys = this.Y(pl.stop), yt = this.Y(pl.tp3 || pl.tp2 || pl.tp1);
      c.fillStyle = 'rgba(255,90,134,.10)'; c.fillRect(x0, Math.min(ye, ys), x1 - x0, Math.abs(ys - ye));
      c.fillStyle = 'rgba(53,242,193,.09)'; c.fillRect(x0, Math.min(ye, yt), x1 - x0, Math.abs(yt - ye));
      const ln = (v, col, dash, w) => { if (!v) return; const y = Math.round(this.Y(v)) + .5; c.strokeStyle = col; c.lineWidth = w || 1.2; c.setLineDash(dash || []); c.shadowColor = col; c.shadowBlur = 6; c.beginPath(); c.moveTo(this.pad.l, y); c.lineTo(x1, y); c.stroke(); c.shadowBlur = 0; c.setLineDash([]); };
      const cE = o('c_entry'), cS = o('c_sl') || K.bear, cT = o('c_tp') || K.bull; ln(pl.entry, cE, [7, 4], 1.6); ln(pl.stop, cS, [3, 3], 1.4); ln(pl.tp1, cT, [3, 3]); ln(pl.tp2, cT, [3, 3]); ln(pl.tp3, cT, [3, 3]);
    }
    drawEma(a, b) {
      if (!this.layers.ema && !this.bb && !this.vw) return; const c = this.ctx;
      const line = (arr, col, w, dash) => { c.beginPath(); c.lineWidth = w; c.strokeStyle = rgba(col, .88); c.setLineDash(dash || []); let st = false; for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) { if (arr[i] == null) continue; const x = this.X(i), y = this.Y(arr[i]); st ? c.lineTo(x, y) : c.moveTo(x, y); st = true; } c.stroke(); c.setLineDash([]); };
      if (this.layers.ema) (this.emas || []).forEach(e => { if (e) { line(e.arr, e.col, 1.4); } });
      if (this.bb) { const mid = this.bb.map(v => v && v[1]), up = this.bb.map(v => v && v[2]), lo = this.bb.map(v => v && v[0]); c.save(); c.beginPath(); let st = false; for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) { if (!this.bb[i]) continue; const x = this.X(i), y = this.Y(up[i]); st ? c.lineTo(x, y) : c.moveTo(x, y); st = true; } for (let i = Math.min(this.n - 1, b); i >= Math.max(0, a); i--) { if (!this.bb[i]) continue; c.lineTo(this.X(i), this.Y(lo[i])); } c.fillStyle = rgba(K.ai, .07); c.fill(); c.restore(); line(up, K.ai, 1, [3, 3]); line(lo, K.ai, 1, [3, 3]); line(mid, K.ai, 1); }
      if (this.vw) line(this.vw, K.gold, 1.4, [6, 3]);
    }
    drawCandles(a, b) {
      const c = this.ctx, bw = this.bw, w = Math.max(1, Math.min(bw * +o('chw'), 18)), st = o('chs'), wk = +o('chwick');
      const val = i => this.ha ? this.ha[i] : null;
      if (st === 'line' || st === 'area') {
        c.beginPath(); let f = true; for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) { const x = this.X(i), y = this.Y(this.d.klines[i].c); f ? c.moveTo(x, y) : c.lineTo(x, y); f = false; }
        c.lineWidth = 2; c.strokeStyle = upC(); c.shadowColor = upC(); c.shadowBlur = 8; c.stroke(); c.shadowBlur = 0;
        if (st === 'area') { c.lineTo(this.X(Math.min(this.n - 1, b)), this.pt + this.ph); c.lineTo(this.X(Math.max(0, a)), this.pt + this.ph); c.closePath(); const g = c.createLinearGradient(0, this.pt, 0, this.pt + this.ph); g.addColorStop(0, rgba(upC(), .35)); g.addColorStop(1, rgba(upC(), 0)); c.fillStyle = g; c.fill(); }
        const lx = this.X(this.n - 1); c.fillStyle = upC(); c.beginPath(); c.arc(lx, this.Y(this.d.klines[this.n - 1].c), 4, 0, 7); c.fill(); return;
      }
      for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) {
        const k0 = this.d.klines[i], k = val(i) || k0, up = k.c >= k.o, col = up ? upC() : dnC(), x = this.X(i), live = i === this.n - 1 && this.d.forming !== false;
        c.strokeStyle = col; c.fillStyle = col; c.lineWidth = Math.max(1, Math.min(wk, bw / 5));
        c.beginPath(); c.moveTo(Math.round(x) + .5, this.Y(k.h)); c.lineTo(Math.round(x) + .5, this.Y(k.l)); c.stroke();
        if (st === 'bars') { c.lineWidth = Math.max(1, Math.min(2, bw / 5)); c.beginPath(); c.moveTo(x - w / 2, this.Y(k.o)); c.lineTo(x, this.Y(k.o)); c.moveTo(x, this.Y(k.c)); c.lineTo(x + w / 2, this.Y(k.c)); c.stroke(); continue; }
        const y1 = this.Y(Math.max(k.o, k.c)), y2 = this.Y(Math.min(k.o, k.c)), hh = Math.max(1.5, y2 - y1);
        if (w >= 3) {
          if (st === 'hollow' && up) { c.lineWidth = 1.3; c.strokeRect(x - w / 2, y1, w, hh); }
          else { c.globalAlpha = live ? .55 : .92; c.shadowColor = col; c.shadowBlur = bw > 6 ? 6 * T.S.fx.gk : 0; c.fillRect(x - w / 2, y1, w, hh); c.shadowBlur = 0; c.globalAlpha = 1; }
        }
        if (live) { c.setLineDash([3, 2]); c.strokeStyle = K.ink; c.lineWidth = 1; c.strokeRect(x - w / 2 - 1, y1 - 1, w + 2, hh + 2); c.setLineDash([]); }
      }
      if (o('lastline')) { const k = this.d.klines[this.n - 1], y = this.Y(k.c), col = k.c >= k.o ? upC() : dnC(); c.strokeStyle = rgba(col, .6); c.setLineDash([2, 3]); c.lineWidth = 1; c.beginPath(); c.moveTo(this.X(this.n - 1), y); c.lineTo(this.pad.l + this.pw, y); c.stroke(); c.setLineDash([]); }
    }
    drawFutureCandles() {
      if (!this.layers.fc) return; const c = this.ctx, w = Math.max(1, Math.min(this.bw * +o('chw'), 16));
      this.fut.forEach(k => {
        const i = this.idx(k.t), x = this.X(i), up = k.close >= k.open, col = up ? upC() : dnC();
        c.strokeStyle = rgba(col, .75); c.lineWidth = 1; c.beginPath(); c.moveTo(Math.round(x) + .5, this.Y(k.high)); c.lineTo(Math.round(x) + .5, this.Y(k.low)); c.stroke();
        const y1 = this.Y(Math.max(k.open, k.close)), y2 = this.Y(Math.min(k.open, k.close)), hh = Math.max(1.5, y2 - y1);
        if (w >= 3) { const fs = o('fcs'); if (fs !== 'outline') { c.fillStyle = rgba(col, fs === 'solid' ? .75 : .22); c.fillRect(x - w / 2, y1, w, hh); } if (fs !== 'solid') { c.setLineDash([2, 2]); c.strokeStyle = rgba(col, .9); c.strokeRect(x - w / 2, y1, w, hh); c.setLineDash([]); } }
      });
    }
    drawVolume(a, b) {
      const c = this.ctx; let mx = 0; for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) mx = Math.max(mx, this.d.klines[i].v);
      for (let i = Math.max(0, a); i <= Math.min(this.n - 1, b); i++) { const k = this.d.klines[i], h = k.v / (mx || 1) * this.vh, x = this.X(i), w = Math.max(1, this.bw * 0.7); c.fillStyle = rgba(o('c_vol') || (k.c >= k.o ? upC() : dnC()), .35); c.fillRect(x - w / 2, this.vy0 + this.vh - h, w, h); }
    }
    drawNow() {
      const c = this.ctx, x = this.X(this.n - 1) + this.bw / 2;
      c.strokeStyle = rgba(o('c_now'), .6); c.lineWidth = 1; c.setLineDash([2, 3]); c.beginPath(); c.moveTo(x, this.pt); c.lineTo(x, this.pt + this.ph); c.stroke(); c.setLineDash([]);
    }
    drawPatternBoxes() {
      if (!this.layers.pat || !this.d.pats) return; const c = this.ctx;
      this.d.pats.filter(p => p.alive && p.bias !== 0).slice(0, 6).forEach(p => {
        const x0 = this.X(this.idx(p.t_start)) - this.bw / 2, x1 = this.X(this.idx(p.valid_until)) - this.bw / 2, col = p.bias > 0 ? K.bull : K.bear;
        const y0 = this.Y(p.pat_hi), y1 = this.Y(p.pat_lo);
        c.fillStyle = rgba(col, .06); c.fillRect(x0, y0, x1 - x0, y1 - y0); c.setLineDash([4, 3]); c.strokeStyle = rgba(col, .55); c.lineWidth = 1; c.strokeRect(x0 + .5, y0 + .5, x1 - x0, y1 - y0); c.setLineDash([]);
        if (p.invalid_level) { const yy = this.Y(p.invalid_level); c.strokeStyle = rgba(K.warn, .7); c.setLineDash([2, 3]); c.beginPath(); c.moveTo(x0, yy); c.lineTo(x1, yy); c.stroke(); c.setLineDash([]); }
        c.fillStyle = rgba(col, .95); c.font = '600 10px system-ui,sans-serif'; c.textAlign = 'left';
        if (o('plabels')) put(c, `${p.fa} · تا ${T.time(p.valid_until)}`, x0 + 4, p.bias > 0 ? y1 + 12 : y0 - 4, 'left');
      });
    }
    drawMarkers() {
      if (!this.layers.pat || !this.d.pats) return; const c = this.ctx;
      this.d.pats.forEach(p => {
        const i = this.idx(p.t); if (i < 0 || i > this.n - 1) return; const x = this.X(i), col = p.bias > 0 ? K.bull : p.bias < 0 ? K.bear : K.warn, k = this.d.klines[Math.round(i)]; if (!k) return;
        const up = p.bias >= 0, y = up ? this.Y(k.l) + 10 : this.Y(k.h) - 10, s = p.alive ? +o('chmark') : +o('chmark') * .66;
        c.globalAlpha = p.alive ? 1 : .4; c.fillStyle = col; c.shadowColor = col; c.shadowBlur = p.alive ? 10 : 0; c.beginPath();
        if (p.bias === 0) { c.arc(x, y, s * .7, 0, 7); } else if (up) { c.moveTo(x, y - s); c.lineTo(x - s, y + s * .7); c.lineTo(x + s, y + s * .7); } else { c.moveTo(x, y + s); c.lineTo(x - s, y - s * .7); c.lineTo(x + s, y - s * .7); }
        c.fill(); c.shadowBlur = 0; c.globalAlpha = 1;
      });
    }
    drawStructs() {
      if (!this.layers.struct || !this.d.structs) return; const c = this.ctx;
      this.d.structs.filter(s => s.alive).slice(0, 3).forEach((s, si) => {
        const col = s.bias > 0 ? K.bull : s.bias < 0 ? K.bear : K.warn;
        (s.lines_t || []).forEach((ln, li) => {
          const x0 = this.X(this.idx(ln[0])), x1 = this.X(this.idx(ln[2])), sl = (ln[3] - ln[1]) / ((ln[2] - ln[0]) || 1);
          const te = Math.min(s.valid_until, ln[2] + (s.valid_until - ln[2]) * (s.k.includes('tri') || s.k.includes('wedge') ? 1 : 0.0001));
          const ye = ln[3] + sl * (te - ln[2]), xe = this.X(this.idx(te));
          c.strokeStyle = rgba(col, li < 2 ? .95 : .55); c.lineWidth = li < 2 ? 2 : 1.3; c.shadowColor = col; c.shadowBlur = 8; c.beginPath(); c.moveTo(x0, this.Y(ln[1])); c.lineTo(x1, this.Y(ln[3])); c.stroke();
          c.setLineDash([5, 4]); c.beginPath(); c.moveTo(x1, this.Y(ln[3])); c.lineTo(xe, this.Y(ye)); c.stroke(); c.setLineDash([]); c.shadowBlur = 0;
        });
        if (o('pts')) (s.points_t || []).forEach((q, qi) => { const x = this.X(this.idx(q[0])), y = this.Y(q[1]); if (x < this.pad.l || x > this.pad.l + this.pw) return; c.fillStyle = rgba(col, .95); c.beginPath(); c.arc(x, y, 3.6, 0, 7); c.fill(); c.strokeStyle = K.bg; c.lineWidth = 1.2; c.stroke(); c.fillStyle = rgba(K.ink, .9); c.font = '700 9px system-ui'; c.textAlign = 'center'; c.fillText(String(qi + 1), x, q[2] === 'H' ? y - 8 : y + 15); });
        [['break_up', s.break_up, K.bull], ['break_dn', s.break_dn, K.bear]].forEach(([k_, v_, cc]) => { if (v_ == null || v_ < this.lo || v_ > this.hi) return; const yy = this.Y(v_), xs = this.X(this.idx(s.t_start)), xe = this.X(this.idx(s.valid_until)); c.strokeStyle = rgba(cc, .55); c.setLineDash([2, 4]); c.lineWidth = 1; c.beginPath(); c.moveTo(xs, yy); c.lineTo(xe, yy); c.stroke(); c.setLineDash([]); c.fillStyle = rgba(cc, .9); c.font = '600 9.5px system-ui'; put(c, (k_ === 'break_up' ? 'شکست صعودی ' : 'شکست نزولی ') + T.price(v_), xe - 4, yy - 3, 'right'); });
        const x = this.X(this.idx(s.valid_until)), y = this.pt + 18 + si * 16;
        c.fillStyle = rgba(col, .95); c.font = '700 11px system-ui,sans-serif'; put(c, `${s.fa} · معتبر تا ${T.date(s.valid_until)} ${T.time(s.valid_until)}`, Math.min(x, this.pad.l + this.pw - 6), y, 'right');
        if (s.target) { const yy = this.Y(s.target); if (yy > this.pt && yy < this.pt + this.ph) { c.strokeStyle = rgba(col, .8); c.setLineDash([2, 4]); c.beginPath(); c.moveTo(this.X(this.n - 1), yy); c.lineTo(this.pad.l + this.pw, yy); c.stroke(); c.setLineDash([]); c.fillStyle = rgba(col, .95); c.font = '600 10px system-ui'; put(c, 'هدف الگو ' + T.price(s.target) + (s.target_eta_t ? ' · حدود ' + T.time(s.target_eta_t) : ''), this.pad.l + this.pw - 6, yy - 4, 'right'); } }
      });
    }
    drawAxes(a, b) {
      const c = this.ctx, p = this.pad, H = this.h, step = nice((this.hi - this.lo) / 6);
      c.font = '11px ui-monospace,Menlo,monospace'; c.textAlign = 'left'; c.fillStyle = rgba(K.ink2, .9);
      for (let v = Math.ceil(this.lo / step) * step; v < this.hi; v += step) c.fillText(T.price(v), p.l + this.pw + 7, this.Y(v) + 4);
      // time axis: two lines per label (time / date) — for 1d: date / weekday
      const ms = this.ms, bw = this.bw; let sb = 1; for (const s of [1, 2, 3, 4, 6, 8, 12, 16, 24, 48, 96]) { sb = s; if (s * bw >= 84) break; }
      const y0 = H - p.b + 14; c.textAlign = 'center'; let prevDay = null;
      c.strokeStyle = rgba(o('c_grid'), .12); c.beginPath(); c.moveTo(p.l, H - p.b + 1.5); c.lineTo(p.l + this.pw, H - p.b + 1.5); c.stroke();
      for (let i = Math.max(0, Math.floor(this.vs) - 1); i <= b; i++) {
        const t = this.tAt(i); if (Math.round(t / ms) % sb !== 0) continue; const x = this.X(i); if (x < p.l + 24 || x > p.l + this.pw - 24) continue;
        const day = T.jnum(t), fut = i > this.n - 1;
        c.fillStyle = fut ? rgba(K.info, .95) : rgba(K.ink, .92); c.font = '600 11px ui-monospace,Menlo,monospace';
        put(c, ms >= 864e5 ? T.date(t) : T.time(t), x, y0, 'center');
        c.fillStyle = rgba(K.mut, .95); c.font = '10px system-ui,sans-serif';
        put(c, ms >= 864e5 ? T.wday(t) : (day !== prevDay ? T.date(t) : ''), x, y0 + 13, 'center');
        c.strokeStyle = 'rgba(255,255,255,.18)'; c.beginPath(); c.moveTo(x, H - p.b + 1.5); c.lineTo(x, H - p.b + 5); c.stroke(); prevDay = day;
      }
    }
    drawLevelTags() {
      const pl = this.d.plan, c = this.ctx, p = this.pad, L = this.layers; if (!L.lv || !pl || !pl.side || pl.side === 'WAIT') return;
      const tag = (v, txt, col) => { if (!v || v < this.lo || v > this.hi) return; const y = this.Y(v); c.fillStyle = col; c.beginPath(); c.roundRect ? c.roundRect(p.l + this.pw + 2, y - 9, p.r - 4, 18, 6) : c.rect(p.l + this.pw + 2, y - 9, p.r - 4, 18); c.fill(); c.fillStyle = '#031'; c.font = '700 10.5px ui-monospace,Menlo,monospace'; c.textAlign = 'left'; c.fillText(T.price(v), p.l + this.pw + 6, y + 4); c.fillStyle = col; c.font = '700 10px system-ui'; c.textAlign = 'left'; c.fillText(txt, p.l + 8, y - 5); };
      tag(pl.entry, 'ENTRY', o('c_entry')); tag(pl.stop, 'SL' + (pl.eta && pl.eta.stop ? ' · ~' + T.time(pl.eta.stop) : ''), o('c_sl') || K.bear);
      ['tp1', 'tp2', 'tp3'].forEach(k => tag(pl[k], k.toUpperCase() + (pl.p && pl.p[k] != null ? ' · ' + Math.round(pl.p[k] * 100) + '%' : '') + (pl.eta && pl.eta[k] ? ' · ~' + T.time(pl.eta[k]) : ''), o('c_tp') || K.bull));
    }
    drawHeader() {
      if (!o('chhead')) return;
      const c = this.ctx, k = this.hover ? this.hover.k : this.d.klines[this.n - 1]; if (!k) return;
      c.textAlign = 'left'; c.font = '11px ui-monospace,Menlo,monospace'; const ch = (k.c / k.o - 1) * 100, col = k.c >= k.o ? K.bull : K.bear;
      let x = this.pad.l + 8; const items = [['O', k.o], ['H', k.h], ['L', k.l], ['C', k.c]];
      items.forEach(([n, v]) => { c.fillStyle = rgba(K.mut, .95); c.fillText(n, x, 14); x += 11; c.fillStyle = col; const s = T.price(v); c.fillText(s, x, 14); x += c.measureText(s).width + 12; });
      c.fillStyle = col; c.fillText((ch >= 0 ? '+' : '') + ch.toFixed(2) + '%', x, 14);
      c.fillStyle = rgba(K.ink, .9); put(c, T.date(k.t) + '  ' + T.time(k.t), x + 62, 14, 'left');
    }
    drawCross() {
      if (!this.mouse || this.drag && this.drag.moved) return; const c = this.ctx, p = this.pad, { x, y } = this.mouse;
      if (x < p.l || x > p.l + this.pw || y < this.pt || y > this.h - p.b) return;
      const i = Math.round(this.vs + (x - p.l) / this.bw - 0.5), cx = this.X(i);
      if (o('chcross') === 'none') return; c.strokeStyle = rgba(K.ink, .45); c.setLineDash(o('chcross') === 'dash' ? [3, 3] : []); c.lineWidth = 1; c.beginPath(); c.moveTo(cx, this.pt); c.lineTo(cx, this.h - p.b); c.moveTo(p.l, y); c.lineTo(p.l + this.pw, y); c.stroke(); c.setLineDash([]);
      if (y < this.pt + this.ph) { const pv = this.hi - (y - this.pt) / this.ph * (this.hi - this.lo); c.fillStyle = K.ink; c.fillRect(p.l + this.pw + 2, y - 9, p.r - 4, 18); c.fillStyle = K.bg; c.font = '700 10.5px ui-monospace,monospace'; c.textAlign = 'left'; c.fillText(T.price(pv), p.l + this.pw + 6, y + 4); }
      const t = this.tAt(i), lab = T.date(t) + '  ' + T.time(t); c.font = '700 10.5px ui-monospace,monospace'; const w = c.measureText(lab).width + 14;
      c.fillStyle = K.ink; c.fillRect(T.clamp(cx - w / 2, p.l, p.l + this.pw - w), this.h - p.b + 3, w, 17); c.fillStyle = K.bg; put(c, lab, T.clamp(cx, p.l + w / 2, p.l + this.pw - w / 2), this.h - p.b + 15, 'center');
    }
    /* ── tooltip: full date + time range of the candle under the pointer ── */
    showTip() {
      const m = this.mouse, p = this.pad, tip = this.tipEl; this.hover = null; if (o('chtip') === 'off') { tip.hidden = true; return; }
      if (!m || m.x < p.l || m.x > p.l + this.pw || m.y < this.pt || m.y > this.h - p.b) { tip.hidden = true; return; }
      const i = Math.round(this.vs + (m.x - p.l) / this.bw - 0.5), t = this.tAt(i), ms = this.ms, future = i > this.n - 1;
      let h = `<div class="hd"><b>${T.wday(t)} ${T.date(t, true)}</b><span class="mono">${T.time(t)}→${T.time(t + ms)}</span></div>`;
      const kv = (a, b, cls) => `<div class="kv"><span class="mut">${a}</span><b class="mono ${cls || ''}">${b}</b></div>`;
      if (!future && this.d.klines[i]) {
        const k = this.d.klines[i], live = i === this.n - 1, ch = (k.c / k.o - 1) * 100; this.hover = { k };
        h += `<div class="mb-1">${live ? T.chip('کندل جاری (در حال تشکیل)', 'warn', 'clock') : T.chip('کندل بسته‌شده', 'info')}</div>` + kv('باز', T.price(k.o)) + kv('بالا', T.price(k.h)) + kv('پایین', T.price(k.l)) + kv('بسته', T.price(k.c), ch >= 0 ? 'bull' : 'bear') + kv('تغییر', T.pct(ch), ch >= 0 ? 'bull' : 'bear') + kv('حجم', T.big(k.v));
        const f0 = this.fcAll.find(c => c.t === k.t); if (live && f0 && this.d.fc && this.d.fc.bands) { const j = this.fcAll.indexOf(f0); h += kv('پیش‌بینی بسته‌شدن', T.price(f0.close)) + kv('بازه ۱۰–۹۰٪', T.price(this.d.fc.bands.p10[j]) + ' – ' + T.price(this.d.fc.bands.p90[j])); }
      } else if (future) {
        const j = this.fcAll.findIndex(c => c.t === t), k = this.fcAll[j];
        if (k) { const bd = this.d.fc.bands, sp = this.d.fc.step_prob, last = this.d.klines[this.n - 1].c; this.hover = { k: { o: k.open, h: k.high, l: k.low, c: k.close, t, v: 0 } };
          h += `<div class="mb-1">${T.chip('پیش‌بینی · کندل ' + T.fa(k.step) + ' از ' + T.fa(this.fut.length), 'ai', 'cone')}</div>` + kv('باز (نوعی)', T.price(k.open)) + kv('بالا', T.price(k.high)) + kv('پایین', T.price(k.low)) + kv('بسته (نوعی)', T.price(k.close), k.close >= k.open ? 'bull' : 'bear')
            + kv('بازه ۱۰–۹۰٪', T.price(bd.p10[j]) + ' – ' + T.price(bd.p90[j])) + kv('میانه', T.price(bd.p50[j])) + (sp ? kv('احتمال بالاتر از قیمت فعلی', Math.round(sp[j] * 100) + '٪', sp[j] >= .5 ? 'bull' : 'bear') : '') + kv('فاصله از اکنون', T.dur(t - this.d.klines[this.n - 1].t));
        } else { tip.hidden = true; return; }
      } else { tip.hidden = true; return; }
      const pats = (this.d.pats || []).filter(q => Math.abs(this.idx(q.t) - i) < 0.6);
      pats.forEach(q => { h += `<div style="margin-top:6px;padding-top:5px;border-top:1px solid var(--gl2)"><b class="${T.biasCls(q.bias)}">${q.fa}</b> <span class="mut xs">${q.state_fa}</span><br><span class="xs mut">معتبر تا</span> <span class="mono xs">${T.date(q.valid_until)} ${T.time(q.valid_until)}</span></div>`; });
      tip.innerHTML = h; tip.hidden = false;
      const hw = this.host.clientWidth, tw = tip.offsetWidth, th = tip.offsetHeight;
      tip.style.left = (m.x + 16 + tw > hw ? m.x - tw - 16 : m.x + 16) + 'px'; tip.style.top = T.clamp(m.y - 20, 6, this.h - th - 6) + 'px';
      this.draw();
    }
  }
  T.Chart = Chart;
})(window);
