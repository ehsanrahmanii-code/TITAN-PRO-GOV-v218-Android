/* TITAN · views A: dashboard, market, coin workspace. */
(function (W) {
  'use strict';
  const T = W.TT, esc = T.esc, S = T.S, V = T.V = T.V || {}, TABS = T.TABS = {};
  const view = () => T.$('#view');
  const ACT = { ENTER_NOW: 'ورود اکنون', WAIT: 'صبر', AVOID: 'پرهیز', WATCH: 'رصد', PULLBACK: 'ورود روی پولبک' };
  T.actFa = a => ACT[a] || a || '—';
  const CMP = { context: 'بافت بازار', data_trust: 'اعتماد به داده', derivatives: 'مشتقات', forecast: 'پیش‌بینی آماری', htf_trend: 'روند تایم‌فریم بالا', ltf_trigger: 'ماشهٔ تایم‌فریم پایین', momentum: 'مومنتوم', mtf_setup: 'ستاپ چندتایم‌فریم', pattern: 'الگوها', structure: 'ساختار بازار', volume_flow: 'جریان حجم', x_layer: 'لایه‌های پیشرفته' };
  const rows = () => Object.values((S.matrix && S.matrix.matrix) || {});
  T.openCoin = function (sym, tf, sub) { S.sym = sym; if (tf) S.tf = tf; if (sub) S.sub = sub; S.cfg.last = { sym: S.sym, tf: S.tf }; T.saveCfg(); T.go('work'); };
  const coinIc = r => `<div class="ic" style="background:${T.coinColor(r.symbol)}">${esc(T.base(r.symbol).slice(0, 4))}</div>`;

  /* ═════════ DASHBOARD (widget grid: order / size / visibility are user settings) ═════════ */
  const WG = {};
  V.dash = {
    mount() { view().innerHTML = '<div id="dash">' + T.skel(4, 120) + '</div>'; this.render(); },
    ctx() {
      const R = rows(), mk = S.market, st = S.status;
      return { R, mk, st, nL: R.filter(r => r.verdict === 'LONG').length, nS: R.filter(r => r.verdict === 'SHORT').length, ex: S.exchange || {}, les: S.lessons || {},
        top: R.filter(r => r.verdict === 'LONG' || r.verdict === 'SHORT').sort((a, b) => ('ABCD'.indexOf(a.grade) - 'ABCD'.indexOf(b.grade)) || (b.confidence - a.confidence)) };
    },
    /** number of columns that really fit: user choice (or auto) limited by the real width, so nothing can overflow */
    cols() {
      const w = (T.$('#view') || document.body).clientWidth || innerWidth, MIN = 176, want = String(T.p('wcols') || 'auto');
      const auto = w < 540 ? 1 : w < 860 ? 2 : w < 1240 ? 3 : 4, fit = Math.max(1, Math.floor((w + 14) / (MIN + 14)));
      return Math.max(1, Math.min(want === 'auto' ? auto : (+want || 4), fit));
    },
    render() {
      const el = T.$('#dash'); if (!el) return; const m = S.matrix; if (!m || !m.matrix) { el.innerHTML = T.skel(4, 120); return; }
      const cx = this.ctx(); cx.nW = cx.R.length - cx.nL - cx.nS; const cols = this.cols(); this.lastCols = cols; this.lastW = (T.$('#view') || {}).clientWidth;
      const L = T.P.dashLayout().filter(w => w.on && WG[w.id] && (w.id !== 'tape' || T.p('dtape')));
      el.innerHTML = `<div class="wgrid" style="--wcols:${cols}">${L.map(w => { const sp = Math.min(w.span || 1, cols), html = WG[w.id](cx); return html ? `<div data-w="${w.id}" style="display:contents">${html.replace('<section class="glass', `<section class="glass ws${sp}`).replace('<div class="tape"', `<div class="tape ws${cols}"`).replace('<div class="grid gB" style="grid-column:1/-1">', '<div class="grid gB wsall">')}</div>` : ''; }).join('')}</div>`;
      T.on(el, '[data-open]', 'click', (e, t) => T.openCoin(t.dataset.open, t.dataset.tf));
      if (T.P.fx) T.P.fx.after(el);
    },
    hero(r) {
      const t = (r.tfs || {})['1h'] || {}, ok = t.side === r.verdict;
      return `<div class="hero" style="cursor:pointer" data-open="${r.symbol}"><div class="row nw">${coinIc(r)}<div class="mn"><b class="lg">${esc(T.base(r.symbol))}</b><div class="mut xs mono">${esc(r.symbol)}</div></div><span class="spacer"></span>${T.grade(r.grade)}</div>
        <div class="row sb hero-mid">${T.sideBadge(r.verdict)}${T.gauge(r.confidence, { size: 64, label: 'اطمینان' })}</div>${ok ? `<div class="kv3"><div><span class="mut xs">ورود</span><b class="mono">${T.price(t.entry)}</b></div><div><span class="bear xs">حدضرر</span><b class="mono bear">${T.price(t.stop)}</b></div><div><span class="bull xs">هدف ۱</span><b class="mono bull">${T.price(t.tp1)}</b></div></div>` : ''}
        ${T.p('dsince') ? `<div class="xs mut">فعال از ${r.since ? esc(T.dt(r.since * 1000)) : '—'}${t.valid_until ? ' · اعتبار تحلیل ۱س تا ' + esc(T.time(t.valid_until)) : ''}</div>` : ''}</div>`;
    },
    opp(r) {
      const tf = ['1h', '4h', '15m', '1d'].find(x => r.tfs[x] && r.tfs[x].side === r.verdict) || '1h', t = r.tfs[tf] || {};
      return `<div class="glass coin" data-open="${r.symbol}" data-tf="${tf}"><div class="row nw">${coinIc(r)}<div class="mn"><b class="lg">${esc(T.base(r.symbol))}</b><div class="mut xs mono">${T.price(r.ticker && r.ticker.price)} · ${T.pct(r.ticker && r.ticker.change_pct)}</div></div><span class="spacer"></span>${T.grade(r.grade)}</div>
        <div class="row sb" style="margin:10px 0">${T.sideBadge(r.verdict)}<div style="flex:1 1 120px;min-width:0"><div class="row sb xs mut"><span>اطمینان ${Math.round(r.confidence || 0)}٪</span><span>${esc(T.actFa(r.action))}</span></div>${T.bar(r.confidence, { cls: r.verdict === 'SHORT' ? 'bear' : '', tall: 1 })}</div></div>
        <div class="kv3"><div><span class="mut xs">ورود</span><b class="mono">${T.price(t.entry)}</b></div><div><span class="mut xs">حدضرر</span><b class="mono bear">${T.price(t.stop)}</b></div><div><span class="mut xs">هدف ۱</span><b class="mono bull">${T.price(t.tp1)}</b></div></div>
        ${T.p('dsince') ? `<div class="row xs mut" style="margin-top:8px;gap:8px">${T.ic('clock')}<span>فعال از ${r.since ? esc(T.dt(r.since * 1000)) : '—'}</span></div>${t.valid_until ? `<div class="xs mut">اعتبار (${tf}) تا ${esc(T.dt(t.valid_until))}</div>` : ''}` : ''}</div>`;
    },
    heat(R) {
      const tfs = ['15m', '1h', '4h', '1d'];
      let h = `<div class="heat heatm"><span></span>${tfs.map(t => `<span class="h">${t}</span>`).join('')}<span class="h">حکم</span>`;
      R.forEach(r => {
        h += `<div class="rowname" data-open="${r.symbol}"><div class="ic mini" style="background:${T.coinColor(r.symbol)}">${esc(T.base(r.symbol).slice(0, 3))}</div><span class="rn">${esc(T.base(r.symbol))}</span></div>`;
        tfs.forEach(tf => { const c = r.tfs[tf]; h += c ? `<div class="hc" style="${T.heat(c.score)}" data-open="${r.symbol}" data-tf="${tf}" data-tip="${esc(T.base(r.symbol) + ' · ' + tf + '\nحکم: ' + T.sideFa(c.side) + ' · امتیاز ' + Math.round(c.score) + '\nاعتماد ' + Math.round(c.confidence * 100) + '٪' + (c.valid_until ? '\nاعتبار تا ' + T.dt(c.valid_until) : ''))}">${T.ic(c.side === 'LONG' ? 'up' : c.side === 'SHORT' ? 'down' : 'pause')}${Math.round(c.score)}</div>` : '<div class="hc" style="background:#ffffff08">·</div>'; });
        h += `<div class="hc" data-open="${r.symbol}" style="${r.verdict === 'WAIT' ? 'background:#ffc86114;color:#ffc861' : T.heat(r.verdict === 'LONG' ? 80 : -80)}">${T.sideFa(r.verdict)} ${r.grade && r.grade !== '—' ? '· ' + esc(r.grade) : ''}</div>`;
      });
      return h + '</div>';
    },
    log() {
      const L = (S.siglog && S.siglog.entries) || []; if (!L.length) return T.empty('وقتی حاکم مرکزی سیگنالی منتشر کند، با زمان دقیق اینجا ثبت و نتیجهٔ واقعی آن سنجیده می‌شود.', 'ledger');
      return `<div class="scroll-x"><table class="tbl"><tr><th>زمان انتشار</th><th>ارز</th><th>حکم</th><th class="c-opt">درجه</th><th class="c-opt">قیمت</th><th class="c-opt">۱ ساعت</th><th class="c-opt">۴ ساعت</th><th>نتیجه</th></tr>${L.slice(0, 8).map(e => `<tr class="click" data-open="${e.symbol}"><td>${T.tstamp(e.t * 1000, true)}</td><td><b>${esc(T.base(e.symbol))}</b></td><td>${T.sideBadge(e.verdict)}</td><td class="c-opt">${T.grade(e.grade)}</td><td class="mono c-opt">${T.price(e.price)}</td>
        <td class="mono c-opt ${T.biasCls(e.res && e.res['1h'])}">${e.res && e.res['1h'] != null ? T.pct(e.res['1h']) : '…'}</td><td class="mono c-opt ${T.biasCls(e.res && e.res['4h'])}">${e.res && e.res['4h'] != null ? T.pct(e.res['4h']) : '…'}</td><td>${e.hit === 'TP1' ? T.chip('رسید به هدف ۱', 'bull', 'check') : e.hit === 'SL' ? T.chip('حدضرر خورد', 'bear', 'x') : T.chip('باز', 'info', 'clock')}</td></tr>`).join('')}</table></div>`;
    },
    tick() { this.render(); }
  };
  addEventListener('resize', T.debounce(() => { if (S.route === 'dash' && V.dash.lastW !== (T.$('#view') || {}).clientWidth) V.dash.render(); }, 160));
  const pn = (title, ic, body, o) => T.panel(title, ic, body, o);
  WG.tape = cx => { const it = cx.R.map(r => { const tk = r.ticker || {}, ch = tk.change_pct || 0; return `<span data-open="${r.symbol}"><b>${esc(T.base(r.symbol))}</b>${T.price(tk.price)} <i class="${T.biasCls(ch)}" style="font-style:normal">${T.pct(ch)}</i> <i class="${T.sideCls(r.verdict)}" style="font-style:normal;font-size:10px">${r.verdict !== 'WAIT' ? '●' : ''}</i></span>`; }).join(''); return `<div class="tape"><div class="in">${it}${it}</div></div>`; };
  WG.mood = cx => { const mood = cx.mk ? (cx.mk.mood - 50) * 2 : 0; return pn('حال‌وهوای بازار', 'pulse', `<div class="col" style="align-items:center"><div style="width:100%;display:grid;place-items:center">${T.dial(mood, { w: 210 })}</div><div class="xl ${mood >= 15 ? 'bull' : mood <= -15 ? 'bear' : 'warn'}">${mood >= 25 ? 'صعودی' : mood >= 8 ? 'کمی صعودی' : mood <= -25 ? 'نزولی' : mood <= -8 ? 'کمی نزولی' : 'خنثی'}</div><div class="row sm wrap" style="gap:6px"><span class="chip bull">${T.ic('up')}${T.fa(cx.nL)} خرید</span><span class="chip bear">${T.ic('down')}${T.fa(cx.nS)} فروش</span><span class="chip warn">${T.ic('pause')}${T.fa(cx.nW)} انتظار</span></div></div>`); };
  WG.clock = cx => { const st = cx.st || {}, last = st.last_scan ? st.last_scan * 1000 : 0, nextIn = last ? last + (st.scan_sec || 45) * 1000 : 0, now = T.nowMs(); return pn('ساعت و تازگی داده', 'clock', `<div class="col"><div class="xl num" id="dclock">${T.time(now, true)}</div><div class="sm ink2" id="ddate">${esc(T.wday(now))} ${esc(T.date(now, true))}</div><div class="sm mut">منطقهٔ زمانی: <span class="mono">${esc(T.zoneName())}</span></div><div class="sm">آخرین اسکن: ${last ? T.tstamp(last, !!T.p('reltime')) : '—'}</div><div class="sm">اسکن بعدی: ${nextIn ? `<span class="t">${esc(T.time(nextIn, true))}</span>` : '—'}</div>${st.restored ? '<div class="xs warn">نمایش از آخرین اسکن ذخیره‌شده</div>' : ''}</div>`); };
  WG.health = cx => { const st = cx.st || {}, pr = st.progress || {}, hp = S.core ? S.core.health : st.core_health; return pn('سلامت سیستم', 'core', `<div class="hbox">${T.gauge(hp, { size: 96, label: 'هسته' })}<div class="col sm mn" style="flex:1 1 130px"><div>${st.scanning ? T.chip('در حال اسکن ' + T.fa(pr.done || 0) + '/' + T.fa(pr.total || 0), 'info', 'radar') : T.chip('اسکن آماده', 'bull', 'check')}</div>${st.scanning ? T.bar(pr.total ? pr.done / pr.total * 100 : 0, { cls: 'info' }) : ''}<div class="mut xs">منابع: ${Object.entries(st.sources || {}).map(([k, v]) => `<span class="${v.cooling ? 'bear' : v.last_ok ? 'bull' : 'mut'}">●</span> ${esc(k)}`).join(' ')}</div><div class="mut xs">ذخیره‌سازی فقط در <b class="mono">${esc(st.data_name || 'XXX')}</b></div></div></div>`); };
  WG.best = cx => pn('بهترین فرصت', 'crown', cx.top[0] ? V.dash.hero(cx.top[0]) : T.empty('فعلاً سیگنال تاییدشده‌ای نیست؛ حاکم مرکزی منتظر شرایط بهتر است.', 'shield'), { cls: cx.top[0] ? 'hot' : '' });
  WG.radar = cx => {
    const n = cx.R.length || 1, cxx = 150, cyy = 150, blips = cx.R.map((r, i) => {
      let h = 0; for (const ch of r.symbol) h = (h * 33 + ch.charCodeAt(0)) % 360; const ang = (i / n) * 2 * Math.PI + (h % 7) * 0.02, conf = r.verdict === 'WAIT' ? 15 + (r.confidence || 0) * 0.3 : 40 + (r.confidence || 0) * 0.55, rad = 125 - conf * 0.95 + (i % 3) * 9, x = cxx + Math.cos(ang) * rad, y = cyy + Math.sin(ang) * rad, c = r.verdict === 'LONG' ? T.col.bull : r.verdict === 'SHORT' ? T.col.bear : T.col.warn, act = r.verdict !== 'WAIT';
      return `<g data-open="${r.symbol}" class="blip" style="cursor:pointer"><title>${esc(T.base(r.symbol) + ' · ' + T.sideFa(r.verdict) + ' · ' + Math.round(r.confidence || 0) + '٪')}</title>${act ? `<circle class="blipc" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5" fill="none" stroke="${c}" stroke-width="1.5"/>` : ''}<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${act ? 5 : 3.2}" fill="${c}" opacity="${act ? 1 : .55}" style="filter:drop-shadow(0 0 6px ${c})"/>${act ? `<text x="${(x + 8).toFixed(1)}" y="${(y + 3).toFixed(1)}" font-size="9" fill="${T.col.ink}" opacity=".9">${esc(T.base(r.symbol))}</text>` : ''}</g>`; }).join('');
    return pn('رادار بازار', 'radar', `<div class="radar"><svg viewBox="0 0 300 300"><defs><radialGradient id="rg"><stop offset="0" stop-color="${T.col.bull}" stop-opacity=".25"/><stop offset="1" stop-color="${T.col.bull}" stop-opacity="0"/></radialGradient><linearGradient id="sw" x1="0" x2="1"><stop offset="0" stop-color="${T.col.bull}" stop-opacity="0"/><stop offset="1" stop-color="${T.col.bull}" stop-opacity=".55"/></linearGradient></defs>
      <circle cx="150" cy="150" r="140" fill="url(#rg)" stroke="${T.col.bull}" stroke-opacity=".35"/>${[35, 70, 105].map(r => `<circle cx="150" cy="150" r="${r}" fill="none" stroke="${T.col.ink}" stroke-opacity=".12" stroke-dasharray="2 4"/>`).join('')}
      <line x1="10" y1="150" x2="290" y2="150" stroke="${T.col.ink}" stroke-opacity=".1"/><line x1="150" y1="10" x2="150" y2="290" stroke="${T.col.ink}" stroke-opacity=".1"/>
      <g class="sweep"><path d="M150 150 L290 150 A140 140 0 0 0 ${150 + 140 * Math.cos(-0.7)} ${150 + 140 * Math.sin(-0.7)} Z" fill="url(#sw)"/><line x1="150" y1="150" x2="290" y2="150" stroke="${T.col.bull}" stroke-width="2" style="filter:drop-shadow(0 0 6px ${T.col.bull})"/></g>${blips}<circle cx="150" cy="150" r="4" fill="${T.col.bull}"/></svg></div><div class="row xs mut wrap" style="justify-content:center;gap:4px 12px;margin-top:6px"><span class="bull">● خرید</span><span class="bear">● فروش</span><span class="warn">● انتظار</span><span>نزدیک مرکز = اطمینان بالا</span></div>`, { cls: 'hot' });
  };
  WG.autotrade = cx => {
    const ex = cx.ex, log = (ex.auto_log || []).slice(-6).reverse(), pos = ex.open_positions || [], les = cx.les.total || {};
    return pn('معامله خودکار و پیگیری نتایج', 'bolt', `<div class="row sb wrap" style="margin-bottom:8px"><div class="row wrap">${ex.auto_trade ? T.chip('خودکار روشن', 'bull', 'bolt') : T.chip('خودکار خاموش', 'warn', 'pause')}<span class="chip">${T.fa(pos.length)} پوزیشن باز</span></div><b class="mono ${T.biasCls(ex.day_pnl)}">${T.usd(ex.day_pnl)} <span class="xs mut">امروز</span></b></div>
      <div class="kpis k3">${T.kpi('معاملهٔ بسته', String(les.n || 0), { c: T.col.info })}${T.kpi('نرخ برد', les.win != null ? les.win + '٪' : '—', { c: T.col.bull })}${T.kpi('مجموع R', les.sum_r != null ? (les.sum_r > 0 ? '+' : '') + les.sum_r : '—', { cls: T.biasCls(les.sum_r) })}</div>
      <div class="col xs" style="margin-top:8px;gap:4px;max-height:150px;overflow:auto">${log.length ? log.map(l => `<div class="row" style="gap:8px"><span class="${l.ok ? 'bull' : 'mut'}">${l.ok ? '✔' : '✖'}</span><b>${esc(T.base(l.symbol || ''))}</b><span class="mut" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1">${esc(l.text || '')}</span><span class="mono mut">${l.t ? esc(T.time(l.t * 1000)) : ''}</span></div>`).join('') : '<span class="mut">هنوز تصمیم خودکاری ثبت نشده؛ بعد از اسکن کامل شروع می‌شود.</span>'}</div>`, { cls: 'hot' });
  };
  WG.equity = cx => { const ex = cx.ex, eq = (ex.equity_log || []).map(x => x.eq); const ch = ex.starting ? (ex.equity / ex.starting - 1) * 100 : 0;
    return pn('منحنی سرمایه', 'activity', `<div class="row sb"><b class="xl mono ${T.biasCls(ch)}">${T.usd(ex.equity)}</b><span class="mono ${T.biasCls(ch)}">${T.pct(ch)}</span></div><div style="margin-top:8px">${T.spark(eq.length > 1 ? eq : [ex.starting || 1, ex.equity || 1], { w: 420, h: 110, color: ch >= 0 ? T.col.bull : T.col.bear }).replace(/width="420"/, 'width="100%" preserveAspectRatio="none"')}</div>`); };
  WG.lessons = cx => { const l = cx.les, cs = (l.cases || []).slice(0, 3), rl = l.rules || [];
    return pn('حافظهٔ اشتباهات', 'brain', `<div class="row wrap" style="gap:6px;margin-bottom:8px">${T.chip(T.fa(rl.length) + ' قانون فعال', rl.length ? 'warn' : '', 'shield')}${T.chip(T.fa((l.total || {}).n || 0) + ' کالبدشکافی', 'info', 'flask')}</div>${cs.length ? cs.map(c => `<div class="callout ${c.win ? 'good' : 'bad'}" style="margin-bottom:6px;padding:7px 10px">${esc(c.lesson)}</div>`).join('') : '<div class="mut sm">بعد از بسته‌شدن اولین معامله‌ها، علت هر برد و باخت اینجا نوشته می‌شود و از تکرار اشتباه جلوگیری می‌کند.</div>'}${rl.slice(0, 2).map(r => `<div class="xs warn">⚠ ${esc(r.text)}</div>`).join('')}`); };
  WG.trends = cx => pn('روند هر ارز', 'compass', `<div class="col" style="gap:7px;max-height:320px;overflow:auto">${cx.R.slice().sort((a, b) => Math.abs(b.consensus || 0) - Math.abs(a.consensus || 0)).map(r => { const c = r.consensus || 0, d = c > 22 ? 'up' : c < -22 ? 'down' : 'range'; return `<div class="row nw trw" style="gap:9px;cursor:pointer" data-open="${r.symbol}"><span class="${d === 'up' ? 'bull' : d === 'down' ? 'bear' : 'warn'}" style="width:20px">${T.ic(d === 'up' ? 'up' : d === 'down' ? 'down' : 'pause')}</span><b style="width:50px">${esc(T.base(r.symbol))}</b><div style="flex:1">${T.bi(c)}</div><span class="seglights tr-lights" style="width:50px;--c:${d === 'down' ? T.col.bear : T.col.bull}">${['15m', '1h', '4h', '1d'].map(tf => { const x = r.tfs[tf]; return `<i class="${x && ((x.score > 0) === (c > 0)) && Math.abs(x.score) > 15 ? 'on' : ''}"></i>`; }).join('')}</span><span class="xs mut tr-lbl" style="width:64px">${d === 'up' ? 'صعودی' : d === 'down' ? 'نزولی' : 'رنج'}</span></div>`; }).join('')}</div>`);
  WG.opps = cx => { const k = +T.p('opps') || 6, top = cx.top.slice(0, k); return top.length ? `<div class="grid gB" style="grid-column:1/-1">${top.map(r => V.dash.opp(r)).join('')}</div>` : pn('بدون فرصت فعال', 'shield', T.empty('هیچ ارزی از همهٔ گیت‌های حاکم عبور نکرده است. این حالت عادی و محافظ سرمایه است.', 'shield')); };
  WG.heat = cx => pn('ماتریس ارز × تایم‌فریم', 'grid', V.dash.heat(cx.R), { sub: 'روی هر خانه بزنید' });
  WG.breadth = cx => { const mk = cx.mk; if (!mk) return ''; const bars = ['15m', '1h', '4h', '1d'].map(tf => { const p = (mk.per_tf || {})[tf]; return p ? `<div class="row sm"><b style="width:46px">${tf}</b><div style="flex:1" class="col"><div class="bar tall info"><i style="width:${p.above50}%"></i></div><div class="bar thin warn"><i style="width:${p.above200}%"></i></div></div><span class="mono xs mut br-txt" style="width:96px">EMA50 ${p.above50}٪ · EMA200 ${p.above200}٪</span></div>` : ''; }).join(''); return pn('پهنای بازار', 'layers', `<div class="col">${bars}</div>`); };
  const mover = (arr, cls) => (arr || []).slice(0, 5).map(x => `<div class="row sm" style="cursor:pointer" data-open="${x.symbol}"><b style="width:56px">${esc(x.base)}</b><div style="flex:1"><div class="bar ${cls === 'bull' ? '' : 'bear'}"><i style="width:${T.clamp(Math.abs(x.chg) * 6, 4, 100)}%"></i></div></div><b class="mono ${cls}" style="width:62px;text-align:left">${T.pct(x.chg)}</b></div>`).join('');
  WG.gainers = cx => cx.mk ? pn('بیشترین رشد', 'up', `<div class="col">${mover(cx.mk.gainers, 'bull')}</div>`) : '';
  WG.losers = cx => cx.mk ? pn('بیشترین افت', 'down', `<div class="col">${mover(cx.mk.losers, 'bear')}</div>`) : '';
  WG.log = cx => pn('آخرین سیگنال‌های ثبت‌شده', 'ledger', V.dash.log());
  T.WG = WG;

  /* ═════════ MARKET (coin cards) ═════════ */
  V.market = {
    f: { q: '', side: 'all', sort: null },
    mount() {
      if (!this.f.sort) this.f.sort = T.p('msort');
      view().innerHTML = `<div class="row wrap" style="margin-bottom:14px"><div class="seg" id="mf-side">${[['all', 'همه'], ['LONG', 'خرید'], ['SHORT', 'فروش'], ['WAIT', 'انتظار']].map(([k, n]) => `<button data-k="${k}" class="${this.f.side === k ? 'on' : ''}">${n}</button>`).join('')}</div>
        <div class="seg" id="mf-sort">${[['conf', 'اطمینان'], ['chg', 'تغییر ۲۴س'], ['vol', 'حجم'], ['name', 'نام']].map(([k, n]) => `<button data-k="${k}" class="${this.f.sort === k ? 'on' : ''}">${n}</button>`).join('')}</div>
        <input class="inp" id="mf-q" placeholder="جستجوی ارز…" value="${esc(this.f.q)}" style="width:200px"><span class="spacer"></span><button class="btn" id="mf-scan">${T.ic('refresh')}اسکن کامل</button></div><div id="mgrid" class="grid gA" style="grid-template-columns:repeat(auto-fill,minmax(min(var(--mminw,250px),100%),1fr))"></div>`;
      T.on(view(), '#mf-side button', 'click', (e, b) => { this.f.side = b.dataset.k; T.$$('#mf-side button').forEach(x => x.classList.toggle('on', x === b)); this.render(); });
      T.on(view(), '#mf-sort button', 'click', (e, b) => { this.f.sort = b.dataset.k; T.$$('#mf-sort button').forEach(x => x.classList.toggle('on', x === b)); this.render(); });
      T.$('#mf-q').addEventListener('input', e => { this.f.q = e.target.value; this.render(); });
      T.$('#mf-scan').addEventListener('click', () => T.scan(true));
      T.on(view(), '[data-open]', 'click', (e, t) => T.openCoin(t.dataset.open, t.dataset.tf));
      this.render();
    },
    render() {
      const g = T.$('#mgrid'); if (!g) return; let R = rows(); if (!R.length) { g.innerHTML = T.skel(6, 190); return; }
      const f = this.f; if (f.side !== 'all') R = R.filter(r => r.verdict === f.side); if (f.q) R = R.filter(r => r.symbol.includes(f.q.toUpperCase()));
      R.sort((a, b) => f.sort === 'chg' ? (b.ticker && b.ticker.change_pct || 0) - (a.ticker && a.ticker.change_pct || 0) : f.sort === 'vol' ? ((b.ticker && b.ticker.quote_volume) || 0) - ((a.ticker && a.ticker.quote_volume) || 0) : f.sort === 'name' ? a.symbol.localeCompare(b.symbol) : (b.confidence || 0) - (a.confidence || 0));
      g.className = 'grid ' + (T.p('mstyle') === 'list' ? 'g1' : 'gA'); g.style.gridTemplateColumns = T.p('mstyle') === 'list' ? '1fr' : 'repeat(auto-fill,minmax(min(var(--mminw,250px),100%),1fr))';
      g.innerHTML = R.map(r => {
        const tk = r.ticker || {}, ch = tk.change_pct || 0;
        return `<div class="glass coin ${r.stale || r.stale_data ? 'stale' : ''}" data-open="${r.symbol}"><div class="row">${coinIc(r)}<div><b>${esc(T.base(r.symbol))}</b><div class="mut xs">${esc(r.symbol)}</div></div><span class="spacer"></span>${T.grade(r.grade)}</div>
          <div class="row sb" style="margin:8px 0"><div><div class="px mono">${T.price(tk.price)}</div><div class="mono sm ${T.biasCls(ch)}">${T.pct(ch)}</div></div>${T.p('mspark') && T.p('mstyle') !== 'list' ? T.spark(r.spark, { w: 110, h: 42 }) : ''}</div>
          <div class="row sb">${T.sideBadge(r.verdict)}${r.stale || r.stale_data ? T.chip('داده کهنه' + (r.stale_tfs && r.stale_tfs.length ? ' · ' + r.stale_tfs.join(',') : ''), 'warn', 'alert') : `<span class="xs mut">اطمینان ${Math.round(r.confidence || 0)}٪</span>`}</div>
          ${T.p('mtf') ? `<div class="tfstrip">${['15m', '1h', '4h', '1d'].map(tf => { const c = r.tfs[tf]; return c ? `<div class="tfc ${c.side}" data-open="${r.symbol}" data-tf="${tf}" data-tip="${esc(tf + ': ' + T.sideFa(c.side) + ' · امتیاز ' + Math.round(c.score) + (c.valid_until ? '\nاعتبار تا ' + T.dt(c.valid_until) : ''))}"><b>${tf}</b>${T.ic(c.side === 'LONG' ? 'up' : c.side === 'SHORT' ? 'down' : 'pause')}${Math.round(c.score)}</div>` : `<div class="tfc"><b>${tf}</b>·</div>`; }).join('')}</div>` : ''}
          ${T.p('msince') ? `<div class="xs mut" style="margin-top:8px">${r.since && r.verdict !== 'WAIT' ? 'فعال از ' + esc(T.dt(r.since * 1000)) : 'به‌روز: ' + (r.age != null ? T.fa(r.age) + ' ثانیه پیش' : '—') + (r.price_src ? ' · قیمت ' + esc(r.price_src) : '')}</div>` : ''}</div>`;
      }).join('') || T.empty('ارزی با این فیلتر پیدا نشد.', 'search');
    },
    tick() { this.render(); }
  };

  /* ═════════ WORKSPACE ═════════ */
  const W_ = V.work = { chart: null, d: {}, loading: false, sym: null, tf: null };
  const TAB_GROUPS = [['تصمیم', ['trend', 'signal']], ['آینده', ['forecast', 'timeline']], ['ساختار', ['patterns', 'levels']], ['داده', ['indicators', 'micro']], ['هوش', ['ai', 'lessons']]];
  const TAB_ORDER = TAB_GROUPS.flatMap(g => g[1]);
  const tabsHtml = () => `<div class="tabgroup" id="wk-tabs">${TAB_GROUPS.map(([g, ids]) => `<div class="tg">${T.p('wgroups') ? `<small>${g}</small>` : ''}<div class="tabs">${ids.map(k => `<button data-t="${k}" class="${S.sub === k ? 'on' : ''}">${T.ic(TABS[k].ic)}${TABS[k].title}</button>`).join('')}</div></div>`).join('')}</div>`;
  W_.mount = function () {
    this.chart && this.chart.destroy(); this.chart = null; this.d = {}; this.sym = null;
    const wl = (S.status && S.status.symbols) || Object.keys((S.matrix && S.matrix.matrix) || {});
    if (!wl.includes(S.sym)) wl.unshift(S.sym);
    view().innerHTML = `<div class="glass wk-head" id="wkh">${T.skel(1, 56)}</div>
      <div class="row wrap sb" style="margin:12px 0"><div class="row wrap"><select class="inp" id="wk-sym">${wl.map(s => `<option ${s === S.sym ? 'selected' : ''} value="${s}">${esc(T.base(s))}</option>`).join('')}</select><input class="inp" id="wk-any" placeholder="ارز دیگر: مثلاً ARB" style="width:140px">
        <div class="seg" id="wk-tf">${['15m', '1h', '4h', '1d'].map(t => `<button data-tf="${t}" class="${S.tf === t ? 'on' : ''}">${t}</button>`).join('')}</div></div>
        <div class="row wrap" id="wk-layers">${[['ema', 'EMA'], ['vol', 'حجم'], ['fc', '۴۸ کندل آینده'], ['cone', 'مخروط احتمال'], ['lv', 'ورود/هدف'], ['pat', 'الگوهای کندلی'], ['struct', 'الگوهای ساختاری'], ['zones', 'حمایت/مقاومت']].map(([k, n]) => `<button class="chip ${S.cfg.layers[k] ? 'info' : ''}" data-l="${k}" style="cursor:pointer">${n}</button>`).join('')}${[['autol', 'روندخط‌ها'], ['fib', 'فیبوناچی'], ['bb', 'بولینگر'], ['vwap', 'VWAP'], ['pts', 'نقاط الگو']].map(([k, n]) => `<button class="chip ${T.p(k) ? 'info' : ''}" data-pp="${k}" style="cursor:pointer">${n}</button>`).join('')}</div></div>
      <div class="chartbox"><div class="chart-tools"><span class="chip ai">${T.ic('cone')}هر کندل، گذشته و آینده، تاریخ و ساعت دارد — نشانگر را روی نمودار ببرید</span><span class="spacer"></span>
        <button class="btn sm" data-z="1.25">${T.ic('zin')}</button><button class="btn sm" data-z="0.8">${T.ic('zout')}</button><button class="btn sm" data-z="now">${T.ic('compass')}اکنون</button><button class="btn sm" data-z="fit">${T.ic('refresh')}کل نمودار</button></div>
        <div id="chartHost" dir="ltr" style="position:relative"></div>
        <div class="legend"><span style="color:#ffc861"><i></i>EMA21</span><span style="color:#a88bff"><i></i>EMA50</span><span style="color:#62b0ff"><i class="dash"></i>ورود</span><span style="color:#ff5a86"><i class="dash"></i>حدضرر</span><span style="color:#35f2c1"><i class="dash"></i>اهداف</span><span style="color:#fff"><i class="dash"></i>میانهٔ پیش‌بینی</span><span class="mut">▲▼ الگوی کندلی · کادر نقطه‌چین = بازهٔ اعتبار الگو</span></div></div>
      <div style="margin:14px 0">${tabsHtml()}</div><div id="wk-body"></div>`;
    this.chart = new T.Chart(T.$('#chartHost')); this.chart.h = +T.p('chh') || 460; this.chart.applyOpts(); this.chart.resize();
    T.$('#wk-sym').addEventListener('change', e => { S.sym = e.target.value; this.switch(); });
    T.$('#wk-any').addEventListener('keydown', e => { if (e.key === 'Enter') { const v = e.target.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); if (v) { S.sym = v.endsWith('USDT') ? v : v + 'USDT'; this.switch(); } } });
    T.on(view(), '#wk-tf button', 'click', (e, b) => { S.tf = b.dataset.tf; T.$$('#wk-tf button').forEach(x => x.classList.toggle('on', x === b)); this.switch(); });
    T.on(view(), '#wk-layers [data-pp]', 'click', (e, b) => { const k = b.dataset.pp; T.P.set(k, !T.p(k)); b.classList.toggle('info', !!T.p(k)); this.chart.prep(); this.chart.draw(); });
    T.on(view(), '#wk-layers [data-l]', 'click', (e, b) => { const k = b.dataset.l; S.cfg.layers[k] = !S.cfg.layers[k]; b.classList.toggle('info', S.cfg.layers[k]); this.chart.applyOpts(); this.chart.draw(); T.saveCfg(); });
    T.on(view(), '[data-z]', 'click', (e, b) => { const z = b.dataset.z; z === 'fit' ? this.chart.fit() : z === 'now' ? this.chart.goNow() : this.chart.zoom(parseFloat(z)); });
    T.on(view(), '#wk-tabs button', 'click', (e, b) => { S.sub = b.dataset.t; S.subSet = 1; T.$$('#wk-tabs button').forEach(x => x.classList.toggle('on', x === b)); this.body(); });
    T.on(view(), '[data-act]', 'click', (e, b) => W_.act(b));
    this.load(true);
  };
  W_.switch = function () { S.cfg.last = { sym: S.sym, tf: S.tf }; T.saveCfg(); this.d = {}; this.chart.d = null; T.$('#wkh').innerHTML = T.skel(1, 56); T.$('#wk-body').innerHTML = T.skel(3, 120); this.load(true); };
  W_.load = async function (first) {
    if (this.loading) return; this.loading = true; const sym = S.sym, tf = S.tf, q = `?tf=${tf}`;
    const get = p => T.api(p).catch(e => ({ error: String(e.message || e) }));
    try {
      const [coin, deep, pats, tl] = await Promise.all([get(`/api/coin/${sym}${q}`), get(`/api/deep/${sym}${q}`), get(`/api/patterns/${sym}${q}`), get(`/api/timeline/${sym}`)]);
      if (sym !== S.sym || tf !== S.tf) return;
      this.d = Object.assign(this.d, { coin, deep, pats, tl }); this.sym = sym; this.tf = tf;
      this.head(); this.feed(first); this.body(first);
    } finally { this.loading = false; }
  };
  W_.plan = function () {
    const d = this.d.deep || {}, f = d.forecast || {}, e = f.edge || {}, tm = f.timing || {}, sg = d.signal;
    if (!sg || !['LONG', 'SHORT'].includes(d.verdict)) return { side: 'WAIT' };
    return { side: d.verdict, entry: sg.entry, stop: sg.stop, tp1: sg.tp1, tp2: sg.tp2, tp3: sg.tp3, rr: sg.risk_reward, room: (sg.levels || {}).room_r, p: { tp1: e.p_tp1, tp2: e.p_tp2, tp3: e.p_tp3, stop: e.p_stop }, eta: { tp1: tm.eta_tp1, tp2: tm.eta_tp2, tp3: tm.eta_tp3, stop: tm.eta_stop }, edge: e, timing: tm };
  };
  W_.feed = function (first) {
    const c = this.d.coin || {}, p = this.d.pats || {}; if (!c.klines) return;
    this.chart.applyOpts(); this.chart.h = +T.p('chh') || 460;
    const lv = (c.signal && c.signal.levels) || {};
    this.chart.set({ sym: this.sym, tf: this.tf, klines: c.klines, fc: c.forecast, bar_ms: c.bar_ms, plan: this.plan(), zones: lv.zones || [], pats: p.recent || [], structs: p.structs || [], auto: p.auto, forming: true });
  };
  W_.head = function () {
    const c = this.d.coin || {}, d = this.d.deep || {}, tk = c.ticker || {}, row = ((S.matrix && S.matrix.matrix) || {})[this.sym] || {}, v = d.verdict || row.verdict || 'WAIT', gov = d.governor || {}, ch = tk.change_pct || 0, close = c.forming_open ? c.forming_open + (c.bar_ms || T.tfMs(this.tf)) : 0;
    T.$('#wkh').innerHTML = `<div class="ic coin" style="width:52px;height:52px;border-radius:16px;display:grid;place-items:center;font-weight:800;background:${T.coinColor(this.sym)};padding:0;cursor:default">${esc(T.base(this.sym).slice(0, 4))}</div>
      <div><div class="lg"><b>${esc(T.base(this.sym))}</b> <span class="mut sm">/ USDT</span></div><div class="xs mut">${c.stale || c.fresh === false ? T.chip('داده کهنه', 'warn', 'alert') : T.chip('زنده', 'bull', 'wave')} آخرین به‌روزرسانی ${c.updated ? esc(T.time(c.updated * 1000, true)) : '—'}${c.price_src ? ' · قیمت از ' + esc(c.price_src) : ''}${c.kl_source ? ' · کندل از ' + esc(c.kl_source) : ''}${c.last_error ? ' · ' + T.chip('خطای آخرین اسکن', 'bear', 'alert') : ''}</div></div>
      <div><div class="big mono">${T.price(tk.price)}</div><div class="mono sm ${T.biasCls(ch)}">${T.pct(ch)} · ۲۴ ساعت</div></div><span class="spacer"></span>
      <div class="col" style="align-items:center"><div class="row">${T.sideBadge(v)}${T.grade(d.grade && d.grade.grade || row.grade)}</div><div class="xs mut">${esc(T.actFa(row.action))}${row.since && v !== 'WAIT' ? ' · فعال از ' + esc(T.dt(row.since * 1000)) : ''}</div></div>
      ${T.gauge(gov.confidence != null ? gov.confidence : row.confidence, { size: 74, label: 'اطمینان' })}
      <div class="col xs" style="min-width:170px"><div class="mut">کندل ${this.tf} جاری تا بسته‌شدن</div><b class="mono lg" id="wk-cd" data-close="${close}">—</b><div class="mut">بسته می‌شود ${close ? esc(T.time(close)) : ''}</div></div>`;
  };
  W_.body = function () {
    const b = T.$('#wk-body'); if (!b) return; const t = TABS[S.sub] || TABS.signal; if (!this.d.coin) { b.innerHTML = T.skel(3, 120); return; }
    if (this.d.coin.error && !this.d.coin.klines) { b.innerHTML = T.callout('داده‌ای برای این ارز/تایم‌فریم دریافت نشد: ' + esc(this.d.coin.error), 'bad'); return; }
    b.innerHTML = t.build(this.d, this); if (t.after) t.after(b, this.d, this);
  };
  W_.act = function (b) { const a = b.dataset.act; if (a === 'tf') { S.tf = b.dataset.v; this.switch(); } else if (a === 'order') T.prefillOrder && T.prefillOrder(this.plan(), this.sym); };
  W_.tick = function () { this.load(false); };
  W_.unmount = function () { this.chart && this.chart.destroy(); this.chart = null; };

  /* ── tab: final signal ── */
  const kv = (a, b, c) => `<div class="row sb sm" style="padding:3px 0"><span class="mut">${a}</span><b class="mono ${c || ''}">${b}</b></div>`;
  T.ladder = function (plan, px) {
    const items = [], d = plan.side === 'LONG' ? 1 : -1, risk = Math.abs(plan.entry - plan.stop) || 1, e = plan.edge || {}, eta = plan.eta || {}, p = plan.p || {};
    [['tp3', 'هدف ۳'], ['tp2', 'هدف ۲'], ['tp1', 'هدف ۱']].forEach(([k, n]) => plan[k] && items.push({ cls: 'tp', n, pr: plan[k], p: p[k], eta: eta[k], r: d * (plan[k] - plan.entry) / risk }));
    items.push({ cls: 'en', n: 'ورود', pr: plan.entry, r: 0 }); items.push({ cls: 'sl', n: 'حدضرر', pr: plan.stop, p: p.stop, eta: eta.stop, r: -1 });
    if (px) items.push({ cls: 'now', n: 'قیمت اکنون', pr: px });
    items.sort((a, b) => b.pr - a.pr);
    return `<div class="ladder">${items.map(i => `<div class="lv ${i.cls}" style="--p:${i.p != null ? Math.round(i.p * 100) : 0}%"><div class="glow"></div><div><div class="nm">${i.n}</div>${i.r != null && i.cls !== 'now' ? `<div class="sub mono">${i.r >= 0 ? '+' : ''}${i.r.toFixed(2)}R</div>` : ''}</div>
      <div><div class="pr mono">${T.price(i.pr)}</div><div class="sub mono">${i.cls === 'now' ? '' : T.pct((i.pr / plan.entry - 1) * 100)}</div></div>
      <div style="text-align:left">${i.p != null ? `<b class="mono ${i.cls === 'sl' ? 'bear' : 'bull'}">${Math.round(i.p * 100)}٪</b><div class="sub">${i.eta ? '~' + esc(T.dt(i.eta)) : 'احتمال'}</div>` : ''}</div></div>`).join('')}</div>`;
  };
  TABS.signal = {
    title: 'سیگنال نهایی', ic: 'target', build(D, w) {
      const d = D.deep || {}, c = D.coin || {}, gov = d.governor || {}, row = ((S.matrix && S.matrix.matrix) || {})[w.sym] || {}, v = d.verdict || 'WAIT', plan = w.plan(), px = (c.ticker || {}).price, tm = (d.forecast || {}).timing || {};
      if (d.error) return T.callout('تحلیل ترکیبی در دسترس نیست: ' + esc(d.error), 'bad');
      const cons = d.consensus_score || 0, why = (d.grade && d.grade.why) || [];
      let main = `<div class="row wrap" style="gap:18px;align-items:flex-start"><div class="col" style="gap:10px;flex:1;min-width:220px"><div class="row">${T.sideBadge(v)}${T.grade(d.grade && d.grade.grade)}${T.chip(esc(T.actFa(row.action)), v === 'WAIT' ? 'warn' : 'bull', 'bolt')}</div>
        <div class="sm ink2">${esc(T.sideFa(d.fuse_side))} طبق اجماع تایم‌فریم‌ها — ${v === 'WAIT' ? '<b class="warn">حاکم مرکزی اجازهٔ انتشار نداد</b>' : '<b class="bull">حاکم مرکزی تایید کرد</b>'}</div>
        <div><div class="row sb xs mut"><span>اجماع وزنی چندتایم‌فریم</span><b class="mono ${T.biasCls(cons)}">${cons > 0 ? '+' : ''}${cons}</b></div>${T.bi(cons)}</div>
        <div class="row" style="gap:16px">${T.gauge(gov.confidence, { size: 78, label: 'اطمینان' })}${T.gauge(gov.trust, { size: 78, label: 'اعتماد داده', color: T.col.info })}${T.gauge((d.conviction || 0) * 100, { size: 78, label: 'قاطعیت', color: T.col.ai })}</div></div>
        <div class="col sm" style="flex:1;min-width:230px;gap:5px"><div class="ph" style="margin:0">${T.ic('clock')}پنجرهٔ زمانی سیگنال</div>
        ${kv('کندل مبنای تحلیل بسته شد', tm.as_of ? esc(T.dt(tm.as_of)) : '—')}${kv('تحلیل معتبر تا', tm.valid_until ? esc(T.dt(tm.valid_until)) : '—')}${kv('ماندگاری', tm.valid_bars ? T.fa(tm.valid_bars) + ' کندل ' + w.tf : '—')}
        ${kv('پیش‌بینی ۴۸ کندل تا', (d.forecast || {}).valid_until ? esc(T.dt(d.forecast.valid_until)) : '—')}${kv('فعال از', d.active ? esc(T.dt(d.active.t * 1000)) : v === 'WAIT' ? '—' : 'همین اسکن')}
        ${tm.valid_until ? `<div class="xs mut">${esc(T.rel(tm.valid_until))} · پس از این زمان سیگنال باید با کندل تازه دوباره سنجیده شود.</div>` : ''}</div></div>`;
      let lad = '';
      if (plan.side !== 'WAIT') {
        const e = plan.edge || {};
        lad = `<div class="grid g2" style="margin-top:14px"><div><div class="ph">${T.ic('ruler')}نردبان معامله (احتمال و زمان رسیدن)</div>${T.ladder(plan, px)}</div><div class="col"><div class="ph">${T.ic('flask')}آمار شبیه‌سازی ${T.fa(e.horizon || 16)} کندل</div>
          ${kv('R:R تا هدف ۲', plan.rr)}${plan.room != null ? kv('فضا تا نزدیک‌ترین سطح مخالف', plan.room + 'R', plan.room < 1 ? 'bear' : '') : ''}${kv('احتمال برد (R>0)', e.p_win != null ? Math.round(e.p_win * 100) + '٪' : '—', 'bull')}${kv('امید ریاضی', e.ev_r != null ? (e.ev_r > 0 ? '+' : '') + e.ev_r + 'R' : '—', T.biasCls(e.ev_r))}${kv('کسر کلی (Kelly)', e.kelly != null ? Math.round(e.kelly * 100) + '٪' : '—')}${kv('بدترین ۵٪ / بهترین ۵٪', e.worst_r != null ? e.worst_r + 'R / ' + e.best_r + 'R' : '—')}
          ${kv('پوزیشن باز می‌ماند (بدون هدف/حدضرر)', e.p_open != null ? Math.round(e.p_open * 100) + '٪' : '—')}<div class="xs mut" style="margin-top:6px">زمان‌ها میانهٔ مسیرهای شبیه‌سازی‌شده‌ای است که به آن سطح رسیده‌اند؛ تضمین نیستند.</div>
          <div class="row" style="margin-top:10px"><button class="btn pri" data-act="order">${T.ic('wallet')}ثبت در صرافی کاغذی</button></div></div></div>`;
      } else {
        const pl = d.plans || {}, tr = d.triggers || {};
        const sc = (side, p, trig, txt) => p ? `<div class="glass pn" style="border-color:${side === 'LONG' ? '#35f2c155' : '#ff5a8655'}"><div class="row sb">${T.sideBadge(side)}<span class="chip">${T.ic('flag')}شرط فعال‌شدن</span></div><div class="sm" style="margin:8px 0">${txt} <b class="mono">${T.price(trig)}</b> بسته شود و حاکم تایید کند.</div>
          <div class="grid g3 sm" style="gap:6px"><div><span class="mut xs">ورود</span><br><b class="mono">${T.price(p.entry)}</b></div><div><span class="mut xs">حدضرر</span><br><b class="mono bear">${T.price(p.stop)}</b></div><div><span class="mut xs">هدف‌ها</span><br><b class="mono bull">${T.price(p.tp1)} / ${T.price(p.tp2)}</b></div></div><div class="xs mut" style="margin-top:6px">R:R ${p.rr} · این سناریو تا ${tm.valid_until ? esc(T.dt(tm.valid_until)) : '—'} قابل بررسی است.</div></div>` : '';
        lad = `<div style="margin-top:14px">${T.callout('<b>اکنون ورود توصیه نمی‌شود.</b> ' + esc((d.governor && d.governor.vetoes && d.governor.vetoes[0]) || row.action || 'شرایط کافی نیست') + '. سناریوهای مشروط زیر فقط وقتی معتبرند که شرط قیمتی محقق شود.', 'warn', 'pause')}</div><div class="grid g2" style="margin-top:12px">${sc('LONG', pl.LONG, tr.LONG && tr.LONG.above, 'خرید اگر قیمت بالای')}${sc('SHORT', pl.SHORT, tr.SHORT && tr.SHORT.below, 'فروش اگر قیمت زیر')}</div>`;
      }
      const left = T.panel('حکم نهایی و برنامهٔ معامله', 'crown', main + lad);
      const votes = ['15m', '1h', '4h', '1d'].map(tf => { const s = (c.all_tf || {})[tf]; if (!s) return ''; const vu = (s.timing || {}).valid_until; return `<div class="row" style="gap:10px;padding:7px 0;border-bottom:1px solid var(--gl2)"><b style="width:38px" class="${tf === w.tf ? 'bull' : ''}">${tf}</b><span class="chip ${T.sideCls(s.side)}" style="width:62px;justify-content:center">${T.sideFa(s.side)}</span><div style="flex:1">${T.bi(s.score)}<div class="xs mut mono" style="display:flex;justify-content:space-between"><span>${s.score > 0 ? '+' : ''}${Math.round(s.score)}</span><span>${vu ? 'تا ' + esc(T.dt(vu)) : ''}</span></div></div><button class="btn sm" data-act="tf" data-v="${tf}">${T.ic('eye')}</button></div>`; }).join('');
      const comps = Object.entries(gov.components || {}).map(([k, val]) => `<div class="row sm" style="gap:10px"><span style="width:128px" class="ink2">${CMP[k] || k}</span><div style="flex:1">${k === 'data_trust' ? T.bar(val * 100, { cls: 'info' }) : T.bi(val * 100)}</div><b class="mono xs" style="width:42px;text-align:left">${val > 0 && k !== 'data_trust' ? '+' : ''}${(+val).toFixed(2)}</b></div>`).join('');
      const fa = r => String(r).replace(/\b(context|data_trust|derivatives|forecast|htf_trend|ltf_trigger|momentum|mtf_setup|pattern|structure|volume_flow|x_layer)\b/g, k => CMP[k]), reasons = (gov.reasons || []).map(r => `<li>${esc(fa(r))}</li>`).join(''), vetoes = (gov.vetoes || []).map(r => `<li class="bear">${esc(fa(r))}</li>`).join('');
      const right = `<div class="col" style="gap:14px">${T.panel('رأی هر تایم‌فریم', 'layers', votes || T.empty('داده‌ای نیست'))}${T.panel('اجزای تصمیم حاکم', 'brain', `<div class="col" style="gap:7px">${comps}</div>`, { sub: 'منفی = نزولی · مثبت = صعودی' })}</div>`;
      const bottom = `<div class="grid g3" style="margin-top:14px">${T.panel('دلایل حاکم', 'check', `<ul class="sm" style="margin:0;padding-inline-start:18px;line-height:1.9">${reasons || '<li class="mut">—</li>'}</ul>`)}${T.panel('وتوها و ریسک‌ها', 'shield', `<ul class="sm" style="margin:0;padding-inline-start:18px;line-height:1.9">${vetoes || '<li class="mut">وتویی وجود ندارد</li>'}${((c.signal && c.signal.warnings) || []).slice(0, 5).map(x => `<li class="warn">${esc(x)}</li>`).join('')}</ul>`)}
        ${T.panel('امتیاز درجه‌بندی', 'flag', `<div class="col sm" style="gap:4px">${why.length ? '' : '<div class="mut">برای حکم انتظار، درجه‌بندی انجام نمی‌شود؛ درجه فقط برای سیگنال‌های منتشرشده محاسبه می‌شود.</div>'}${why.map(x => `<div class="row" style="gap:8px"><span class="chip ${x.p > 0 ? 'bull' : x.p < 0 ? 'bear' : ''}" style="width:34px;justify-content:center">${x.p > 0 ? '+' : ''}${x.p}</span><span>${esc(x.t)}</span></div>`).join('')}</div>`)}</div>
        ${T.panel('خلاصهٔ تحلیل', 'book', `<div class="sm" style="line-height:2;overflow-wrap:anywhere">${esc(fa(String(d.narrative || '').replace(/ — /g, '\n')).replace(/\n/g, ' — ')).replace(/ \| /g, '<br>')}</div>`, { cls: '' })}`;
      return `<div class="grid ${T.p('wsplit') === 'stack' ? '' : 'split'}">${left}${right}</div>${bottom}`;
    }
  };

  /* ── tab: 48-candle forecast ── */
  TABS.forecast = {
    title: 'پیش‌بینی ۴۸ کندل', ic: 'cone', build(D, w) {
      const c = D.coin, f = c.forecast || {}, cs = (f.candles || []).filter(x => !x.current), bd = f.bands || {}, sp = f.step_prob || [], last = c.klines[c.klines.length - 1];
      if (!cs.length) return T.callout('پیش‌بینی برای این تایم‌فریم در دسترس نیست (کندل کافی نیست).', 'warn');
      const dir = f.direction === 'bullish' ? ['صعودی', 'bull'] : f.direction === 'bearish' ? ['نزولی', 'bear'] : ['خنثی', 'warn'], end = cs[cs.length - 1];
      const off = (f.candles || []).length - cs.length;
      const strip = cs.map((k, j) => { const pu = sp[j + off] != null ? sp[j + off] : 0.5, a = Math.abs(pu - .5) * 2; return `<i style="background:${pu >= .5 ? `rgba(53,242,193,${.15 + a * .8})` : `rgba(255,90,134,${.15 + a * .8})`}" data-tip="${esc(T.dt(k.t) + '\nکندل ' + T.fa(j + 1) + '\nاحتمال بالاتر از قیمت فعلی: ' + Math.round(pu * 100) + '٪\nمیانه: ' + T.price(bd.p50 && bd.p50[j + off]))}"></i>`; }).join('');
      const mil = cs.map((k, j) => [k, j]).filter(([k, j]) => (j + 1) % 6 === 0 || j === 0 || j === cs.length - 1);
      const tbl = `<table class="tbl"><tr><th>کندل</th><th>باز شدن (تاریخ و ساعت)</th><th>بسته شدن</th><th>پایین ۱۰٪</th><th>میانه</th><th>بالا ۹۰٪</th><th>احتمال بالاتر</th></tr>${mil.map(([k, j]) => `<tr><td>${T.fa(j + 1)}</td><td>${T.tstamp(k.t)}</td><td>${T.tstamp(k.t_close)}</td><td class="mono bear">${T.price(bd.p10[j + off])}</td><td class="mono">${T.price(bd.p50[j + off])}</td><td class="mono bull">${T.price(bd.p90[j + off])}</td><td><b class="mono ${sp[j + off] >= .5 ? 'bull' : 'bear'}">${Math.round(sp[j + off] * 100)}٪</b></td></tr>`).join('')}</table>`;
      const h = f.hist || {}, mx = Math.max(1, ...(h.counts || [1])), hist = (h.counts || []).map((n, i) => { const mid = ((h.edges[i] + h.edges[i + 1]) / 2); return `<i style="height:${Math.max(3, n / mx * 100)}%;--c:${mid >= 0 ? '#35f2c1' : '#ff5a86'}" data-tip="${T.pct(h.edges[i])} تا ${T.pct(h.edges[i + 1])}\n${T.fa(n)} مسیر"></i>`; }).join('');
      const cmp = ['15m', '1h', '4h', '1d'].map(tf => { const x = (c.all_forecasts || {})[tf]; if (!x || !x.candles) return ''; const dd = x.direction === 'bullish' ? 'bull' : x.direction === 'bearish' ? 'bear' : 'warn'; return `<div class="row sm" style="gap:10px;padding:6px 0"><b style="width:38px">${tf}</b><span class="chip ${dd}" style="width:64px;justify-content:center">${x.direction === 'bullish' ? 'صعودی' : x.direction === 'bearish' ? 'نزولی' : 'خنثی'}</span><div style="flex:1">${T.bar(x.prob_up * 100, { cls: x.prob_up >= .5 ? '' : 'bear' })}</div><b class="mono" style="width:44px">${Math.round(x.prob_up * 100)}٪</b><span class="mono xs mut" style="width:62px">${T.pct(x.expected_move_pct)}</span><span class="xs mut" style="width:150px">تا ${esc(T.dt(x.valid_until))}</span></div>`; }).join('');
      return `<div class="kpis">${T.kpi('جهت غالب', `<span class="${dir[1]}">${dir[0]}</span>`, { ic: 'compass', c: T.col[dir[1]], sub: 'در ' + T.fa(cs.length) + ' کندل ' + w.tf })}${T.kpi('احتمال بالاتر در پایان', Math.round(f.prob_up * 100) + '٪', { ic: 'up', c: T.col.bull, cls: f.prob_up >= .5 ? 'bull' : 'bear' })}${T.kpi('حرکت میانه', T.pct(f.expected_move_pct), { ic: 'activity', cls: T.biasCls(f.expected_move_pct) })}${T.kpi('نوسان هر کندل (σ)', T.pct(f.sigma_pct, 2, false), { ic: 'wave', c: T.col.ai })}
        ${T.kpi('بازهٔ ۱۰–۹۰٪ پایان', T.price(bd.p10[bd.p10.length - 1]) + ' – ' + T.price(bd.p90[bd.p90.length - 1]), { ic: 'cone', c: T.col.info })}${T.kpi('پایان افق پیش‌بینی', esc(T.time(end.t_close)), { ic: 'clock', sub: esc(T.dtFull(end.t_close)) })}</div>
        <div class="grid g2" style="margin-top:14px">${T.panel('۴۸ کندل آینده — احتمال بالاتر بودن از قیمت فعلی', 'pulse', `<div class="fstrip">${strip}</div><div class="row sb xs mut" style="margin-top:8px"><span>${esc(T.dt(cs[0].t))}</span><span>روشن‌تر = قطعیت بیشتر · سبز = بالاتر · قرمز = پایین‌تر</span><span>${esc(T.dt(end.t))}</span></div>`)}
        ${T.panel('توزیع بازدهٔ پایان افق', 'wave', `<div class="hist">${hist}</div><div class="row sb xs mut mono" style="margin-top:6px"><span>${T.pct(h.edges && h.edges[0])}</span><span>۰٪</span><span>${T.pct(h.edges && h.edges[h.edges.length - 1])}</span></div>`)}</div>
        <div style="margin-top:14px">${T.panel('نقاط عطف زمانی (هر ۶ کندل)', 'calendar', `<div class="scroll-x">${tbl}</div>`, { sub: 'قیمت آخر ' + T.price(last.c) })}</div>
        <div style="margin-top:14px">${T.panel('مقایسهٔ همهٔ تایم‌فریم‌ها', 'layers', cmp)}</div>
        <div class="xs mut" style="margin-top:10px">این یک توزیع احتمالاتی از شبیه‌سازی تاریخی است، نه وعده. کندل‌های نمودار «مسیر نوعی» هستند و مخروط، بازهٔ محتمل را نشان می‌دهد.</div>`;
    }
  };

  /* ── tab: patterns ── */
  const stDef = {};
  TABS.patterns = {
    title: 'الگوها', ic: 'shapes', filter: 'active', build(D, w) {
      const p = D.pats || {}; if (p.error) return T.callout('الگوها محاسبه نشد: ' + esc(p.error), 'bad');
      const all = this.filter === 'all', structs = (p.structs || []).filter(s => all || s.alive), cands = (p.recent || []).filter(r => (all || r.alive) && (all || r.bias !== 0 || r.alive)).slice(0, all ? 40 : 14), net = (p.summary && p.summary.score) || 0;
      const card = (r, st) => {
        const col = r.bias > 0 ? 'bull' : r.bias < 0 ? 'bear' : 'warn', vb = r.valid_bars || 1, left = st ? Math.max(0, Math.round((r.valid_until - T.nowMs()) / T.tfMs(r.tf))) : r.bars_left, pctL = T.clamp(left / vb * 100, 0, 100), name = r.fa;
        return `<div class="pat ${r.alive ? '' : 'dim'}"><div class="gl">${st ? T.structGlyph(r.k, r.bias, 64) : T.candleGlyph(r.k, 62)}</div><div><h4>${esc(name)} ${T.chip(esc(r.state_fa), r.alive ? (r.state === 'confirmed' || r.state === 'triggered' ? 'bull' : 'info') : 'warn')}${T.chip(r.bias > 0 ? 'صعودی' : r.bias < 0 ? 'نزولی' : 'خنثی', col)}${T.chip(st ? 'ساختاری' : 'کندلی', '')}<span class="spacer"></span><span class="mono xs mut">${w.tf}</span></h4>
          <div class="win"><div>شروع الگو<b class="mono">${esc(T.dt(r.t_start))}</b></div><div>پایان تشکیل<b class="mono">${esc(T.dt(r.t_end))}</b></div><div>معتبر تا<b class="mono ${r.alive ? 'info' : 'mut'}">${esc(T.dt(r.valid_until))}</b></div></div>
          <div class="row sm" style="gap:10px"><span class="mut xs" style="width:92px">${r.alive ? 'مانده: ' + T.fa(left) + ' کندل' : 'پایان اعتبار'}</span><div style="flex:1">${T.bar(pctL, { cls: r.alive ? 'info' : '' })}</div><span class="xs mut">${r.alive ? esc(T.rel(r.valid_until)) : ''}</span></div>
          ${st ? `<div class="row wrap xs" style="gap:14px;margin-top:6px"><span>سقف شکست: <b class="mono bull">${T.price(r.break_up)}</b></span><span>کف شکست: <b class="mono bear">${T.price(r.break_dn)}</b></span><span>هدف: <b class="mono ${col}">${T.price(r.target)}</b>${r.target_eta_t ? ' <span class="mut">(~' + esc(T.dt(r.target_eta_t)) + ')</span>' : ''}</span><span class="mut">${esc(r.valid_basis || '')}</span></div>`
            : `<div class="row wrap xs" style="gap:14px;margin-top:6px">${r.invalid_level ? `<span>ابطال با بسته‌شدن ${r.bias > 0 ? 'زیر' : 'بالای'}: <b class="mono warn">${T.price(r.invalid_level)}</b></span>` : ''}${r.confirm_level ? `<span>تایید با بسته‌شدن ${r.bias > 0 ? 'بالای' : 'زیر'}: <b class="mono ${col}">${T.price(r.confirm_level)}</b></span>` : ''}<span>قدرت: <b class="mono">${Math.round(r.strength * 100)}٪</b></span>${r.at_level ? T.chip('روی ناحیهٔ کلیدی', 'info', 'flag') : ''}</div>`}
          <div class="sm ink2" style="margin-top:6px;line-height:1.8">${esc(r.meaning)} <span class="mut">${esc(r.expect)}</span></div>${r.verdict ? `<div class="callout ${r.verdict.level === 'good' ? 'good' : r.verdict.level === 'bad' ? 'bad' : 'info'}" style="margin-top:6px;padding:6px 10px">${esc(r.verdict.text)}</div>` : ''}</div></div>`;
      };
      return `<div class="row wrap sb" style="margin-bottom:12px"><div class="seg" id="pat-f"><button data-f="active" class="${all ? '' : 'on'}">فقط فعال</button><button data-f="all" class="${all ? 'on' : ''}">همه (با تاریخچه)</button></div>
        <div class="row" style="gap:12px;min-width:260px"><span class="sm mut">برآیند الگوها</span><div style="flex:1">${T.bi(net)}</div><b class="mono ${T.biasCls(net)}">${net > 0 ? '+' : ''}${net}</b></div></div>
        <div class="sec">${T.ic('shapes')} الگوهای ساختاری (${T.fa(structs.length)})</div><div class="grid gB">${structs.map(s => card(s, true)).join('') || T.panel('الگوی ساختاری فعالی نیست', 'shapes', T.empty('در این تایم‌فریم مثلث، گوه، کانال، دوقلو یا سر و شانهٔ معتبری شکل نگرفته است.', 'shapes'), { cls: 'span-all' })}</div>
        <div class="sec">${T.ic('candles')} الگوهای کندلی (${T.fa(cands.length)})</div><div class="grid gB">${cands.map(r => card(r, false)).join('') || T.panel('الگوی کندلی فعالی نیست', 'candles', T.empty('الگوی معتبر کندلی در این بازه نیست.', 'candles'), { cls: 'span-all' })}</div>`;
    },
    after(root, D, w) { T.on(root, '#pat-f button', 'click', (e, b) => { this.filter = b.dataset.f; w.body(); }); }
  };

  /* ── tab: timeline ── */
  TABS.timeline = {
    title: 'زمان‌بندی', ic: 'clock', build(D, w) {
      const tl = D.tl || {}, lanes = tl.lanes || []; if (!lanes.length) return T.callout('زمان‌بندی هنوز آماده نیست؛ اسکن اول را صبر کنید.', 'info');
      const now = T.nowMs();
      const lane = l => {
        const tm = l.timing || {}, ms = tm.bar_ms || T.tfMs(l.tf), f = l.forecast || {}, t0 = (tm.as_of || now) - 14 * ms, t1 = (f.until || (tm.valid_until || now) + 20 * ms), span = t1 - t0, X = t => T.clamp((t - t0) / span * 100, 0, 100);
        const bar = (a, b, lab, col, y, ghost, tip) => `<div class="tb ${ghost ? 'ghost' : ''}" style="--tc:${col};left:${X(a)}%;width:${Math.max(1.2, X(b) - X(a))}%;top:${y}px" data-tip="${esc(tip || lab)}">${esc(lab)}</div>`;
        const mk = (t, col, tip) => t ? `<div class="mk" style="left:${X(t)}%;top:6px;color:${col}" data-tip="${esc(tip)}"></div>` : '';
        let h = `<div class="lane" style="--lh:${118 + Math.min(4, (l.patterns || []).length) * 19}px;direction:ltr"><span class="lb" style="direction:rtl;left:10px;right:auto">${l.tf} · ${T.sideFa(l.side)}</span><div class="nowline" style="left:${X(now)}%"></div>`;
        h += bar(tm.valid_from || tm.as_of, tm.valid_until, 'اعتبار سیگنال', T.col[T.sideCls(l.side)] || '#ffc861', 26, 0, `اعتبار سیگنال ${l.tf}\nاز ${T.dt(tm.valid_from)}\nتا ${T.dt(tm.valid_until)}`);
        h += bar(f.from, f.until, 'پیش‌بینی ' + T.fa(f.bars || 48) + ' کندل', T.col.info, 45, 1, `افق پیش‌بینی\nاز ${T.dt(f.from)}\nتا ${T.dt(f.until)}`);
        h += mk(tm.eta_tp1, T.col.bull, 'رسیدن تقریبی به هدف ۱: ' + T.dt(tm.eta_tp1)) + mk(tm.eta_tp2, T.col.bull, 'هدف ۲: ' + T.dt(tm.eta_tp2)) + mk(tm.eta_stop, T.col.bear, 'برخورد تقریبی به حدضرر: ' + T.dt(tm.eta_stop));
        (l.patterns || []).slice(0, 4).forEach((p, i) => { h += bar(p.t_start, p.valid_until, p.fa + ' (' + p.state_fa + ')', p.bias > 0 ? T.col.bull : p.bias < 0 ? T.col.bear : T.col.warn, 64 + i * 19, 0, `${p.fa}\nشروع ${T.dt(p.t_start)}\nمعتبر تا ${T.dt(p.valid_until)}`); });
        for (let k = 0; k <= 5; k++) { const t = t0 + span * k / 5; h += `<span class="tk" style="left:${k * 20}%;transform:translateX(${k === 0 ? '0' : k === 5 ? '-100%' : '-50%'})"><b>${esc(T.time(t))}</b><br>${esc(T.date(t))}</span>`; }
        return h + '</div>';
      };
      const l0 = lanes[0], tm0 = l0.timing || {};
      return `${T.callout('هر خط یک تایم‌فریم است. نوار پررنگ = اعتبار سیگنال، نوار شفاف = افق ۴۸ کندل پیش‌بینی، لوزی‌ها = زمان تقریبی رسیدن به هدف/حدضرر، نوارهای رنگی پایین = الگوها تا زمان انقضا. خط زرد = اکنون.', 'info', 'clock')}
        <div style="margin-top:12px" class="col">${lanes.map(l => `<div class="glass pn" style="padding:12px 14px">${lane(l)}<div class="row wrap xs mut" style="gap:16px;margin-top:4px"><span>مبنا: ${esc(T.dt(l.timing && l.timing.as_of))}</span><span>اعتبار تا: ${esc(T.dt(l.timing && l.timing.valid_until))}</span><span>افق: ${esc(T.dt(l.forecast && l.forecast.until))}</span><span>${T.fa((l.patterns || []).length)} الگوی فعال</span></div></div>`).join('')}</div>`;
    }
  };
})(window);

(function (W) {
  const T = W.TT, esc = T.esc, S = T.S, TABS = T.TABS;
  const kv = (a, b, c) => `<div class="row sb sm" style="padding:3px 0"><span class="mut">${a}</span><b class="mono ${c || ''}">${b}</b></div>`;
  /* ── tab: trend (what is this coin doing, how sure are we, what breaks it) ── */
  TABS.trend = {
    title: 'روند ارز', ic: 'compass', build() { return '<div id="trendbox">' + T.skel(3, 120) + '</div>'; },
    async after(root, D, w) {
      const t = await T.api('/api/trend/' + w.sym).catch(() => null); const el = T.$('#trendbox'); if (!el || S.sub !== 'trend') return;
      if (!t || !t.ok) { el.innerHTML = T.callout(esc((t && t.error) || 'تحلیل روند آماده نیست'), 'warn'); return; }
      const o = t.overall, d = o.dir, cls = d === 'up' ? 'bull' : d === 'down' ? 'bear' : 'warn', gcol = d === 'up' ? T.col.bull : d === 'down' ? T.col.bear : T.col.warn, lv = t.levels;
      const tfc = Object.values(t.tfs).map(v => { const c = v.dir === 'up' ? 'bull' : v.dir === 'down' ? 'bear' : 'warn'; return `<div class="ttf"><div class="row sb"><b>${v.tf}</b><span class="chip ${c}">${T.ic(v.dir === 'up' ? 'up' : v.dir === 'down' ? 'down' : 'pause')}${v.dir_fa} ${v.strength_fa}</span></div>${T.bar(v.strength, { cls: v.dir === 'down' ? 'bear' : v.dir === 'range' ? 'warn' : '' })}
        <div class="xs mut" style="margin-top:8px;line-height:1.9">قدرت ${v.strength}٪ · <bdi dir="ltr">ADX ${v.adx}</bdi> · <bdi dir="ltr">RSI ${v.rsi}</bdi><br>${esc(v.structure)}<br>چینش EMA: <b class="${v.ema_stack === 'bull' ? 'bull' : v.ema_stack === 'bear' ? 'bear' : 'warn'}">${v.ema_stack === 'bull' ? 'صعودی' : v.ema_stack === 'bear' ? 'نزولی' : 'مختلط'}</b><br>فاز: <b>${esc(v.phase_fa)}</b><br>روی همین سمت EMA۵۰ از ${esc(T.dt(Date.now() - v.age_ms))} (${T.fa(v.age_bars)} کندل)${v.pullback_depth != null && v.phase === 'pullback' ? '<br>عمق اصلاح: ' + Math.round(v.pullback_depth * 100) + '٪ از آخرین موج' : ''}</div></div>`; }).join('');
      const ex = Object.entries(t.expect || {}).map(([tf, e]) => `<div class="row sm" style="gap:10px;padding:6px 0;border-bottom:1px solid var(--gl2)"><b style="width:32px">${tf}</b><span class="chip ${e.prob_up >= .5 ? 'bull' : 'bear'}" style="width:78px;justify-content:center">${Math.round(e.prob_up * 100)}٪ بالاتر</span><span class="mono ${T.biasCls(e.move_pct)}">${T.pct(e.move_pct)}</span><span class="xs mut mono">${T.price(e.lo)} ← ${T.price(e.mid)} → ${T.price(e.hi)}</span><span class="xs mut">تا ${esc(T.dt(e.t_end))}</span></div>`).join('');
      el.innerHTML = `<div class="grid split"><section class="glass pn hot"><div class="trendhero"><div class="arrowbig ${d}">${T.ic(d === 'up' ? 'up' : d === 'down' ? 'down' : 'pause')}</div><div class="col" style="gap:6px"><div class="xl ${cls}">روند ${esc(o.dir_fa)} · ${esc(o.strength_fa)}</div><div class="sm ink2">${esc(o.phase_fa)} · تایم‌فریم اصلی ${o.primary_tf}</div><div class="row wrap" style="gap:10px 14px">${T.gauge(o.strength, { size: 76, label: 'قدرت', color: gcol })}${T.gauge(o.confidence, { size: 76, label: 'اطمینان', color: T.col.info })}${T.gauge(o.agree, { size: 76, label: 'هم‌جهتی', color: T.col.ai })}</div></div></div>
          <div style="margin-top:14px;line-height:2.1" class="sm">${o.statement.map((x, i) => `<div class="${i === 0 ? 'ink' : 'ink2'}" style="${i === 0 ? 'font-weight:700;font-size:1.05em' : ''}">${esc(x)}</div>`).join('')}</div></section>
        <div class="col" style="gap:14px">${T.panel('سطوح تاییدکننده و ابطال', 'ruler', `${(lv.resistance || []).slice().reverse().map((p, i) => kv('مقاومت ' + T.fa((lv.resistance.length - i)), T.price(p) + ' <span class="xs mut">' + T.pct((p / lv.price - 1) * 100) + '</span>', 'bear')).join('')}${kv('قیمت اکنون', T.price(lv.price), 'warn')}${(lv.support || []).map((p, i) => kv('حمایت ' + T.fa(i + 1), T.price(p) + ' <span class="xs mut">' + T.pct((p / lv.price - 1) * 100) + '</span>', 'bull')).join('')}${lv.invalidation ? `<div class="callout warn" style="margin-top:8px">${T.ic('alert')}<div>ابطال روند: بسته‌شدن ${d === 'up' ? 'زیر' : 'بالای'} <b class="mono">${T.price(lv.invalidation)}</b>${lv.invalidation_htf ? ' · ابطال قوی: <b class="mono">' + T.price(lv.invalidation_htf) + '</b>' : ''}</div></div>` : ''}`)}
          ${T.panel('انتظار آماری ۴۸ کندل', 'cone', ex || T.empty('پیش‌بینی آماده نیست'))}</div></div>
        <div class="sec">${T.ic('layers')} روند به تفکیک تایم‌فریم</div><div class="grid g4">${tfc}</div>
        <div class="grid g2" style="margin-top:14px">${T.panel('شواهد این قضاوت', 'check', t.checklist.map(c => `<div class="chk"><i class="${c.ok ? 'y' : 'n'}">${c.ok ? '✓' : '✕'}</i><span>${esc(c.t)}</span></div>`).join(''))}${T.panel('ریسک‌ها و نکات احتیاط', 'shield', t.risks.length ? t.risks.map(r => T.callout(esc(r), 'warn', 'alert')).join('<div style="height:6px"></div>') : T.callout('ریسک ساختاری مهمی دیده نمی‌شود؛ ولی همیشه حدضرر را رعایت کنید.', 'good'))}</div>`;
      if (T.P && T.P.fx) T.P.fx.after(el);
    }
  };
  /* ── tab: lessons + auto-trade ledger of this coin ── */
  TABS.lessons = {
    title: 'درس‌ها و ثبت خودکار', ic: 'brain', build() { return '<div id="lessbox">' + T.skel(2, 120) + '</div>'; },
    async after(root, D, w) {
      const l = await T.api('/api/lessons').catch(() => ({})); const el = T.$('#lessbox'); if (!el || S.sub !== 'lessons') return; const d = D.deep || {}, adv = d.lessons, led = d.auto_ledger || [], mine = (l.cases || []).filter(c => c.symbol === w.sym);
      const row = c => `<div class="callout ${c.win ? 'good' : 'bad'}" style="margin-bottom:6px"><div><b>${esc(T.base(c.symbol))} ${c.side === 'LONG' ? 'خرید' : 'فروش'}</b> · <span class="mono">${c.r > 0 ? '+' : ''}${c.r}R</span> · ${esc(T.dt(c.t_close * 1000))}<br>${esc(c.lesson)}</div></div>`;
      el.innerHTML = `<div class="grid g2">${T.panel('ثبت خودکار برای این ارز', 'bolt', `${led.length ? led.slice().reverse().map(x => `<div class="row sm" style="gap:8px;padding:5px 0;border-bottom:1px solid var(--gl2)"><span class="${x.ok ? 'bull' : 'mut'}">${x.ok ? '✔ ثبت شد' : '✖ رد شد'}</span><span class="mono xs mut">${esc(T.dt(x.t * 1000))}</span><span class="xs" style="flex:1">${esc(x.text || '')}</span></div>`).join('') : '<div class="mut sm">برای این ارز هنوز تصمیم خودکاری ثبت نشده.</div>'}`)}
        ${T.panel('هشدار حافظهٔ اشتباهات برای سیگنال فعلی', 'shield', adv ? `${adv.ok ? T.callout('هیچ اشتباه تکراری ثابت‌شده‌ای در این ستاپ دیده نمی‌شود.', 'good') : adv.fails.map(f => T.callout(esc(f), 'bad')).join('<div style="height:6px"></div>')}${(adv.warns || []).map(x => T.callout(esc(x), 'warn')).join('')}<div class="row wrap" style="gap:6px;margin-top:8px">${(adv.tags || []).map(t => T.chip(esc(t.fa), 'warn', 'alert')).join('') || '<span class="mut xs">هشدار پیش‌ورودی ندارد</span>'}</div><div class="xs mut" style="margin-top:6px">بر پایهٔ ${T.fa(adv.n_cases)} معاملهٔ واقعی بسته‌شده.</div>` : T.empty('حکم فعلی انتظار است؛ چیزی برای سنجش نیست.', 'pause'))}</div>
        <div class="sec">${T.ic('hist')} معامله‌های بسته‌شدهٔ این ارز و درس آن‌ها</div>${mine.length ? mine.slice(0, 8).map(row).join('') : '<div class="mut sm">هنوز معاملهٔ بسته‌شده‌ای برای این ارز نیست.</div>'}
        <div class="sec">${T.ic('brain')} دانستهٔ کلی سیستم از همهٔ ارزها</div><div class="grid g2">${T.panel('اشتباه‌های پرتکرار (با آمار واقعی)', 'flag', `<table class="tbl">${Object.values(l.tags || {}).filter(x => x.n).map(x => `<tr><td>${esc(x.fa)}</td><td class="mono">n=${x.n}</td><td class="mono ${x.win <= 34 ? 'bear' : ''}">${x.win}٪ برد</td><td class="mono ${T.biasCls(x.sum_r)}">${x.sum_r}R</td></tr>`).join('') || '<tr><td class="mut">داده‌ای نیست</td></tr>'}</table>`)}${T.panel('قوانین فعال', 'lock', (l.rules || []).map(r => T.callout(esc(r.text) + ` (n=${r.n}، برد ${r.win}٪)`, 'warn')).join('<div style="height:6px"></div>') || '<div class="mut sm">هنوز قانونی فعال نشده؛ بعد از چند معاملهٔ بسته‌شده ساخته می‌شود.</div>')}</div>`;
    }
  };
})(window);
