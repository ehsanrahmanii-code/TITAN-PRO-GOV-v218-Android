"""Run the dashboard on synthetic data (no internet needed):  python tools/sim_server.py  → http://127.0.0.1:8080"""
import os, sys, tempfile
os.environ.setdefault("TITAN_DATA", tempfile.mkdtemp(prefix="XXX_sim_"))
sys.pycache_prefix = os.path.join(os.environ["TITAN_DATA"], "pycache")      # no __pycache__ next to the code
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools import sim_market
sim_market.install()
from app.web import app as web
from app.engine import scanner

if __name__ == "__main__":
    scanner.start_background()
    web.app.run(host="127.0.0.1", port=int(os.getenv("TITAN_PORT", "8080")), threaded=True)
